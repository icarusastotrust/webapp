import React from 'react';
import { Card, CardActionArea, CardContent, Typography, makeStyles } from '@mui/material';
import { Link } from 'react-router-dom';

const useStyles = makeStyles({
  card: {
    minWidth: 150,
    maxWidth: 200,
    margin: '10px',
    textAlign: 'center',
  },
  icon: {
    fontSize: '50px',
  },
});

const SectionButton = ({ icon, title, subtitle, link }) => {
  const classes = useStyles();

  return (
    <Card className={classes.card}>
      <CardActionArea component={Link} to={link}>
        <CardContent>
          <Typography className={classes.icon} component="div">
            {icon}
          </Typography>
          <Typography variant="h6" component="h2">
            {title}
          </Typography>
          <Typography color="textSecondary">
            {subtitle}
          </Typography>
        </CardContent>
      </CardActionArea>
    </Card>
  );
};

export default SectionButton;
