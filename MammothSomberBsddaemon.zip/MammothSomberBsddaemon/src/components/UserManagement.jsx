import React from 'react';
import { Typography, Box } from '@mui/material';

const UserManagement = () => {
  return (
    <Box p={3}>
      <Typography variant="h6" gutterBottom>
        User Management
      </Typography>
      <Typography>
        Allow different levels of access for maintenance personnel.
      </Typography>
      {/* Add your user management implementation here */}
    </Box>
  );
};

export default UserManagement;
