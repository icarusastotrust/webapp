
import React, { useState } from 'react';
import {
  Container,
  Typography,
  Grid,
  Paper,
  Card,
  CardContent,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  Box,
  Tabs,
  Tab,
  Chip,
  LinearProgress,
  AppBar,
  Toolbar,
  IconButton,
  Badge,
  Avatar,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText
} from '@mui/material';
import {
  Engineering,
  Build,
  Schedule,
  TrendingUp,
  Warning,
  CheckCircle,
  WaterDrop,
  Speed,
  Thermostat,
  Power,
  Menu as MenuIcon,
  Notifications as NotificationsIcon,
  Settings as SettingsIcon,
  AccountCircle as AccountCircleIcon,
  Assessment,
  Timeline,
  Opacity,
  LocalGasStation,
  Category
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import NavigationBreadcrumb from './NavigationBreadcrumb';

const PredictiveMaintenancePumps = () => {
  const [activeTab, setActiveTab] = useState(0);
  const [navigationOpen, setNavigationOpen] = useState(false);
  const navigate = useNavigate();
  const [pumpData, setPumpData] = useState({
    pumpType: '',
    flowRate: '',
    operatingPressure: '',
    operatingHours: '',
    fluidType: '',
    temperature: '',
    vibration: '',
    cavitation: '',
    efficiency: ''
  });

  const pumpTypes = [
    'Centrifugal Pump - Single Stage',
    'Centrifugal Pump - Multi Stage',
    'Reciprocating Pump - Triplex',
    'Reciprocating Pump - Quintuplex',
    'Progressive Cavity Pump',
    'Gear Pump',
    'Screw Pump',
    'Diaphragm Pump',
    'Submersible Pump',
    'Jet Pump'
  ];

  const fluidTypes = [
    'Crude Oil',
    'Natural Gas Liquids',
    'Produced Water',
    'Drilling Mud',
    'Completion Fluids',
    'Refined Products',
    'Chemicals/Additives',
    'Seawater',
    'Fresh Water'
  ];

  const handleNavigationToggle = () => {
    setNavigationOpen(!navigationOpen);
  };

  const lateralMenuItems = [
    { title: 'Overview', icon: <Assessment />, path: '/predictive-maintenance' },
    { title: 'Drilling Equipment', icon: <Engineering />, path: '/predictive-maintenance/drilling' },
    { title: 'Pumping Systems', icon: <Opacity />, path: '/predictive-maintenance/pumps' },
    { title: 'Pipeline Systems', icon: <Timeline />, path: '/predictive-maintenance/pipelines' },
    { title: 'Compressors', icon: <Speed />, path: '/predictive-maintenance/compressors' },
    { title: 'Turbines', icon: <LocalGasStation />, path: '/predictive-maintenance/turbines' },
    { title: 'Heat Exchangers', icon: <Thermostat />, path: '/predictive-maintenance/heat-exchangers' },
    { title: 'Separators', icon: <Category />, path: '/predictive-maintenance/separators' },
    { title: 'Valves & Controls', icon: <Build />, path: '/predictive-maintenance/valves' }
  ];

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {/* Top Banner */}
      <AppBar 
        position="fixed" 
        sx={{ 
          zIndex: (theme) => theme.zIndex.drawer + 1,
          background: 'linear-gradient(135deg, #1976d2 0%, #1565c0 100%)',
          boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open navigation"
            edge="start"
            onClick={handleNavigationToggle}
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          
          <Box display="flex" alignItems="center" flexGrow={1}>
            <Opacity sx={{ mr: 2, fontSize: 28 }} />
            <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
              ICARUS - Pumping Systems Maintenance
            </Typography>
          </Box>

          <Box display="flex" alignItems="center" gap={2}>
            <IconButton color="inherit">
              <Badge badgeContent={1} color="error">
                <NotificationsIcon />
              </Badge>
            </IconButton>
            <IconButton color="inherit">
              <SettingsIcon />
            </IconButton>
            <Avatar sx={{ bgcolor: 'rgba(255,255,255,0.2)' }}>
              <AccountCircleIcon />
            </Avatar>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Lateral Navigation Drawer */}
      <Drawer
        variant="temporary"
        anchor="left"
        open={navigationOpen}
        onClose={handleNavigationToggle}
        sx={{
          '& .MuiDrawer-paper': {
            width: 280,
            mt: '64px',
            height: 'calc(100vh - 64px)',
            background: 'linear-gradient(180deg, #f8f9fa 0%, #e9ecef 100%)',
            borderRight: '1px solid #dee2e6'
          }
        }}
      >
        <Box sx={{ p: 2 }}>
          <Typography variant="h6" sx={{ mb: 2, color: '#495057', fontWeight: 600 }}>
            Maintenance Modules
          </Typography>
          <List>
            {lateralMenuItems.map((item, index) => (
              <ListItem 
                button 
                key={index}
                onClick={() => {
                  navigate(item.path);
                  setNavigationOpen(false);
                }}
                sx={{
                  borderRadius: 2,
                  mb: 1,
                  '&:hover': {
                    backgroundColor: 'rgba(25, 118, 210, 0.1)',
                    transform: 'translateX(4px)',
                    transition: 'all 0.3s ease'
                  }
                }}
              >
                <ListItemIcon sx={{ color: '#1976d2' }}>
                  {item.icon}
                </ListItemIcon>
                <ListItemText 
                  primary={item.title}
                  sx={{ 
                    '& .MuiListItemText-primary': { 
                      fontWeight: 500,
                      color: '#495057'
                    } 
                  }} 
                />
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>

      {/* Main Content */}
      <Box 
        component="main" 
        sx={{ 
          flexGrow: 1, 
          pt: '64px',
          backgroundColor: '#f8f9fa',
          minHeight: '100vh'
        }}
      >
        <Container maxWidth="xl" sx={{ py: 4 }}>
          <NavigationBreadcrumb />
          
          <Typography variant="h4" gutterBottom sx={{ fontWeight: 700, color: '#2c3e50' }}>
            Predictive Maintenance - Pumping Systems
          </Typography>
          
          <Typography variant="body1" paragraph sx={{ color: '#6c757d', fontSize: '1.1rem' }}>
            Advanced maintenance prediction for oil and gas pumping equipment
          </Typography>

      <Tabs value={activeTab} onChange={(e, v) => setActiveTab(v)} sx={{ mb: 3 }}>
        <Tab label="Pump Analysis" />
        <Tab label="Performance Monitoring" />
        <Tab label="Maintenance Planning" />
      </Tabs>

      {activeTab === 0 && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Pump Condition Assessment
          </Typography>
          
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel>Pump Type</InputLabel>
                <Select
                  value={pumpData.pumpType}
                  onChange={(e) => setPumpData({...pumpData, pumpType: e.target.value})}
                  label="Pump Type"
                >
                  {pumpTypes.map((type) => (
                    <MenuItem key={type} value={type}>{type}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel>Fluid Type</InputLabel>
                <Select
                  value={pumpData.fluidType}
                  onChange={(e) => setPumpData({...pumpData, fluidType: e.target.value})}
                  label="Fluid Type"
                >
                  {fluidTypes.map((fluid) => (
                    <MenuItem key={fluid} value={fluid}>{fluid}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Flow Rate (bpd)"
                type="number"
                value={pumpData.flowRate}
                onChange={(e) => setPumpData({...pumpData, flowRate: e.target.value})}
              />
            </Grid>

            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Operating Pressure (psi)"
                type="number"
                value={pumpData.operatingPressure}
                onChange={(e) => setPumpData({...pumpData, operatingPressure: e.target.value})}
              />
            </Grid>

            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Operating Hours"
                type="number"
                value={pumpData.operatingHours}
                onChange={(e) => setPumpData({...pumpData, operatingHours: e.target.value})}
              />
            </Grid>

            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Temperature (°F)"
                type="number"
                value={pumpData.temperature}
                onChange={(e) => setPumpData({...pumpData, temperature: e.target.value})}
              />
            </Grid>

            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Vibration (mm/s RMS)"
                type="number"
                value={pumpData.vibration}
                onChange={(e) => setPumpData({...pumpData, vibration: e.target.value})}
              />
            </Grid>

            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Efficiency (%)"
                type="number"
                value={pumpData.efficiency}
                onChange={(e) => setPumpData({...pumpData, efficiency: e.target.value})}
              />
            </Grid>

            <Grid item xs={12}>
              <Button variant="contained" color="primary" size="large">
                Analyze Pump Condition
              </Button>
            </Grid>
          </Grid>

          {/* Pump-specific maintenance indicators */}
          <Grid container spacing={3} sx={{ mt: 2 }}>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Box display="flex" alignItems="center" mb={1}>
                    <WaterDrop color="primary" sx={{ mr: 1 }} />
                    <Typography variant="h6">Seal Condition</Typography>
                  </Box>
                  <Chip label="Good" color="success" />
                  <LinearProgress variant="determinate" value={75} sx={{ mt: 1 }} />
                  <Typography variant="caption">Next service: 2,500 hours</Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Box display="flex" alignItems="center" mb={1}>
                    <Speed color="warning" sx={{ mr: 1 }} />
                    <Typography variant="h6">Impeller Wear</Typography>
                  </Box>
                  <Chip label="Monitor" color="warning" />
                  <LinearProgress variant="determinate" value={45} color="warning" sx={{ mt: 1 }} />
                  <Typography variant="caption">Efficiency declining</Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Box display="flex" alignItems="center" mb={1}>
                    <Engineering color="success" sx={{ mr: 1 }} />
                    <Typography variant="h6">Bearing Health</Typography>
                  </Box>
                  <Chip label="Excellent" color="success" />
                  <LinearProgress variant="determinate" value={90} color="success" sx={{ mt: 1 }} />
                  <Typography variant="caption">Recently serviced</Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Paper>
      )}

      {activeTab === 1 && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Real-time Performance Monitoring
          </Typography>
          
          <Alert severity="info" sx={{ mb: 3 }}>
            <Typography>
              Live pump performance data and trending analysis with integration to existing SCADA systems.
            </Typography>
          </Alert>

          <Grid container spacing={3}>
            <Grid item xs={12} md={3}>
              <Card>
                <CardContent>
                  <Typography variant="h6">Current Flow</Typography>
                  <Typography variant="h4" color="primary">2,450</Typography>
                  <Typography variant="body2">bpd (95% of rated)</Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={3}>
              <Card>
                <CardContent>
                  <Typography variant="h6">Discharge Pressure</Typography>
                  <Typography variant="h4" color="success.main">1,245</Typography>
                  <Typography variant="body2">psi (Normal)</Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={3}>
              <Card>
                <CardContent>
                  <Typography variant="h6">Power Consumption</Typography>
                  <Typography variant="h4" color="warning.main">875</Typography>
                  <Typography variant="body2">kW (Elevated)</Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={3}>
              <Card>
                <CardContent>
                  <Typography variant="h6">Efficiency</Typography>
                  <Typography variant="h4" color="error.main">72%</Typography>
                  <Typography variant="body2">(Below optimal)</Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Paper>
      )}

      {activeTab === 2 && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Maintenance Planning & Recommendations
          </Typography>
          
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Alert severity="warning">
                <Typography variant="h6">Upcoming Maintenance Actions</Typography>
                <Typography>
                  Based on current operating conditions and performance trends, the following maintenance activities are recommended:
                </Typography>
              </Alert>
            </Grid>

            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>Immediate Actions (Next 30 days)</Typography>
                <Box display="flex" alignItems="center" sx={{ mb: 1 }}>
                  <CheckCircle color="warning" sx={{ mr: 1 }} />
                  <Typography>Inspect impeller for wear and cavitation damage</Typography>
                </Box>
                <Box display="flex" alignItems="center" sx={{ mb: 1 }}>
                  <CheckCircle color="warning" sx={{ mr: 1 }} />
                  <Typography>Check mechanical seal condition</Typography>
                </Box>
                <Box display="flex" alignItems="center" sx={{ mb: 1 }}>
                  <CheckCircle color="error" sx={{ mr: 1 }} />
                  <Typography>Investigate efficiency decline</Typography>
                </Box>
              </Paper>
            </Grid>

            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>Planned Maintenance (Next 90 days)</Typography>
                <Box display="flex" alignItems="center" sx={{ mb: 1 }}>
                  <Schedule color="info" sx={{ mr: 1 }} />
                  <Typography>Bearing lubrication service</Typography>
                </Box>
                <Box display="flex" alignItems="center" sx={{ mb: 1 }}>
                  <Schedule color="info" sx={{ mr: 1 }} />
                  <Typography>Vibration analysis and balancing</Typography>
                </Box>
                <Box display="flex" alignItems="center" sx={{ mb: 1 }}>
                  <Schedule color="info" sx={{ mr: 1 }} />
                  <Typography>Performance test and curve validation</Typography>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Paper>
      )}
        </Container>
      </Box>
    </Box>
  );
};

export default PredictiveMaintenancePumps;
