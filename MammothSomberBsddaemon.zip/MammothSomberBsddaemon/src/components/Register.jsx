import React, { useState } from 'react';
import { Container, TextField, Button, Typography, Paper, MenuItem, Select, InputLabel, FormControl } from '@mui/material';
import { makeStyles } from '@mui/styles';
import { useNavigate } from 'react-router-dom';
import backgroundImage from '/test.png';

const useStyles = makeStyles((theme) => ({
  root: {
    height: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundImage: `url(${backgroundImage})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
  },
  paper: {
    padding: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
  },
  form: {
    marginTop: 10,
  },
  submit: {
    margin: '20px 0 10px',
  },
}));

const Login = () => {
  const classes = useStyles();
  const navigate = useNavigate();
  const [user, setUser] = useState({
    name: '',
    surname: '',
    post: '',
    phoneNumber: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({
      ...user,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission (e.g., send data to backend)
    console.log('User Registered:', user);
    navigate(`/dashboard/${user.post.toLowerCase().replace(/\s+/g, '-')}`);
  };

  return (
    <div className={classes.root}>
      <Container component="main" maxWidth="xs">
        <Paper className={classes.paper}>
          <Typography component="h1" variant="h5">
            Welcome to Aygos Traceability System
          </Typography>
          <form className={classes.form} onSubmit={handleSubmit}>
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              id="name"
              label="Name"
              name="name"
              autoComplete="name"
              autoFocus
              value={user.name}
              onChange={handleChange}
            />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              name="surname"
              label="Surname"
              id="surname"
              autoComplete="surname"
              value={user.surname}
              onChange={handleChange}
            />
            <FormControl variant="outlined" fullWidth margin="normal" required>
              <InputLabel id="post-label">Post in Company</InputLabel>
              <Select
                labelId="post-label"
                id="post"
                name="post"
                value={user.post}
                onChange={handleChange}
                label="Post in Company"
              >
                <MenuItem value="MAGASIN MATIÈRE PREMIÈRE">MAGASIN MATIÈRE PREMIÈRE</MenuItem>
                <MenuItem value="FRAGILISATION">FRAGILISATION</MenuItem>
                <MenuItem value="DÉCORTICAGE">DÉCORTICAGE</MenuItem>
                <MenuItem value="SÉCHAGE">SÉCHAGE</MenuItem>
                <MenuItem value="DÉPELLICULAGE">DÉPELLICULAGE</MenuItem>
                <MenuItem value="CLASSIFICATION+ÉPURATION">CLASSIFICATION+ÉPURATION</MenuItem>
                <MenuItem value="EMBALLAGE PRODUITS FINI">EMBALLAGE PRODUITS FINI</MenuItem>
              </Select>
            </FormControl>
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              name="phoneNumber"
              label="Phone Number"
              id="phoneNumber"
              autoComplete="phoneNumber"
              value={user.phoneNumber}
              onChange={handleChange}
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              className={classes.submit}
            >
              Register
            </Button>
          </form>
        </Paper>
      </Container>
    </div>
  );
};

export default Login;
