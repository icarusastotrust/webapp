
import React, { useState, useEffect } from 'react';
import {
  Container, Typography, Box, Card, CardContent, Grid, Button, TextField,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper,
  Chip, IconButton, Dialog, DialogTitle, DialogContent, DialogActions,
  FormControl, InputLabel, Select, MenuItem, Tabs, Tab, Avatar, Badge,
  Drawer, List, ListItem, ListItemIcon, ListItemText, Divider, AppBar,
  Toolbar, Breadcrumbs, Link, Alert, Snackbar, LinearProgress, Fab,
  InputAdornment, Tooltip, CardHeader, CardActions
} from '@mui/material';
import {
  Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon, Search as SearchIcon,
  FilterList as FilterIcon, Settings as SettingsIcon, Build as BuildIcon,
  Engineering as EngineeringIcon, Speed as SpeedIcon, Warning as WarningIcon,
  CheckCircle as CheckCircleIcon, Schedule as ScheduleIcon, Analytics as AnalyticsIcon,
  Inventory as InventoryIcon, Assignment as AssignmentIcon, Home as HomeIcon,
  Dashboard as DashboardIcon, Close as CloseIcon, Refresh as RefreshIcon,
  Download as DownloadIcon, Upload as UploadIcon, Visibility as VisibilityIcon
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import NavigationBreadcrumb from './NavigationBreadcrumb';

const MaintenanceEquipmentDatabase = () => {
  const navigate = useNavigate();
  const { user, userRole } = useAuth();
  
  // State management
  const [activeTab, setActiveTab] = useState(0);
  const [equipment, setEquipment] = useState([]);
  const [filteredEquipment, setFilteredEquipment] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedEquipment, setSelectedEquipment] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  // Equipment data structure
  const [newEquipment, setNewEquipment] = useState({
    id: '',
    name: '',
    type: '',
    location: '',
    status: 'operational',
    lastMaintenance: '',
    nextMaintenance: '',
    manufacturer: '',
    model: '',
    serialNumber: '',
    installationDate: '',
    criticality: 'medium',
    maintenanceHistory: []
  });

  // Mock data for demonstration
  useEffect(() => {
    const mockEquipment = [
      {
        id: 'EQ001',
        name: 'Mud Pump #1',
        type: 'Drilling Equipment',
        location: 'Drilling Platform A',
        status: 'operational',
        lastMaintenance: '2024-01-15',
        nextMaintenance: '2024-04-15',
        manufacturer: 'National Oilwell Varco',
        model: 'NOV-3NB1600',
        serialNumber: 'NOV2024001',
        installationDate: '2023-06-01',
        criticality: 'high',
        maintenanceHistory: [
          { date: '2024-01-15', type: 'Preventive', description: 'Seal replacement and inspection' },
          { date: '2023-10-15', type: 'Corrective', description: 'Bearing replacement' }
        ]
      },
      {
        id: 'EQ002',
        name: 'Top Drive System',
        type: 'Drilling Equipment',
        location: 'Drilling Platform A',
        status: 'maintenance',
        lastMaintenance: '2024-01-20',
        nextMaintenance: '2024-03-20',
        manufacturer: 'Cameron',
        model: 'TDS-11SA',
        serialNumber: 'CAM2024002',
        installationDate: '2023-07-15',
        criticality: 'high',
        maintenanceHistory: [
          { date: '2024-01-20', type: 'Preventive', description: 'Motor bearing inspection' }
        ]
      },
      {
        id: 'EQ003',
        name: 'Pipeline Pump Station #3',
        type: 'Pipeline Equipment',
        location: 'Pipeline Segment 12',
        status: 'operational',
        lastMaintenance: '2024-01-10',
        nextMaintenance: '2024-04-10',
        manufacturer: 'Sulzer',
        model: 'BB5',
        serialNumber: 'SUL2024003',
        installationDate: '2023-05-20',
        criticality: 'medium',
        maintenanceHistory: []
      }
    ];
    setEquipment(mockEquipment);
    setFilteredEquipment(mockEquipment);
  }, []);

  // Filter equipment based on search and status
  useEffect(() => {
    let filtered = equipment.filter(eq => 
      eq.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      eq.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      eq.location.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (statusFilter !== 'all') {
      filtered = filtered.filter(eq => eq.status === statusFilter);
    }

    setFilteredEquipment(filtered);
  }, [searchTerm, statusFilter, equipment]);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleAddEquipment = () => {
    setSelectedEquipment(null);
    setNewEquipment({
      id: '',
      name: '',
      type: '',
      location: '',
      status: 'operational',
      lastMaintenance: '',
      nextMaintenance: '',
      manufacturer: '',
      model: '',
      serialNumber: '',
      installationDate: '',
      criticality: 'medium',
      maintenanceHistory: []
    });
    setDialogOpen(true);
  };

  const handleEditEquipment = (eq) => {
    setSelectedEquipment(eq);
    setNewEquipment(eq);
    setDialogOpen(true);
  };

  const handleSaveEquipment = () => {
    if (selectedEquipment) {
      // Update existing equipment
      setEquipment(prev => prev.map(eq => eq.id === selectedEquipment.id ? newEquipment : eq));
    } else {
      // Add new equipment
      const id = `EQ${String(equipment.length + 1).padStart(3, '0')}`;
      setEquipment(prev => [...prev, { ...newEquipment, id }]);
    }
    setDialogOpen(false);
    setSnackbar({ open: true, message: 'Equipment saved successfully!', severity: 'success' });
  };

  const handleDeleteEquipment = (id) => {
    setEquipment(prev => prev.filter(eq => eq.id !== id));
    setSnackbar({ open: true, message: 'Equipment deleted successfully!', severity: 'success' });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'operational': return 'success';
      case 'maintenance': return 'warning';
      case 'out_of_order': return 'error';
      default: return 'default';
    }
  };

  const getCriticalityColor = (criticality) => {
    switch (criticality) {
      case 'high': return 'error';
      case 'medium': return 'warning';
      case 'low': return 'success';
      default: return 'default';
    }
  };

  // Enhanced lateral navigation items with proper interconnection
  const navigationItems = [
    { text: 'Main Dashboard', icon: <HomeIcon />, path: '/main-dashboard', description: 'Return to main overview' },
    { text: 'Equipment Database', icon: <InventoryIcon />, active: true, description: 'Current: Equipment management' },
    { text: 'Maintenance Schedule', icon: <ScheduleIcon />, path: '/maintenance-scheduling', description: 'Schedule maintenance tasks' },
    { text: 'Work Orders', icon: <AssignmentIcon />, path: '/work-orders', description: 'Manage work orders' },
    { text: 'Analytics', icon: <AnalyticsIcon />, path: '/reporting-analytics', description: 'View reports and analytics' },
    { text: 'Predictive Maintenance', icon: <EngineeringIcon />, path: '/predictive-maintenance/drilling', description: 'Predictive analytics' },
    { text: 'Settings', icon: <SettingsIcon />, path: '/settings', description: 'System configuration' }
  ];

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', backgroundColor: '#f8fafc' }}>
      {/* Stylish Top Banner */}
      <AppBar 
        position="fixed" 
        sx={{ 
          zIndex: (theme) => theme.zIndex.drawer + 1,
          background: 'linear-gradient(135deg, #1976d2 0%, #42a5f5 100%)',
          boxShadow: '0 4px 20px rgba(0,0,0,0.15)'
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            onClick={() => setDrawerOpen(!drawerOpen)}
            edge="start"
            sx={{ mr: 2 }}
          >
            <BuildIcon />
          </IconButton>
          
          <Box sx={{ flexGrow: 1 }}>
            <Box display="flex" alignItems="center" gap={1}>
              <IconButton 
                color="inherit" 
                onClick={() => navigate('/main-dashboard')}
                sx={{ mr: 1 }}
              >
                <HomeIcon />
              </IconButton>
              <Box>
                <Typography variant="h6" sx={{ fontWeight: 700 }}>
                  Maintenance Equipment Database
                </Typography>
                <Typography variant="caption" sx={{ opacity: 0.8 }}>
                  Advanced Equipment Management System • ICARUS Portal
                </Typography>
              </Box>
            </Box>
          </Box>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Badge badgeContent={equipment.filter(eq => eq.status === 'maintenance').length} color="warning">
              <WarningIcon />
            </Badge>
            <Badge badgeContent={equipment.filter(eq => eq.status === 'operational').length} color="success">
              <CheckCircleIcon />
            </Badge>
            <Avatar sx={{ bgcolor: 'rgba(255,255,255,0.2)' }}>
              {user?.name?.charAt(0)}
            </Avatar>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Stylish Lateral Banner/Drawer */}
      <Drawer
        variant="persistent"
        anchor="left"
        open={drawerOpen}
        sx={{
          width: 280,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: 280,
            boxSizing: 'border-box',
            backgroundColor: '#ffffff',
            borderRight: '1px solid #e0e7ff',
            boxShadow: '4px 0 20px rgba(0,0,0,0.1)',
            mt: 8
          },
        }}
      >
        <Box sx={{ p: 2, background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white' }}>
          <Typography variant="h6" sx={{ fontWeight: 700, mb: 1 }}>
            Navigation
          </Typography>
          <Typography variant="caption" sx={{ opacity: 0.9 }}>
            Maintenance Management System
          </Typography>
        </Box>
        
        <List sx={{ px: 1, py: 2 }}>
          {navigationItems.map((item, index) => (
            <ListItem key={index} sx={{ mb: 0.5 }}>
              <Tooltip title={item.description} placement="right">
                <Button
                  fullWidth
                  startIcon={item.icon}
                  onClick={() => item.path && navigate(item.path)}
                  sx={{
                    justifyContent: 'flex-start',
                    py: 1.5,
                    px: 2,
                    backgroundColor: item.active ? 'primary.50' : 'transparent',
                    color: item.active ? 'primary.main' : 'text.primary',
                    fontWeight: item.active ? 600 : 400,
                    borderRadius: 2,
                    border: item.active ? '1px solid' : 'none',
                    borderColor: item.active ? 'primary.200' : 'transparent',
                    textAlign: 'left',
                    '&:hover': {
                      backgroundColor: 'primary.50',
                      transform: 'translateX(4px)',
                      transition: 'all 0.2s ease'
                    }
                  }}
                >
                  {item.text}
                </Button>
              </Tooltip>
            </ListItem>
          ))}
        </List>
        
        <Divider sx={{ mx: 2 }} />
        
        <Box sx={{ p: 2 }}>
          <Card sx={{ background: 'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)', mb: 2 }}>
            <CardContent sx={{ p: 2 }}>
              <Typography variant="subtitle2" sx={{ color: 'white', fontWeight: 600, mb: 1 }}>
                Quick Stats
              </Typography>
              <Typography variant="caption" sx={{ color: 'white', opacity: 0.9, display: 'block', mb: 0.5 }}>
                Total Equipment: {equipment.length}
              </Typography>
              <Typography variant="caption" sx={{ color: 'white', opacity: 0.9, display: 'block', mb: 0.5 }}>
                Operational: {equipment.filter(eq => eq.status === 'operational').length}
              </Typography>
              <Typography variant="caption" sx={{ color: 'white', opacity: 0.9, display: 'block' }}>
                Maintenance: {equipment.filter(eq => eq.status === 'maintenance').length}
              </Typography>
            </CardContent>
          </Card>
          
          <Button
            fullWidth
            variant="contained"
            startIcon={<HomeIcon />}
            onClick={() => navigate('/main-dashboard')}
            sx={{
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              color: 'white',
              py: 1.2,
              borderRadius: 2,
              fontWeight: 600,
              '&:hover': {
                transform: 'translateY(-2px)',
                boxShadow: '0 6px 20px rgba(0,0,0,0.2)'
              }
            }}
          >
            Back to Dashboard
          </Button>
        </Box>
      </Drawer>

      {/* Main Content */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          mt: 8,
          ml: drawerOpen ? 0 : 0,
          transition: 'margin 0.3s ease'
        }}
      >
        <Container maxWidth="xl">
          <NavigationBreadcrumb />
          
          {/* Stats Cards */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white' }}>
                <CardContent>
                  <Box display="flex" alignItems="center" justifyContent="space-between">
                    <Box>
                      <Typography variant="h4" sx={{ fontWeight: 700 }}>
                        {equipment.length}
                      </Typography>
                      <Typography variant="body2" sx={{ opacity: 0.9 }}>
                        Total Equipment
                      </Typography>
                    </Box>
                    <InventoryIcon sx={{ fontSize: 48, opacity: 0.7 }} />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', color: 'white' }}>
                <CardContent>
                  <Box display="flex" alignItems="center" justifyContent="space-between">
                    <Box>
                      <Typography variant="h4" sx={{ fontWeight: 700 }}>
                        {equipment.filter(eq => eq.status === 'operational').length}
                      </Typography>
                      <Typography variant="body2" sx={{ opacity: 0.9 }}>
                        Operational
                      </Typography>
                    </Box>
                    <CheckCircleIcon sx={{ fontSize: 48, opacity: 0.7 }} />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ background: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)', color: 'white' }}>
                <CardContent>
                  <Box display="flex" alignItems="center" justifyContent="space-between">
                    <Box>
                      <Typography variant="h4" sx={{ fontWeight: 700 }}>
                        {equipment.filter(eq => eq.status === 'maintenance').length}
                      </Typography>
                      <Typography variant="body2" sx={{ opacity: 0.9 }}>
                        In Maintenance
                      </Typography>
                    </Box>
                    <BuildIcon sx={{ fontSize: 48, opacity: 0.7 }} />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ background: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)', color: 'white' }}>
                <CardContent>
                  <Box display="flex" alignItems="center" justifyContent="space-between">
                    <Box>
                      <Typography variant="h4" sx={{ fontWeight: 700 }}>
                        {equipment.filter(eq => eq.criticality === 'high').length}
                      </Typography>
                      <Typography variant="body2" sx={{ opacity: 0.9 }}>
                        Critical Equipment
                      </Typography>
                    </Box>
                    <WarningIcon sx={{ fontSize: 48, opacity: 0.7 }} />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* Control Panel */}
          <Card sx={{ mb: 3, borderRadius: 3, boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}>
            <CardHeader 
              title="Equipment Management" 
              subheader="Manage and monitor all maintenance equipment"
              action={
                <Button
                  variant="contained"
                  startIcon={<AddIcon />}
                  onClick={handleAddEquipment}
                  sx={{ borderRadius: 2 }}
                >
                  Add Equipment
                </Button>
              }
            />
            <CardContent>
              <Grid container spacing={2} alignItems="center">
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    placeholder="Search equipment..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <SearchIcon />
                        </InputAdornment>
                      ),
                    }}
                    sx={{ borderRadius: 2 }}
                  />
                </Grid>
                <Grid item xs={12} md={3}>
                  <FormControl fullWidth>
                    <InputLabel>Status Filter</InputLabel>
                    <Select
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      label="Status Filter"
                    >
                      <MenuItem value="all">All Status</MenuItem>
                      <MenuItem value="operational">Operational</MenuItem>
                      <MenuItem value="maintenance">In Maintenance</MenuItem>
                      <MenuItem value="out_of_order">Out of Order</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} md={5}>
                  <Box display="flex" gap={1}>
                    <Button startIcon={<RefreshIcon />} variant="outlined">
                      Refresh
                    </Button>
                    <Button startIcon={<DownloadIcon />} variant="outlined">
                      Export
                    </Button>
                    <Button startIcon={<UploadIcon />} variant="outlined">
                      Import
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Equipment Table */}
          <Card sx={{ borderRadius: 3, boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}>
            <TableContainer>
              <Table>
                <TableHead sx={{ backgroundColor: '#f8fafc' }}>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 700 }}>Equipment ID</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Name</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Type</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Location</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Criticality</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Next Maintenance</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredEquipment.map((eq) => (
                    <TableRow key={eq.id} hover>
                      <TableCell>
                        <Typography variant="body2" sx={{ fontWeight: 600, color: 'primary.main' }}>
                          {eq.id}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" sx={{ fontWeight: 500 }}>
                          {eq.name}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {eq.manufacturer} {eq.model}
                        </Typography>
                      </TableCell>
                      <TableCell>{eq.type}</TableCell>
                      <TableCell>{eq.location}</TableCell>
                      <TableCell>
                        <Chip 
                          label={eq.status.replace('_', ' ').toUpperCase()}
                          color={getStatusColor(eq.status)}
                          size="small"
                          sx={{ fontWeight: 600 }}
                        />
                      </TableCell>
                      <TableCell>
                        <Chip 
                          label={eq.criticality.toUpperCase()}
                          color={getCriticalityColor(eq.criticality)}
                          variant="outlined"
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {new Date(eq.nextMaintenance).toLocaleDateString()}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Box display="flex" gap={1}>
                          <Tooltip title="View Details">
                            <IconButton size="small" color="info">
                              <VisibilityIcon />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Edit">
                            <IconButton size="small" color="primary" onClick={() => handleEditEquipment(eq)}>
                              <EditIcon />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Delete">
                            <IconButton size="small" color="error" onClick={() => handleDeleteEquipment(eq.id)}>
                              <DeleteIcon />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Card>
        </Container>

        {/* Floating Action Button */}
        <Fab
          color="primary"
          aria-label="add"
          onClick={handleAddEquipment}
          sx={{
            position: 'fixed',
            bottom: 16,
            right: 16,
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
          }}
        >
          <AddIcon />
        </Fab>
      </Box>

      {/* Equipment Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>
          <Box display="flex" alignItems="center" justifyContent="space-between">
            <Typography variant="h6">
              {selectedEquipment ? 'Edit Equipment' : 'Add New Equipment'}
            </Typography>
            <IconButton onClick={() => setDialogOpen(false)}>
              <CloseIcon />
            </IconButton>
          </Box>
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={3} sx={{ mt: 1 }}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Equipment Name"
                value={newEquipment.name}
                onChange={(e) => setNewEquipment({...newEquipment, name: e.target.value})}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel>Equipment Type</InputLabel>
                <Select
                  value={newEquipment.type}
                  onChange={(e) => setNewEquipment({...newEquipment, type: e.target.value})}
                  label="Equipment Type"
                >
                  <MenuItem value="Drilling Equipment">Drilling Equipment</MenuItem>
                  <MenuItem value="Pipeline Equipment">Pipeline Equipment</MenuItem>
                  <MenuItem value="Pump Systems">Pump Systems</MenuItem>
                  <MenuItem value="Compressor Systems">Compressor Systems</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Location"
                value={newEquipment.location}
                onChange={(e) => setNewEquipment({...newEquipment, location: e.target.value})}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel>Status</InputLabel>
                <Select
                  value={newEquipment.status}
                  onChange={(e) => setNewEquipment({...newEquipment, status: e.target.value})}
                  label="Status"
                >
                  <MenuItem value="operational">Operational</MenuItem>
                  <MenuItem value="maintenance">In Maintenance</MenuItem>
                  <MenuItem value="out_of_order">Out of Order</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Manufacturer"
                value={newEquipment.manufacturer}
                onChange={(e) => setNewEquipment({...newEquipment, manufacturer: e.target.value})}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Model"
                value={newEquipment.model}
                onChange={(e) => setNewEquipment({...newEquipment, model: e.target.value})}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Serial Number"
                value={newEquipment.serialNumber}
                onChange={(e) => setNewEquipment({...newEquipment, serialNumber: e.target.value})}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel>Criticality</InputLabel>
                <Select
                  value={newEquipment.criticality}
                  onChange={(e) => setNewEquipment({...newEquipment, criticality: e.target.value})}
                  label="Criticality"
                >
                  <MenuItem value="low">Low</MenuItem>
                  <MenuItem value="medium">Medium</MenuItem>
                  <MenuItem value="high">High</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button onClick={() => setDialogOpen(false)} variant="outlined">
            Cancel
          </Button>
          <Button onClick={handleSaveEquipment} variant="contained">
            {selectedEquipment ? 'Update' : 'Create'} Equipment
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar({...snackbar, open: false})}
      >
        <Alert severity={snackbar.severity} onClose={() => setSnackbar({...snackbar, open: false})}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default MaintenanceEquipmentDatabase;
