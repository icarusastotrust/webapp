import React from 'react';
import { Bar } from 'react-chartjs-2';
import { Container, Typography } from '@mui/material';

const QualityChart = ({ aygosQuality, internationalStandards }) => {
  const data = {
    labels: ['Moisture', 'FFA', 'PV', 'Aflatoxin', 'E. coli', 'Salmonella', 'Listeria', 'Staphylococcus'],
    datasets: [
      {
        label: 'AYGOS Quality',
        data: aygosQuality,
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
      {
        label: 'International Standards',
        data: internationalStandards,
        backgroundColor: 'rgba(153, 102, 255, 0.6)',
      },
    ],
  };

  const options = {
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <Container>
      <Typography variant="h5" component="h1" gutterBottom>
        Cashew Nut Quality: AYGOS vs International Standards
      </Typography>
      <Bar data={data} options={options} />
    </Container>
  );
};

export default QualityChart;
