
import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  IconButton,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText
} from '@mui/material';
import {
  Close as CloseIcon,
  Support as SupportIcon,
  Description as DocIcon,
  Security as PrivacyIcon,
  Gavel as TermsIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  Chat as ChatIcon,
  GetApp as DownloadIcon,
  MenuBook as GuideIcon,
  Code as ApiIcon
} from '@mui/icons-material';

// Support Modal
export const SupportModal = ({ open, onClose }) => {
  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box display="flex" alignItems="center">
          <SupportIcon sx={{ mr: 1, color: '#1976d2' }} />
          Support Center
        </Box>
        <IconButton onClick={onClose}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent>
        <Typography variant="body1" paragraph>
          Need help with the ICARUS System? Our support team is here to assist you.
        </Typography>
        
        <List>
          <ListItem>
            <ListItemIcon>
              <EmailIcon color="primary" />
            </ListItemIcon>
            <ListItemText 
              primary="Email Support" 
              secondary="support@icarus-system.com - Response within 24 hours"
            />
          </ListItem>
          <ListItem>
            <ListItemIcon>
              <PhoneIcon color="primary" />
            </ListItemIcon>
            <ListItemText 
              primary="Phone Support" 
              secondary="+1 (555) 123-4567 - Monday to Friday, 9 AM - 6 PM EST"
            />
          </ListItem>
          <ListItem>
            <ListItemIcon>
              <ChatIcon color="primary" />
            </ListItemIcon>
            <ListItemText 
              primary="Live Chat" 
              secondary="Available during business hours for immediate assistance"
            />
          </ListItem>
        </List>
        
        <Box mt={2}>
          <Typography variant="h6" gutterBottom>Common Issues</Typography>
          <Typography variant="body2" paragraph>
            • Login problems: Check your credentials and contact your administrator
          </Typography>
          <Typography variant="body2" paragraph>
            • Permission issues: Verify your role and access level
          </Typography>
          <Typography variant="body2" paragraph>
            • Performance issues: Clear browser cache and try again
          </Typography>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} variant="contained">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// Documentation Modal
export const DocumentationModal = ({ open, onClose }) => {
  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box display="flex" alignItems="center">
          <DocIcon sx={{ mr: 1, color: '#1976d2' }} />
          Documentation
        </Box>
        <IconButton onClick={onClose}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent>
        <Typography variant="body1" paragraph>
          Access comprehensive documentation for the ICARUS System platform.
        </Typography>
        
        <List>
          <ListItem>
            <ListItemIcon>
              <GuideIcon color="primary" />
            </ListItemIcon>
            <ListItemText 
              primary="User Guide" 
              secondary="Step-by-step instructions for all system features"
            />
          </ListItem>
          <ListItem>
            <ListItemIcon>
              <ApiIcon color="primary" />
            </ListItemIcon>
            <ListItemText 
              primary="API Documentation" 
              secondary="Technical reference for developers and integrators"
            />
          </ListItem>
          <ListItem>
            <ListItemIcon>
              <DownloadIcon color="primary" />
            </ListItemIcon>
            <ListItemText 
              primary="Quick Reference" 
              secondary="Downloadable PDF guides and cheat sheets"
            />
          </ListItem>
        </List>
        
        <Divider sx={{ my: 2 }} />
        
        <Box>
          <Typography variant="h6" gutterBottom>Available Modules</Typography>
          <Typography variant="body2" paragraph>
            • Manufacturing Operations Portal
          </Typography>
          <Typography variant="body2" paragraph>
            • Predictive Maintenance System
          </Typography>
          <Typography variant="body2" paragraph>
            • Africa Negoce Industrie Platform
          </Typography>
          <Typography variant="body2" paragraph>
            • Pipeline Monitoring & Drone Integration
          </Typography>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} variant="contained">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// Privacy Policy Modal
export const PrivacyPolicyModal = ({ open, onClose }) => {
  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box display="flex" alignItems="center">
          <PrivacyIcon sx={{ mr: 1, color: '#1976d2' }} />
          Privacy Policy
        </Box>
        <IconButton onClick={onClose}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent>
        <Typography variant="h6" gutterBottom>
          ICARUS System Privacy Policy
        </Typography>
        <Typography variant="caption" color="text.secondary" paragraph>
          Last updated: December 2024
        </Typography>
        
        <Typography variant="body2" paragraph>
          <strong>Data Collection:</strong> We collect information necessary to provide our industrial 
          control and monitoring services, including user credentials, system usage data, and operational metrics.
        </Typography>
        
        <Typography variant="body2" paragraph>
          <strong>Data Usage:</strong> Your data is used to provide system functionality, improve performance, 
          generate analytics, and ensure security compliance.
        </Typography>
        
        <Typography variant="body2" paragraph>
          <strong>Data Security:</strong> We implement industry-standard security measures including encryption, 
          access controls, and regular security audits to protect your information.
        </Typography>
        
        <Typography variant="body2" paragraph>
          <strong>Data Sharing:</strong> We do not share your data with third parties except as required 
          by law or with your explicit consent.
        </Typography>
        
        <Typography variant="body2" paragraph>
          <strong>Your Rights:</strong> You have the right to access, modify, or delete your personal data. 
          Contact our support team for assistance with data requests.
        </Typography>
        
        <Box mt={2} p={2} bgcolor="grey.100" borderRadius={1}>
          <Typography variant="body2">
            <strong>Contact:</strong> For privacy-related questions, contact privacy@icarus-system.com
          </Typography>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} variant="contained">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// Terms of Service Modal
export const TermsOfServiceModal = ({ open, onClose }) => {
  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box display="flex" alignItems="center">
          <TermsIcon sx={{ mr: 1, color: '#1976d2' }} />
          Terms of Service
        </Box>
        <IconButton onClick={onClose}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent>
        <Typography variant="h6" gutterBottom>
          ICARUS System Terms of Service
        </Typography>
        <Typography variant="caption" color="text.secondary" paragraph>
          Last updated: December 2024
        </Typography>
        
        <Typography variant="body2" paragraph>
          <strong>1. Acceptance of Terms:</strong> By accessing and using the ICARUS System, you agree 
          to be bound by these terms and conditions.
        </Typography>
        
        <Typography variant="body2" paragraph>
          <strong>2. Authorized Use:</strong> The system is intended for authorized industrial operations 
          personnel only. Misuse or unauthorized access is strictly prohibited.
        </Typography>
        
        <Typography variant="body2" paragraph>
          <strong>3. User Responsibilities:</strong> Users are responsible for maintaining the confidentiality 
          of their login credentials and for all activities under their account.
        </Typography>
        
        <Typography variant="body2" paragraph>
          <strong>4. System Availability:</strong> We strive for 99.9% uptime but cannot guarantee 
          uninterrupted service due to maintenance, updates, or unforeseen circumstances.
        </Typography>
        
        <Typography variant="body2" paragraph>
          <strong>5. Limitation of Liability:</strong> Africa Negoce Industrie shall not be liable for 
          any indirect, incidental, or consequential damages arising from system use.
        </Typography>
        
        <Typography variant="body2" paragraph>
          <strong>6. Modification of Terms:</strong> We reserve the right to modify these terms at any 
          time. Users will be notified of significant changes.
        </Typography>
        
        <Box mt={2} p={2} bgcolor="grey.100" borderRadius={1}>
          <Typography variant="body2">
            <strong>Governing Law:</strong> These terms are governed by applicable industrial regulations 
            and local jurisdiction laws.
          </Typography>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} variant="contained">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};
