
import React from 'react';
import {
  Card,
  CardContent,
  CardActions,
  Typography,
  Button,
  Box,
  Chip,
  Avatar,
  IconButton,
  LinearProgress
} from '@mui/material';
import {
  MoreVert as MoreVertIcon,
  TrendingUp as TrendingUpIcon,
  Warning as WarningIcon,
  CheckCircle as CheckCircleIcon
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const ModuleCard = ({
  title,
  description,
  icon,
  status = 'active',
  progress = null,
  metrics = {},
  primaryAction,
  secondaryAction,
  badge = null,
  variant = 'default'
}) => {
  const navigate = useNavigate();

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'success';
      case 'warning': return 'warning';
      case 'error': return 'error';
      case 'inactive': return 'default';
      default: return 'primary';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active': return <CheckCircleIcon />;
      case 'warning': return <WarningIcon />;
      case 'error': return <WarningIcon />;
      default: return <TrendingUpIcon />;
    }
  };

  return (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        overflow: 'visible',
        '&:hover': {
          '& .module-actions': {
            opacity: 1
          }
        }
      }}
    >
      {badge && (
        <Chip
          label={badge}
          size="small"
          color="primary"
          sx={{
            position: 'absolute',
            top: 12,
            right: 12,
            zIndex: 1
          }}
        />
      )}

      <CardContent sx={{ flexGrow: 1, pb: 1 }}>
        <Box display="flex" alignItems="flex-start" justifyContent="space-between" mb={2}>
          <Box display="flex" alignItems="center" gap={2}>
            <Avatar
              sx={{
                bgcolor: 'primary.100',
                color: 'primary.600',
                width: 48,
                height: 48
              }}
            >
              {icon}
            </Avatar>
            <Box>
              <Typography variant="h6" component="h3" sx={{ fontWeight: 600, mb: 0.5 }}>
                {title}
              </Typography>
              <Chip
                icon={getStatusIcon(status)}
                label={status.charAt(0).toUpperCase() + status.slice(1)}
                size="small"
                color={getStatusColor(status)}
                variant="outlined"
              />
            </Box>
          </Box>
          
          <IconButton
            size="small"
            className="module-actions"
            sx={{ opacity: 0, transition: 'opacity 0.2s' }}
          >
            <MoreVertIcon />
          </IconButton>
        </Box>

        <Typography variant="body2" color="text.secondary" paragraph>
          {description}
        </Typography>

        {progress !== null && (
          <Box mb={2}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
              <Typography variant="caption" color="text.secondary">
                Completion
              </Typography>
              <Typography variant="caption" fontWeight={600}>
                {progress}%
              </Typography>
            </Box>
            <LinearProgress
              variant="determinate"
              value={progress}
              sx={{ borderRadius: 2, height: 6 }}
            />
          </Box>
        )}

        {Object.keys(metrics).length > 0 && (
          <Box
            display="flex"
            gap={2}
            mt={2}
            p={2}
            bgcolor="grey.50"
            borderRadius={1}
          >
            {Object.entries(metrics).map(([key, value]) => (
              <Box key={key} textAlign="center" flex={1}>
                <Typography variant="h6" fontWeight={600} color="primary.main">
                  {value}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {key}
                </Typography>
              </Box>
            ))}
          </Box>
        )}
      </CardContent>

      <CardActions sx={{ p: 2, pt: 0, gap: 1 }}>
        <Button
          fullWidth
          variant="contained"
          onClick={() => primaryAction?.onClick?.()}
          sx={{ borderRadius: 2 }}
        >
          {primaryAction?.label || 'Open Module'}
        </Button>
        {secondaryAction && (
          <Button
            variant="outlined"
            onClick={() => secondaryAction?.onClick?.()}
            sx={{ borderRadius: 2, minWidth: 'auto', px: 2 }}
          >
            {secondaryAction.label}
          </Button>
        )}
      </CardActions>
    </Card>
  );
};

export default ModuleCard;
