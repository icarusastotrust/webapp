import React from 'react';
import { Container, Typography } from '@mui/material';

const Decorticage = () => {
  return (
    <Container>
      <Typography variant="h4">Décorticage</Typography>
      {/* Add your content here */}
    </Container>
  );
};

export default Decorticage;
