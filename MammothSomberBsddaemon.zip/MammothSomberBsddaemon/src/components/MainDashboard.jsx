import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Paper, 
  Box, 
  Button, 
  Chip,
  IconButton,
  AppBar,
  Toolbar,
  Card,
  CardContent,
  Avatar,
  LinearProgress,
  Divider,
  Badge
} from '@mui/material';
import { useAuth } from './AuthContext';
import { useNavigate } from 'react-router-dom';
import ModuleCard from './ModuleCard';
import ModuleSidebar from './ModuleSidebar';
import ProtectedRoute from './ProtectedRoute';
import TopBanner from './TopBanner';
import BottomBanner from './BottomBanner';
import NavigationBreadcrumb from './NavigationBreadcrumb';
import { 
  Analytics as AnalyticsIcon, 
  Business as BusinessIcon, 
  PrecisionManufacturing as PrecisionManufacturingIcon, 
  Logout as LogoutIcon, 
  Security as SecurityIcon,
  Dashboard as DashboardIcon,
  TrendingUp as TrendingUpIcon,
  Notifications as NotificationsIcon,
  Speed as SpeedIcon,
  Warning as WarningIcon,
  CheckCircle as CheckCircleIcon,
  Schedule as ScheduleIcon,
  Menu as MenuIcon,
  Settings as SettingsIcon,
  MenuBook as MenuBookIcon
} from '@mui/icons-material';

const MainDashboard = () => {
  const { user, userRole, logout } = useAuth();
  const navigate = useNavigate();
  const [navigationOpen, setNavigationOpen] = useState(false); // Start hidden
  const [isHovering, setIsHovering] = useState(false);
  const [bottomBannerOpen, setBottomBannerOpen] = useState(false);
  const [isHoveringBottom, setIsHoveringBottom] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleNavigationToggle = () => {
    setNavigationOpen(!navigationOpen);
  };

  const handleMouseEnterTrigger = () => {
    setIsHovering(true);
    setNavigationOpen(true);
  };

  const handleMouseLeaveTrigger = () => {
    setIsHovering(false);
    setTimeout(() => {
      if (!isHovering) {
        setNavigationOpen(false);
      }
    }, 300); // Small delay to prevent flickering
  };

  const handleMouseEnterBottomTrigger = () => {
    setIsHoveringBottom(true);
    setBottomBannerOpen(true);
  };

  const handleMouseLeaveBottomTrigger = () => {
    setIsHoveringBottom(false);
    setTimeout(() => {
      if (!isHoveringBottom) {
        setBottomBannerOpen(false);
      }
    }, 300); // Small delay to prevent flickering
  };

  const handleBottomBannerMouseLeave = () => {
    setIsHoveringBottom(false);
    setTimeout(() => {
      if (!isHoveringBottom) {
        setBottomBannerOpen(false);
      }
    }, 300);
  };

  // Module configurations
  const moduleConfigs = [
    {
      title: 'Africa Negoce Industrie',
      description: 'Commodity trading, supply chain management, and market intelligence platform',
      icon: <BusinessIcon />,
      status: 'active',
      progress: 95,
      metrics: {
        'Active Trades': '24',
        'Revenue': '$2.3M',
        'Efficiency': '98%'
      },
      primaryAction: {
        label: 'Open Trading Portal',
        onClick: () => navigate('/africa-negoce/trading')
      },
      secondaryAction: {
        label: 'Reports',
        onClick: () => navigate('/africa-negoce/financial')
      },
      badge: 'Live'
    },
    {
      title: 'Manufacturing Operations',
      description: 'End-to-end production line management with real-time monitoring and quality control',
      icon: <PrecisionManufacturingIcon />,
      status: 'warning',
      progress: 87,
      metrics: {
        'Production': '89%',
        'Quality': '96%',
        'Downtime': '2.1h'
      },
      primaryAction: {
        label: 'View Production',
        onClick: () => navigate('/magasin-matiere-premiere')
      },
      secondaryAction: {
        label: 'Analytics',
        onClick: () => navigate('/reporting-analytics')
      }
    },
    {
      title: 'Predictive Maintenance',
      description: 'AI-powered maintenance scheduling and equipment health monitoring for oil & gas operations',
      icon: <AnalyticsIcon />,
      status: 'active',
      progress: 92,
      metrics: {
        'Alerts': '5',
        'Savings': '$1.2M',
        'Uptime': '99.2%'
      },
      primaryAction: {
        label: 'View Insights',
        onClick: () => navigate('/predictive-maintenance/drilling')
      },
      secondaryAction: {
        label: 'Schedule',
        onClick: () => navigate('/predictive-maintenance/pipelines')
      },
      badge: 'AI'
    }
  ];

  const quickStats = [
    { label: 'System Health', value: '99.8%', trend: '+0.2%', color: 'success' },
    { label: 'Active Users', value: '1,247', trend: '+12%', color: 'primary' },
    { label: 'Revenue Today', value: '$89.4K', trend: '+5.8%', color: 'success' },
    { label: 'Alerts', value: '3', trend: '-2', color: 'warning' }
  ];

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', backgroundColor: '#f8fafc', position: 'relative' }}>
      <TopBanner />

      {/* Hover trigger zone for navigation */}
      <Box
        sx={{
          position: 'fixed',
          left: 0,
          top: 0,
          width: '20px',
          height: '100vh',
          zIndex: 1300,
          backgroundColor: 'transparent'
        }}
        onMouseEnter={handleMouseEnterTrigger}
      />

      {/* Hover trigger zone for bottom banner */}
      <Box
        sx={{
          position: 'fixed',
          right: 0,
          bottom: 0,
          width: '20px',
          height: '100px',
          zIndex: 1300,
          backgroundColor: 'transparent'
        }}
        onMouseEnter={handleMouseEnterBottomTrigger}
      />

      <ModuleSidebar 
        open={navigationOpen} 
        onToggle={handleNavigationToggle}
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={handleMouseLeaveTrigger}
      />

      <Box 
        component="main" 
        sx={{ 
          flexGrow: 1,
          transition: 'margin-left 0.3s ease',
          marginLeft: 0,
          width: '100%',
          minHeight: '100vh'
        }}
      >
        {/* Modern Header */}
        <AppBar 
          position="static" 
          elevation={0}
          sx={{ 
            backgroundColor: 'white',
            borderBottom: '1px solid #e0e7ff',
            color: 'text.primary',
            backdropFilter: 'blur(10px)'
          }}
        >
          <Toolbar sx={{ py: 1 }}>
            <IconButton
              onClick={handleNavigationToggle}
              sx={{ mr: 2, color: 'primary.main' }}
            >
              <MenuIcon />
            </IconButton>
            <Box sx={{ flexGrow: 1 }}>
              <Typography variant="h5" sx={{ fontWeight: 700, color: 'primary.main' }}>
                ICARUS System Portal
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button
                color="inherit"
                startIcon={<SettingsIcon />}
                onClick={() => navigate('/settings')}
                sx={{ color: 'primary.main' }}
              >
                Settings
              </Button>
              <Button
                color="inherit"
                startIcon={<MenuBookIcon />}
                onClick={() => navigate('/documentation')}
                sx={{ color: 'primary.main' }}
              >
                Docs
              </Button>
            </Box>

            <Box display="flex" alignItems="center" gap={3}>
              <Badge badgeContent={7} color="error">
                <IconButton>
                  <NotificationsIcon />
                </IconButton>
              </Badge>

              <Box display="flex" alignItems="center" gap={2}>
                <Avatar sx={{ bgcolor: 'primary.main', width: 40, height: 40 }}>
                  {user?.name?.charAt(0)}
                </Avatar>
                <Box>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                    {user?.name}
                  </Typography>
                  <Chip 
                    label={userRole} 
                    size="small" 
                    color="primary"
                    variant="outlined"
                    sx={{ height: 20, fontSize: '0.6rem' }}
                  />
                </Box>
              </Box>

              <Button 
                variant="outlined" 
                onClick={handleLogout}
                startIcon={<LogoutIcon />}
                sx={{ 
                  borderRadius: 2,
                  textTransform: 'none',
                  fontWeight: 600
                }}
              >
                Sign Out
              </Button>
            </Box>
          </Toolbar>
        </AppBar>

        <Container maxWidth="xl" sx={{ py: 4 }}>
          <NavigationBreadcrumb />

          {/* Hero Section */}
          <Card 
            sx={{ 
              mb: 4,
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              color: 'white',
              borderRadius: 3
            }}
          >
            <CardContent sx={{ p: 4 }}>
              <Grid container spacing={4} alignItems="center">
                <Grid item xs={12} md={8}>
                  <Typography variant="h3" sx={{ fontWeight: 700, mb: 2 }}>
                    Welcome back, {user?.name}
                  </Typography>
                  <Typography variant="h6" sx={{ opacity: 0.9, mb: 3 }}>
                    Monitor operations, analyze performance, and optimize workflows across all business units
                  </Typography>
                  <Box display="flex" gap={2}>
                    <Button 
                      variant="contained" 
                      size="large"
                      onClick={() => navigate('/reporting-analytics')}
                      sx={{ 
                        backgroundColor: 'white', 
                        color: 'primary.main',
                        '&:hover': { backgroundColor: 'grey.100' }
                      }}
                    >
                      View Analytics
                    </Button>
                    <Button 
                      variant="outlined" 
                      size="large"
                      onClick={() => navigate('/maintenance-equipment-database')}
                      sx={{ 
                        borderColor: 'white', 
                        color: 'white',
                        '&:hover': { backgroundColor: 'rgba(255,255,255,0.1)' }
                      }}
                    >
                      Equipment Database
                    </Button>
                  </Box>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Box textAlign="center">
                    <DashboardIcon sx={{ fontSize: 120, opacity: 0.3 }} />
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            {quickStats.map((stat, index) => (
              <Grid item xs={12} sm={6} md={3} key={index}>
                <Card sx={{ borderRadius: 3 }}>
                  <CardContent>
                    <Box display="flex" justifyContent="space-between" alignItems="center">
                      <Box>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                          {stat.label}
                        </Typography>
                        <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>
                          {stat.value}
                        </Typography>
                        <Chip 
                          label={stat.trend}
                          size="small"
                          color={stat.color}
                          variant="outlined"
                        />
                      </Box>
                      <TrendingUpIcon color={stat.color} sx={{ fontSize: 40, opacity: 0.7 }} />
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>

          <Grid container spacing={3} sx={{ mt: 4 }}>
            <Grid item xs={12}>
              <Card sx={{ 
                background: 'linear-gradient(135deg, #1976d2 0%, #42a5f5 100%)',
                color: 'white',
                textAlign: 'center',
                p: 3
              }}>
                <Typography variant="h5" gutterBottom>
                  🚁 ICARUS DaaS Portal
                </Typography>
                <Typography variant="body1" sx={{ mb: 2 }}>
                  Access our Drone as a Service platform for Military, Agriculture, Oil & Gas, and Mining applications
                </Typography>
                <Button
                  variant="contained"
                  size="large"
                  sx={{ 
                    backgroundColor: 'white', 
                    color: '#1976d2',
                    '&:hover': {
                      backgroundColor: '#f5f5f5'
                    }
                  }}
                  onClick={() => navigate('/icarus-daas')}
                >
                  Access DaaS Portal
                </Button>
              </Card>
            </Grid>
          </Grid>

          {/* Module Cards */}
          <Box mb={4}>
            <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
              Business Modules
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
              Access and manage your core business operations
            </Typography>

            <Grid container spacing={3}>
              {moduleConfigs.map((module, index) => (
                <Grid item xs={12} lg={4} key={index}>
                  {module.title === 'Manufacturing Operations' ? (
                    <ProtectedRoute allowedRoles={['admin', 'manufacturing']}>
                      <ModuleCard {...module} />
                    </ProtectedRoute>
                  ) : (
                    <ModuleCard {...module} />
                  )}
                </Grid>
              ))}
            </Grid>
          </Box>

          {/* System Status & Activity */}
          <Grid container spacing={3}>
            <Grid item xs={12} md={8}>
              <Card sx={{ borderRadius: 3 }}>
                <CardContent>
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                    Recent Activity
                  </Typography>
                  <Box display="flex" flexDirection="column" gap={2}>
                    {[
                      { time: '10 minutes ago', action: 'Production line 2 maintenance completed', status: 'success' },
                      { time: '1 hour ago', action: 'New trading order processed: $45,000', status: 'info' },
                      { time: '2 hours ago', action: 'Predictive alert: Pump maintenance required', status: 'warning' },
                      { time: '3 hours ago', action: 'Quality control check passed: Batch #1247', status: 'success' }
                    ].map((activity, index) => (
                      <Box key={index} display="flex" alignItems="center" gap={2} p={2} bgcolor="grey.50" borderRadius={2}>
                        <CheckCircleIcon color={activity.status} />
                        <Box flex={1}>
                          <Typography variant="body2" sx={{ fontWeight: 500 }}>
                            {activity.action}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {activity.time}
                          </Typography>
                        </Box>
                      </Box>
                    ))}
                  </Box>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={4}>
              <Card sx={{ borderRadius: 3 }}>
                <CardContent>
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                    System Health
                  </Typography>
                  <Box display="flex" flexDirection="column" gap={3}>
                    {[
                      { label: 'Server Uptime', value: 99.8, color: 'success' },
                      { label: 'Database Performance', value: 95.2, color: 'success' },
                      { label: 'API Response Time', value: 87.5, color: 'warning' },
                      { label: 'Storage Usage', value: 72.3, color: 'info' }
                    ].map((metric, index) => (
                      <Box key={index}>
                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                          <Typography variant="body2" color="text.secondary">
                            {metric.label}
                          </Typography>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {metric.value}%
                          </Typography>
                        </Box>
                        <LinearProgress 
                          variant="determinate" 
                          value={metric.value} 
                          color={metric.color}
                          sx={{ borderRadius: 1, height: 6 }}
                        />
                      </Box>
                    ))}
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Container>
      </Box>
      <BottomBanner 
        open={bottomBannerOpen}
        onMouseEnter={() => setIsHoveringBottom(true)}
        onMouseLeave={handleBottomBannerMouseLeave}
      />
    </Box>
  );
};

export default MainDashboard;