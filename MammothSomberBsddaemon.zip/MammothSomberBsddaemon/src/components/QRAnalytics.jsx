
import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Grid,
  Paper,
  Card,
  CardContent,
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  LinearProgress
} from '@mui/material';
import {
  QrCode,
  Scanner,
  CheckCircle,
  Cancel,
  Analytics,
  Timeline
} from '@mui/icons-material';
import AppLayout from './AppLayout';
import NavigationBreadcrumb from './NavigationBreadcrumb';
import axios from 'axios';

const API_BASE_URL = `${window.location.protocol}//${window.location.host.split(':')[0]}:5000/api`;

const QRAnalytics = () => {
  const [analytics, setAnalytics] = useState(null);
  const [scanHistory, setScanHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
    fetchScanHistory();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/qrcode/analytics`);
      setAnalytics(response.data);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchScanHistory = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/qrcode/scans`);
      setScanHistory(response.data.slice(0, 20)); // Get last 20 scans
    } catch (error) {
      console.error('Error fetching scan history:', error);
    }
  };

  if (loading) {
    return (
      <AppLayout>
        <Container>
          <LinearProgress />
          <Typography>Loading analytics...</Typography>
        </Container>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <Container maxWidth="xl" sx={{ py: 3 }}>
        <NavigationBreadcrumb />
        <Typography variant="h4" component="h1" gutterBottom>
          <Analytics sx={{ mr: 1, verticalAlign: 'middle' }} />
          QR Code Analytics & Tracking
        </Typography>

        {analytics && (
          <>
            {/* Summary Cards */}
            <Grid container spacing={3} sx={{ mb: 4 }}>
              <Grid item xs={12} sm={6} md={3}>
                <Card elevation={3}>
                  <CardContent>
                    <Box display="flex" alignItems="center">
                      <QrCode color="primary" sx={{ fontSize: 40, mr: 2 }} />
                      <Box>
                        <Typography variant="h4" color="primary">
                          {analytics.totalQRCodes}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Total QR Codes
                        </Typography>
                      </Box>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={6} md={3}>
                <Card elevation={3}>
                  <CardContent>
                    <Box display="flex" alignItems="center">
                      <CheckCircle color="success" sx={{ fontSize: 40, mr: 2 }} />
                      <Box>
                        <Typography variant="h4" color="success.main">
                          {analytics.activeQRCodes}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Active QR Codes
                        </Typography>
                      </Box>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={6} md={3}>
                <Card elevation={3}>
                  <CardContent>
                    <Box display="flex" alignItems="center">
                      <Scanner color="info" sx={{ fontSize: 40, mr: 2 }} />
                      <Box>
                        <Typography variant="h4" color="info.main">
                          {analytics.totalScans}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Total Scans
                        </Typography>
                      </Box>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={6} md={3}>
                <Card elevation={3}>
                  <CardContent>
                    <Box display="flex" alignItems="center">
                      <Cancel color="error" sx={{ fontSize: 40, mr: 2 }} />
                      <Box>
                        <Typography variant="h4" color="error.main">
                          {analytics.deactivatedQRCodes}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Deactivated
                        </Typography>
                      </Box>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            {/* Activity Summary */}
            <Grid container spacing={3} sx={{ mb: 4 }}>
              <Grid item xs={12} md={6}>
                <Card elevation={3}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Recent Activity (24h)
                    </Typography>
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="body1">
                        <strong>Scans:</strong> {analytics.recentActivity.scansLast24h}
                      </Typography>
                      <Typography variant="body1">
                        <strong>Deactivations:</strong> {analytics.recentActivity.deactivationsLast24h}
                      </Typography>
                      <Typography variant="body1">
                        <strong>Unique QRs Scanned:</strong> {analytics.uniqueScannedQRs}
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>

              <Grid item xs={12} md={6}>
                <Card elevation={3}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Scans by Process Stage
                    </Typography>
                    <Box sx={{ mt: 2 }}>
                      {Object.entries(analytics.scansByStage).map(([stage, count]) => (
                        <Box key={stage} sx={{ mb: 1 }}>
                          <Box display="flex" justifyContent="space-between">
                            <Typography variant="body2">
                              {stage.charAt(0).toUpperCase() + stage.slice(1)}
                            </Typography>
                            <Typography variant="body2">{count}</Typography>
                          </Box>
                          <LinearProgress
                            variant="determinate"
                            value={(count / analytics.totalScans) * 100}
                            sx={{ height: 6, borderRadius: 3 }}
                          />
                        </Box>
                      ))}
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            {/* Recent Scan History */}
            <Card elevation={3}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  <Timeline sx={{ mr: 1, verticalAlign: 'middle' }} />
                  Recent Scan History
                </Typography>
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>QR Code ID</TableCell>
                        <TableCell>Scanner</TableCell>
                        <TableCell>Location</TableCell>
                        <TableCell>Stage</TableCell>
                        <TableCell>Condition</TableCell>
                        <TableCell>Timestamp</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {scanHistory.map((scan, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <Typography variant="body2" fontFamily="monospace">
                              {scan.qrCodeId}
                            </Typography>
                          </TableCell>
                          <TableCell>{scan.scannedBy.name}</TableCell>
                          <TableCell>{scan.scanData.location}</TableCell>
                          <TableCell>
                            <Chip 
                              label={scan.scanData.processStage || 'N/A'} 
                              size="small" 
                              color="primary"
                            />
                          </TableCell>
                          <TableCell>
                            <Chip 
                              label={scan.scanData.batchCondition || 'N/A'} 
                              size="small" 
                              color={
                                scan.scanData.batchCondition === 'excellent' ? 'success' :
                                scan.scanData.batchCondition === 'good' ? 'info' :
                                scan.scanData.batchCondition === 'fair' ? 'warning' : 'error'
                              }
                            />
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2">
                              {new Date(scan.scanTimestamp).toLocaleString()}
                            </Typography>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          </>
        )}
      </Container>
    </AppLayout>
  );
};

export default QRAnalytics;
