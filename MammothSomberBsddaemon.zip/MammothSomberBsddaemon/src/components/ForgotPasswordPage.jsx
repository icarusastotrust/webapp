import React, { useState } from 'react';
import { Container, TextField, Button, Typography, Paper } from '@mui/material';
import { useNavigate } from 'react-router-dom';
const ForgotPasswordPage = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');

  const handleSubmit = () => {
    // Implement your forgot password logic here
    navigate('/');
  };

  return (
    <Container>
      <Paper sx={{ padding: 2.5, maxWidth: 400, margin: 'auto', marginTop: 6.25 }}>
        <Typography variant="h5">Forgot Password</Typography>
        <TextField
          fullWidth
          label="Email"
          margin="normal"
          name="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <Button variant="contained" color="primary" fullWidth onClick={handleSubmit} sx={{ marginTop: 1.25 }}>
          Submit
        </Button>
      </Paper>
    </Container>
  );
};

export default ForgotPasswordPage;
