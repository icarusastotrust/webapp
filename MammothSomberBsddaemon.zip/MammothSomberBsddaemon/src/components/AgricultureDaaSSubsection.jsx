
import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  Box,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  DialogActions,
  AppBar,
  Toolbar,
  IconButton,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  Alert,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  Agriculture as AgricultureIcon,
  Schedule as ScheduleIcon,
  LocationOn as LocationIcon,
  BugReport as BugReportIcon,
  WaterDrop as WaterIcon,
  Visibility as VisibilityIcon,
  CheckCircle as CheckCircleIcon
} from '@mui/icons-material';

const AgricultureDaaSSubsection = ({ onBack }) => {
  const [selectedDrone, setSelectedDrone] = useState(null);
  const [bookingDialog, setBookingDialog] = useState(false);
  const [selectedMission, setSelectedMission] = useState('');
  const [activeStep, setActiveStep] = useState(0);
  const [missionDetails, setMissionDetails] = useState({
    farmLocation: '',
    farmSize: '',
    cropType: '',
    pestType: '',
    sprayingArea: '',
    weatherConditions: '',
    urgencyLevel: '',
    scheduledDate: '',
    scheduledTime: '',
    additionalNotes: ''
  });
  const [flightData, setFlightData] = useState(null);
  const [prescriptionMap, setPrescriptionMap] = useState(null);
  const [operationalPhase, setOperationalPhase] = useState('planning'); // planning, scanning, processing, spraying, completed

  const missions = [
    {
      id: 'pesticide',
      name: 'PESTICIDE SPRAYING',
      icon: <BugReportIcon />,
      description: 'Targeted pesticide application for pest control',
      requirements: ['Farm coordinates', 'Pest identification', 'Chemical type', 'Weather conditions']
    },
    {
      id: 'water',
      name: 'WATER SPRAYING',
      icon: <WaterIcon />,
      description: 'Precision irrigation and water application',
      requirements: ['Irrigation zones', 'Water volume', 'Soil moisture data', 'Crop stage']
    },
    {
      id: 'mapping',
      name: 'AGRICULTURE LAND MAPPING',
      icon: <LocationIcon />,
      description: 'Comprehensive field mapping and analysis',
      requirements: ['Field boundaries', 'Resolution requirements', 'Survey objectives']
    },
    {
      id: 'pest-id',
      name: 'PEST IDENTIFICATION',
      icon: <VisibilityIcon />,
      description: 'AI-powered pest detection and identification',
      requirements: ['Crop type', 'Suspected areas', 'Image resolution', 'Analysis depth']
    },
    {
      id: 'crop-spray',
      name: 'CROPS SPRAYING MISSION',
      icon: <AgricultureIcon />,
      description: 'General crop treatment and maintenance',
      requirements: ['Treatment type', 'Application rate', 'Coverage area', 'Chemical compatibility']
    }
  ];

  const agricultureDrones = [
    {
      id: 'AGR-001',
      name: 'AgroDrone X1 Pro',
      image: '/test.png',
      specifications: {
        'Max Speed': '65 km/h',
        'Flight Time': '8 hours',
        'Payload Capacity': '40 liters',
        'Coverage Range': '50 km',
        'Max Altitude': '500 m',
        'Sensors': 'Multispectral Camera, GPS RTK',
        'Spray Width': '6 meters',
        'Tank Capacity': '40L',
        'Precision': '±2cm GPS accuracy'
      },
      capabilities: ['Pesticide Spraying', 'Water Spraying', 'Land Mapping'],
      availability: 'Available',
      cost: '$800/day',
      suitableFor: ['Small to Medium Farms', 'Precision Agriculture', 'Organic Farming']
    },
    {
      id: 'AGR-002',
      name: 'CropGuardian 5000',
      image: '/test.png',
      specifications: {
        'Max Speed': '80 km/h',
        'Flight Time': '10 hours',
        'Payload Capacity': '60 liters',
        'Coverage Range': '75 km',
        'Max Altitude': '800 m',
        'Sensors': 'NDVI Camera, Thermal Sensor, LiDAR',
        'Spray Width': '8 meters',
        'Tank Capacity': '60L',
        'Precision': '±1cm GPS accuracy'
      },
      capabilities: ['All Agriculture Missions', 'Advanced Analytics'],
      availability: 'Available',
      cost: '$1,200/day',
      suitableFor: ['Large Commercial Farms', 'Research Applications', 'High-Value Crops']
    },
    {
      id: 'AGR-003',
      name: 'PestHunter Elite',
      image: '/test.png',
      specifications: {
        'Max Speed': '70 km/h',
        'Flight Time': '6 hours',
        'Payload Capacity': '25 liters',
        'Coverage Range': '40 km',
        'Max Altitude': '300 m',
        'Sensors': 'AI Vision System, Chemical Detector, Hyperspectral',
        'Spray Width': '4 meters',
        'Tank Capacity': '25L',
        'Precision': '±1.5cm GPS accuracy'
      },
      capabilities: ['Pest Identification', 'Targeted Pesticide Application'],
      availability: 'Maintenance',
      cost: '$950/day',
      suitableFor: ['Pest Control Specialists', 'Integrated Pest Management', 'Organic Certification']
    },
    {
      id: 'AGR-004',
      name: 'AquaSpray Master',
      image: '/test.png',
      specifications: {
        'Max Speed': '55 km/h',
        'Flight Time': '12 hours',
        'Payload Capacity': '80 liters',
        'Coverage Range': '60 km',
        'Max Altitude': '400 m',
        'Sensors': 'Soil Moisture Sensor, Weather Station',
        'Spray Width': '10 meters',
        'Tank Capacity': '80L',
        'Precision': '±2cm GPS accuracy'
      },
      capabilities: ['Water Spraying', 'Irrigation Management', 'Soil Analysis'],
      availability: 'Available',
      cost: '$1,000/day',
      suitableFor: ['Irrigation Systems', 'Water Management', 'Drought Areas']
    }
  ];

  const operationalSteps = [
    {
      label: 'Mission Selection',
      description: 'Choose the type of agricultural mission required'
    },
    {
      label: 'Drone Selection',
      description: 'Select appropriate drone based on mission requirements'
    },
    {
      label: 'Farm Details',
      description: 'Provide detailed information about your farm and requirements'
    },
    {
      label: 'Flight Path Planning',
      description: 'Configure grid pattern flight path for uniform coverage'
    },
    {
      label: 'Multispectral Scanning',
      description: 'UAV performs field scan with multispectral camera'
    },
    {
      label: 'Data Processing & Prescription Map',
      description: 'GCS processes data and generates spraying prescription'
    },
    {
      label: 'Mission Execution',
      description: 'Execute precision spraying based on prescription map'
    },
    {
      label: 'Completion & Reporting',
      description: 'Mission completion and detailed report generation'
    }
  ];

  // Simulate multispectral data collection
  const simulateMultispectralScan = () => {
    const scanData = {
      ndvi: generateNDVIData(),
      swir: generateSWIRData(),
      redEdge: generateRedEdgeData(),
      lwir: generateLWIRData(),
      gpsCoordinates: generateGPSGrid(),
      timestamp: new Date().toISOString(),
      scanQuality: 'High',
      cloudCover: Math.random() * 10 // 0-10% cloud cover
    };
    setFlightData(scanData);
    return scanData;
  };

  // Generate NDVI data for crop stress identification
  const generateNDVIData = () => {
    const zones = [];
    const farmSizeHa = parseInt(missionDetails.farmSize) || 10;
    const gridSize = Math.ceil(Math.sqrt(farmSizeHa * 4)); // 0.25 ha per grid cell
    
    for (let i = 0; i < gridSize; i++) {
      for (let j = 0; j < gridSize; j++) {
        const ndviValue = 0.3 + Math.random() * 0.6; // NDVI range 0.3-0.9
        const stressLevel = ndviValue < 0.5 ? 'High' : ndviValue < 0.7 ? 'Medium' : 'Low';
        zones.push({
          gridX: i,
          gridY: j,
          ndvi: parseFloat(ndviValue.toFixed(3)),
          stressLevel,
          area: 0.25 // hectares
        });
      }
    }
    return zones;
  };

  // Generate SWIR data for moisture stress
  const generateSWIRData = () => {
    return flightData?.ndvi?.map(zone => ({
      ...zone,
      swir: 0.1 + Math.random() * 0.3,
      moistureStress: Math.random() > 0.7 ? 'Detected' : 'Normal'
    })) || [];
  };

  // Generate Red-Edge data for crop health
  const generateRedEdgeData = () => {
    return flightData?.ndvi?.map(zone => ({
      ...zone,
      redEdge: 0.15 + Math.random() * 0.25,
      chlorophyllContent: 20 + Math.random() * 40
    })) || [];
  };

  // Generate LWIR thermal data for pest detection
  const generateLWIRData = () => {
    return flightData?.ndvi?.map(zone => ({
      ...zone,
      thermalTemp: 25 + Math.random() * 15, // 25-40°C
      pestActivity: Math.random() > 0.8 ? 'Detected' : 'None',
      infestationSeverity: Math.random() > 0.8 ? ['Low', 'Medium', 'High'][Math.floor(Math.random() * 3)] : 'None'
    })) || [];
  };

  // Generate GPS coordinates grid
  const generateGPSGrid = () => {
    const baseCoords = {
      lat: -1.9441 + Math.random() * 0.1, // Kenya coordinates example
      lng: 30.0619 + Math.random() * 0.1
    };
    
    return {
      center: baseCoords,
      boundaries: [
        { lat: baseCoords.lat - 0.001, lng: baseCoords.lng - 0.001 },
        { lat: baseCoords.lat + 0.001, lng: baseCoords.lng - 0.001 },
        { lat: baseCoords.lat + 0.001, lng: baseCoords.lng + 0.001 },
        { lat: baseCoords.lat - 0.001, lng: baseCoords.lng + 0.001 }
      ]
    };
  };

  // Generate prescription map
  const generatePrescriptionMap = (scanData) => {
    const sprayingZones = [];
    const pesticidesRequired = {
      'Low': 1.5,    // L/ha
      'Medium': 2.5, // L/ha
      'High': 4.0    // L/ha
    };

    scanData.ndvi.forEach((zone, index) => {
      const lwirData = scanData.lwir?.[index];
      const pestInfestation = lwirData?.infestationSeverity || 'None';
      
      if (pestInfestation !== 'None' || zone.stressLevel === 'High') {
        sprayingZones.push({
          zoneId: `Z-${zone.gridX}-${zone.gridY}`,
          coordinates: {
            lat: scanData.gpsCoordinates.center.lat + (zone.gridX * 0.0001),
            lng: scanData.gpsCoordinates.center.lng + (zone.gridY * 0.0001)
          },
          area: zone.area,
          pesticidesVolume: pesticidesRequired[pestInfestation] || pesticidesRequired['Low'],
          priority: pestInfestation === 'High' ? 1 : pestInfestation === 'Medium' ? 2 : 3,
          treatmentType: zone.stressLevel === 'High' ? 'Stress Relief + Pest Control' : 'Pest Control',
          recommendedPesticide: getRecommendedPesticide(missionDetails.cropType, pestInfestation)
        });
      }
    });

    const totalArea = sprayingZones.reduce((sum, zone) => sum + zone.area, 0);
    const totalVolume = sprayingZones.reduce((sum, zone) => sum + (zone.pesticidesVolume * zone.area), 0);
    const flightPath = generateOptimizedFlightPath(sprayingZones);

    const prescription = {
      mapId: `PM-${Date.now()}`,
      generatedAt: new Date().toISOString(),
      totalSprayingArea: totalArea,
      totalPesticideVolume: totalVolume,
      numberOfZones: sprayingZones.length,
      sprayingZones,
      flightPath,
      estimatedFlightTime: Math.ceil(totalArea * 0.5), // 0.5 hours per hectare
      weatherRequirements: {
        maxWindSpeed: '15 km/h',
        minTemperature: '10°C',
        maxTemperature: '30°C',
        humidityRange: '40-80%'
      }
    };

    setPrescriptionMap(prescription);
    return prescription;
  };

  const getRecommendedPesticide = (cropType, severity) => {
    const pesticides = {
      'corn': {
        'Low': 'Deltamethrin 2.5% EC',
        'Medium': 'Chlorpyrifos 20% EC',
        'High': 'Bifenthrin 10% EC'
      },
      'wheat': {
        'Low': 'Lambda-cyhalothrin 5% EC',
        'Medium': 'Cypermethrin 10% EC',
        'High': 'Chlorpyrifos 20% EC'
      },
      'default': {
        'Low': 'Neem Oil 1000 ppm',
        'Medium': 'Pyrethrin 0.5% EC',
        'High': 'Malathion 50% EC'
      }
    };
    
    return pesticides[cropType]?.[severity] || pesticides['default'][severity] || 'Organic Pyrethrin';
  };

  const generateOptimizedFlightPath = (zones) => {
    // Sort zones by priority and create efficient flight path
    const sortedZones = zones.sort((a, b) => a.priority - b.priority);
    
    return {
      takeoffPoint: { lat: -1.9441, lng: 30.0619 },
      waypoints: sortedZones.map((zone, index) => ({
        waypointId: index + 1,
        coordinates: zone.coordinates,
        action: 'spray',
        sprayWidth: '6 meters',
        altitude: '15 meters',
        speed: '5 m/s',
        volume: zone.pesticidesVolume
      })),
      landingPoint: { lat: -1.9441, lng: 30.0619 },
      totalDistance: calculateFlightDistance(sortedZones),
      safetyMargins: {
        obstacleAvoidance: '50 meters',
        noFlyZones: 'Residential areas, water bodies'
      }
    };
  };

  const calculateFlightDistance = (zones) => {
    // Simplified distance calculation
    return zones.length * 0.5 + 2; // km
  };

  const handleDroneSelect = (drone) => {
    setSelectedDrone(drone);
    setBookingDialog(true);
    setActiveStep(0);
  };

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleMissionDetailChange = (field, value) => {
    setMissionDetails(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleBookingConfirm = () => {
    // Simulate booking confirmation
    const bookingData = {
      drone: selectedDrone.name,
      mission: selectedMission,
      details: missionDetails,
      cost: selectedDrone.cost,
      estimatedDuration: calculateMissionDuration(),
      bookingId: `AGR-${Date.now()}`,
      multispectralData: flightData,
      prescriptionMap: prescriptionMap,
      operationalPhases: [
        'Multispectral Field Scanning',
        'Data Processing & Analysis', 
        'Prescription Map Generation',
        'Precision Spraying Execution',
        'Mission Completion & Reporting'
      ]
    };

    const summary = prescriptionMap ? 
      `🚁 Precision Agriculture Mission Completed Successfully!\n\nBooking ID: ${bookingData.bookingId}\nDrone: ${bookingData.drone}\nMission: ${selectedMission}\nFarm: ${missionDetails.farmLocation}\n\n📊 MULTISPECTRAL SCAN RESULTS:\n• NDVI Zones Analyzed: ${flightData?.ndvi?.length || 0}\n• Crop Stress Areas Identified: ${flightData?.ndvi?.filter(z => z.stressLevel === 'High').length || 0}\n• Pest Infestations Detected: ${flightData?.lwir?.filter(z => z.pestActivity === 'Detected').length || 0}\n\n🎯 PRESCRIPTION MAP:\n• Treatment Zones: ${prescriptionMap.numberOfZones}\n• Total Area Treated: ${prescriptionMap.totalSprayingArea?.toFixed(2)} ha\n• Pesticide Volume Used: ${prescriptionMap.totalPesticideVolume?.toFixed(1)} L\n• Flight Time: ${prescriptionMap.estimatedFlightTime} hours\n\n💰 Cost: ${selectedDrone.cost}\n📅 Scheduled: ${missionDetails.scheduledDate} at ${missionDetails.scheduledTime}\n\n✅ Mission Status: COMPLETED\n📈 Treatment Effectiveness: 98.5% coverage accuracy\n📊 Detailed report and follow-up monitoring scheduled.` :
      `🚁 Agricultural Mission Booked Successfully!\n\nBooking ID: ${bookingData.bookingId}\nDrone: ${bookingData.drone}\nMission: ${selectedMission}\nFarm Location: ${missionDetails.farmLocation}\nScheduled: ${missionDetails.scheduledDate} at ${missionDetails.scheduledTime}\nEstimated Cost: ${selectedDrone.cost}\n\nOperational workflow includes:\n• Multispectral field scanning (NDVI, SWIR, Red-Edge, LWIR)\n• GPS coordinate mapping\n• Data processing & prescription map generation\n• Precision spraying execution\n• Comprehensive reporting\n\nYou will receive confirmation via email shortly.`;

    alert(summary);
    
    setBookingDialog(false);
    setSelectedDrone(null);
    setSelectedMission('');
    setActiveStep(0);
    setFlightData(null);
    setPrescriptionMap(null);
    setOperationalPhase('planning');
    setMissionDetails({
      farmLocation: '',
      farmSize: '',
      cropType: '',
      pestType: '',
      sprayingArea: '',
      weatherConditions: '',
      urgencyLevel: '',
      scheduledDate: '',
      scheduledTime: '',
      additionalNotes: ''
    });
  };

  const calculateMissionDuration = () => {
    const baseHours = selectedMission === 'mapping' ? 4 : 6;
    const sizeMultiplier = missionDetails.farmSize ? parseInt(missionDetails.farmSize) / 100 : 1;
    return Math.ceil(baseHours * sizeMultiplier);
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>Select Mission Type</Typography>
            <Grid container spacing={2}>
              {missions.map((mission) => (
                <Grid item xs={12} sm={6} key={mission.id}>
                  <Card 
                    sx={{ 
                      cursor: 'pointer',
                      border: selectedMission === mission.name ? 2 : 1,
                      borderColor: selectedMission === mission.name ? 'primary.main' : 'divider'
                    }}
                    onClick={() => setSelectedMission(mission.name)}
                  >
                    <CardContent>
                      <Box display="flex" alignItems="center" mb={1}>
                        {mission.icon}
                        <Typography variant="h6" sx={{ ml: 1 }}>
                          {mission.name}
                        </Typography>
                      </Box>
                      <Typography variant="body2" color="text.secondary">
                        {mission.description}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Box>
        );
      
      case 1:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>Farm Information</Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Farm Location (Coordinates or Address)"
                  value={missionDetails.farmLocation}
                  onChange={(e) => handleMissionDetailChange('farmLocation', e.target.value)}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Farm Size (Hectares)"
                  type="number"
                  value={missionDetails.farmSize}
                  onChange={(e) => handleMissionDetailChange('farmSize', e.target.value)}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Crop Type</InputLabel>
                  <Select
                    value={missionDetails.cropType}
                    onChange={(e) => handleMissionDetailChange('cropType', e.target.value)}
                  >
                    <MenuItem value="corn">Corn</MenuItem>
                    <MenuItem value="wheat">Wheat</MenuItem>
                    <MenuItem value="soybeans">Soybeans</MenuItem>
                    <MenuItem value="rice">Rice</MenuItem>
                    <MenuItem value="cotton">Cotton</MenuItem>
                    <MenuItem value="vegetables">Vegetables</MenuItem>
                    <MenuItem value="fruits">Fruits</MenuItem>
                    <MenuItem value="other">Other</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              {selectedMission?.includes('PEST') && (
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Pest Type (if known)"
                    value={missionDetails.pestType}
                    onChange={(e) => handleMissionDetailChange('pestType', e.target.value)}
                  />
                </Grid>
              )}
            </Grid>
          </Box>
        );
      
      case 2:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>Mission Scheduling</Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  type="date"
                  label="Preferred Date"
                  value={missionDetails.scheduledDate}
                  onChange={(e) => handleMissionDetailChange('scheduledDate', e.target.value)}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  type="time"
                  label="Preferred Time"
                  value={missionDetails.scheduledTime}
                  onChange={(e) => handleMissionDetailChange('scheduledTime', e.target.value)}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Urgency Level</InputLabel>
                  <Select
                    value={missionDetails.urgencyLevel}
                    onChange={(e) => handleMissionDetailChange('urgencyLevel', e.target.value)}
                  >
                    <MenuItem value="low">Low - Routine maintenance</MenuItem>
                    <MenuItem value="medium">Medium - Scheduled treatment</MenuItem>
                    <MenuItem value="high">High - Pest outbreak</MenuItem>
                    <MenuItem value="emergency">Emergency - Immediate action needed</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={3}
                  label="Additional Notes"
                  value={missionDetails.additionalNotes}
                  onChange={(e) => handleMissionDetailChange('additionalNotes', e.target.value)}
                />
              </Grid>
            </Grid>
          </Box>
        );
      
      case 3:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>Flight Path Planning</Typography>
            <Alert severity="info" sx={{ mb: 2 }}>
              Configure grid pattern flight path for uniform imaging coverage
            </Alert>
            
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Grid Cell Size (meters)"
                  type="number"
                  defaultValue="50"
                  helperText="Recommended: 50m for detailed analysis"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Flight Altitude (meters)"
                  type="number"
                  defaultValue="120"
                  helperText="120m provides optimal resolution"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Overlap Percentage</InputLabel>
                  <Select defaultValue="75">
                    <MenuItem value="60">60% - Standard</MenuItem>
                    <MenuItem value="75">75% - Recommended</MenuItem>
                    <MenuItem value="80">80% - High Precision</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Camera Sensors</InputLabel>
                  <Select defaultValue="all" multiple>
                    <MenuItem value="ndvi">NDVI (Crop Health)</MenuItem>
                    <MenuItem value="swir">SWIR (Moisture Stress)</MenuItem>
                    <MenuItem value="redEdge">Red-Edge (Chlorophyll)</MenuItem>
                    <MenuItem value="lwir">LWIR (Thermal/Pest Detection)</MenuItem>
                    <MenuItem value="all">All Sensors</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
            </Grid>
          </Box>
        );

      case 4:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>Multispectral Field Scanning</Typography>
            <Alert severity="success" sx={{ mb: 2 }}>
              UAV is performing full-field scan with multispectral camera
            </Alert>
            
            <Button 
              variant="contained" 
              onClick={simulateMultispectralScan}
              sx={{ mb: 2 }}
              disabled={!!flightData}
            >
              {flightData ? 'Scan Completed' : 'Start Multispectral Scan'}
            </Button>

            {flightData && (
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Paper sx={{ p: 2 }}>
                    <Typography variant="subtitle1" gutterBottom><strong>Scan Results</strong></Typography>
                    <Typography>NDVI Zones Analyzed: {flightData.ndvi?.length || 0}</Typography>
                    <Typography>Scan Quality: {flightData.scanQuality}</Typography>
                    <Typography>Cloud Cover: {flightData.cloudCover?.toFixed(1)}%</Typography>
                    <Typography>Completion Time: {new Date(flightData.timestamp).toLocaleTimeString()}</Typography>
                  </Paper>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Paper sx={{ p: 2 }}>
                    <Typography variant="subtitle1" gutterBottom><strong>Data Collected</strong></Typography>
                    <Typography>✓ NDVI (Crop Stress Identification)</Typography>
                    <Typography>✓ SWIR (Moisture Analysis)</Typography>
                    <Typography>✓ Red-Edge (Chlorophyll Content)</Typography>
                    <Typography>✓ LWIR (Pest Infestation Detection)</Typography>
                    <Typography>✓ GPS Coordinates of Affected Zones</Typography>
                  </Paper>
                </Grid>
              </Grid>
            )}
          </Box>
        );

      case 5:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>Data Processing & Prescription Map Generation</Typography>
            <Alert severity="info" sx={{ mb: 2 }}>
              Ground Control Station processes multispectral data and generates prescription map
            </Alert>
            
            {flightData && (
              <Button 
                variant="contained" 
                onClick={() => generatePrescriptionMap(flightData)}
                sx={{ mb: 2 }}
                disabled={!!prescriptionMap}
              >
                {prescriptionMap ? 'Prescription Map Generated' : 'Generate Prescription Map'}
              </Button>
            )}

            {prescriptionMap && (
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Paper sx={{ p: 2 }}>
                    <Typography variant="subtitle1" gutterBottom><strong>Prescription Summary</strong></Typography>
                    <Typography>Spraying Zones: {prescriptionMap.numberOfZones}</Typography>
                    <Typography>Total Area: {prescriptionMap.totalSprayingArea?.toFixed(2)} ha</Typography>
                    <Typography>Pesticide Volume: {prescriptionMap.totalPesticideVolume?.toFixed(1)} L</Typography>
                    <Typography>Flight Time: {prescriptionMap.estimatedFlightTime} hours</Typography>
                  </Paper>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Paper sx={{ p: 2 }}>
                    <Typography variant="subtitle1" gutterBottom><strong>Flight Path</strong></Typography>
                    <Typography>Waypoints: {prescriptionMap.flightPath?.waypoints?.length || 0}</Typography>
                    <Typography>Total Distance: {prescriptionMap.flightPath?.totalDistance?.toFixed(1)} km</Typography>
                    <Typography>Spray Width: 6 meters</Typography>
                    <Typography>Flight Speed: 5 m/s</Typography>
                  </Paper>
                </Grid>
              </Grid>
            )}
          </Box>
        );

      case 6:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>Pre-Flight Setup & Mission Execution</Typography>
            
            {/* Pre-Flight Setup */}
            <Paper sx={{ p: 2, mb: 3 }}>
              <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 'bold' }}>
                📋 Pre-Flight Setup Phase
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Box sx={{ p: 2, border: '1px solid #ddd', borderRadius: 1 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      ✅ Prescription Map Loading
                    </Typography>
                    <Typography variant="body2">
                      • UAV loaded with pre-configured prescription map from Phase 1
                    </Typography>
                    <Typography variant="body2">
                      • Flight path waypoints: {prescriptionMap?.flightPath?.waypoints?.length || 0}
                    </Typography>
                    <Typography variant="body2">
                      • Total treatment zones: {prescriptionMap?.numberOfZones || 0}
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Box sx={{ p: 2, border: '1px solid #ddd', borderRadius: 1 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      ⛽ Tank Filling & Calibration
                    </Typography>
                    <Typography variant="body2">
                      • Initial tank volume: {prescriptionMap?.totalPesticideVolume?.toFixed(1) || 0} L
                    </Typography>
                    <Typography variant="body2">
                      • Pesticide type: {prescriptionMap?.sprayingZones?.[0]?.recommendedPesticide || 'N/A'}
                    </Typography>
                    <Typography variant="body2">
                      • Flow rate sensor calibrated: ±0.1 L/min accuracy
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </Paper>

            {/* Flight Execution Monitoring */}
            <Paper sx={{ p: 2, mb: 3 }}>
              <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 'bold' }}>
                🚁 Real-Time Flight Execution Monitoring
              </Typography>
              
              <Grid container spacing={2}>
                <Grid item xs={12} md={8}>
                  <TableContainer component={Paper} variant="outlined">
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell>Zone ID</TableCell>
                          <TableCell>Status</TableCell>
                          <TableCell>VRN Rate (L/ha)</TableCell>
                          <TableCell>Consumed (L)</TableCell>
                          <TableCell>Coverage %</TableCell>
                          <TableCell>Flow Rate</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {prescriptionMap?.sprayingZones?.slice(0, 5).map((zone, index) => {
                          const status = index < 2 ? 'Completed' : index === 2 ? 'Active' : 'Pending';
                          const coverage = index < 2 ? 100 : index === 2 ? 65 : 0;
                          const flowRate = index === 2 ? '2.3 L/min' : index < 2 ? 'Completed' : '-';
                          
                          return (
                            <TableRow key={zone.zoneId}>
                              <TableCell>{zone.zoneId}</TableCell>
                              <TableCell>
                                <Chip 
                                  label={status}
                                  color={status === 'Completed' ? 'success' : status === 'Active' ? 'warning' : 'default'}
                                  size="small"
                                />
                              </TableCell>
                              <TableCell>{zone.pesticidesVolume}</TableCell>
                              <TableCell>{(zone.pesticidesVolume * zone.area * (coverage / 100)).toFixed(1)}</TableCell>
                              <TableCell>{coverage}%</TableCell>
                              <TableCell>{flowRate}</TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Grid>
                
                <Grid item xs={12} md={4}>
                  <Box sx={{ p: 2, border: '1px solid #ddd', borderRadius: 1, mb: 2 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      📊 Real-Time Monitoring
                    </Typography>
                    <Typography variant="body2">
                      • Current flow rate: 2.3 L/min
                    </Typography>
                    <Typography variant="body2">
                      • UAV speed: 5.2 m/s
                    </Typography>
                    <Typography variant="body2">
                      • Altitude: 15.0 m AGL
                    </Typography>
                    <Typography variant="body2">
                      • Wind speed: 8 km/h
                    </Typography>
                  </Box>
                  
                  <Box sx={{ p: 2, border: '1px solid #ddd', borderRadius: 1 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      🎯 Variable-Rate Nozzles (VRN)
                    </Typography>
                    <Typography variant="body2">
                      • Dynamic adjustment: Active
                    </Typography>
                    <Typography variant="body2">
                      • Spray width: 6.0 meters
                    </Typography>
                    <Typography variant="body2">
                      • Nozzle pressure: 3.2 bar
                    </Typography>
                    <Typography variant="body2">
                      • Droplet size: 250 μm VMD
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </Paper>

            {/* End of Flight Summary */}
            <Paper sx={{ p: 2 }}>
              <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 'bold' }}>
                📈 End of Spraying Flight Summary
              </Typography>
              
              <Grid container spacing={2}>
                <Grid item xs={12} md={4}>
                  <Box sx={{ p: 2, backgroundColor: '#f0f8ff', borderRadius: 1 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      Tank Volume Analysis
                    </Typography>
                    <Typography variant="body2">
                      • Initial volume: {prescriptionMap?.totalPesticideVolume?.toFixed(1) || 0} L
                    </Typography>
                    <Typography variant="body2">
                      • Remaining volume: {((prescriptionMap?.totalPesticideVolume || 0) * 0.05).toFixed(1)} L
                    </Typography>
                    <Typography variant="body2">
                      • Consumed volume: {((prescriptionMap?.totalPesticideVolume || 0) * 0.95).toFixed(1)} L
                    </Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold', color: 'green' }}>
                      • Efficiency: 95% usage rate
                    </Typography>
                  </Box>
                </Grid>
                
                <Grid item xs={12} md={4}>
                  <Box sx={{ p: 2, backgroundColor: '#f8f8f0', borderRadius: 1 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      Consumption Metrics
                    </Typography>
                    <Typography variant="body2">
                      • Average rate: {(prescriptionMap?.totalPesticideVolume || 0 / prescriptionMap?.totalSprayingArea || 1).toFixed(1)} L/ha
                    </Typography>
                    <Typography variant="body2">
                      • Total area covered: {prescriptionMap?.totalSprayingArea?.toFixed(2) || 0} ha
                    </Typography>
                    <Typography variant="body2">
                      • Flight duration: {prescriptionMap?.estimatedFlightTime || 0} hours
                    </Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold', color: 'blue' }}>
                      • Precision accuracy: 98.7%
                    </Typography>
                  </Box>
                </Grid>
                
                <Grid item xs={12} md={4}>
                  <Box sx={{ p: 2, backgroundColor: '#f0f8f0', borderRadius: 1 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      GCS Data Tracking
                    </Typography>
                    <Typography variant="body2">
                      • Data points collected: 1,247
                    </Typography>
                    <Typography variant="body2">
                      • Flow variations detected: 12
                    </Typography>
                    <Typography variant="body2">
                      • Speed adjustments: 8
                    </Typography>
                    <Typography variant="body2" sx={{ fontWeight: 'bold', color: 'purple' }}>
                      • Real-time sync: 100%
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </Paper>

            {/* Weather Requirements Check */}
            <Paper sx={{ p: 2, mt: 2 }}>
              <Typography variant="subtitle1" gutterBottom><strong>Weather Compliance Status</strong></Typography>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography>Max Wind Speed: {prescriptionMap?.weatherRequirements?.maxWindSpeed || '15 km/h'} ✅</Typography>
                  <Typography>Temperature Range: {prescriptionMap?.weatherRequirements?.minTemperature || '10°C'} - {prescriptionMap?.weatherRequirements?.maxTemperature || '30°C'} ✅</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography>Humidity Range: {prescriptionMap?.weatherRequirements?.humidityRange || '40-80%'} ✅</Typography>
                  <Typography>Current conditions: Optimal for spraying ✅</Typography>
                </Grid>
              </Grid>
            </Paper>
          </Box>
        );

      case 7:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>Mission Completion & Reporting</Typography>
            <Alert severity="success" sx={{ mb: 2 }}>
              Mission completed successfully! Comprehensive report generated.
            </Alert>
            
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Paper sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom><strong>Mission Summary</strong></Typography>
                  <Typography>Drone: {selectedDrone?.name}</Typography>
                  <Typography>Mission: {selectedMission}</Typography>
                  <Typography>Farm: {missionDetails.farmLocation}</Typography>
                  <Typography>Total Area Treated: {prescriptionMap?.totalSprayingArea?.toFixed(2) || 0} ha</Typography>
                  <Typography>Pesticide Used: {prescriptionMap?.totalPesticideVolume?.toFixed(1) || 0} L</Typography>
                </Paper>
              </Grid>
              <Grid item xs={12} md={6}>
                <Paper sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom><strong>Effectiveness Metrics</strong></Typography>
                  <Typography>Coverage Accuracy: 98.5%</Typography>
                  <Typography>Application Rate Precision: ±2%</Typography>
                  <Typography>Zones Treated: {prescriptionMap?.numberOfZones || 0}</Typography>
                  <Typography>Cost Efficiency: 35% savings vs traditional</Typography>
                </Paper>
              </Grid>
              <Grid item xs={12}>
                <Paper sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom><strong>Next Steps</strong></Typography>
                  <List>
                    <ListItem>
                      <ListItemIcon><CheckCircleIcon color="success" /></ListItemIcon>
                      <ListItemText primary="Follow-up monitoring scheduled in 7 days" />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon><CheckCircleIcon color="success" /></ListItemIcon>
                      <ListItemText primary="Detailed report sent to farm management" />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon><CheckCircleIcon color="success" /></ListItemIcon>
                      <ListItemText primary="Treatment effectiveness tracking initiated" />
                    </ListItem>
                  </List>
                </Paper>
              </Grid>
            </Grid>
          </Box>
        );
      
      default:
        return null;
    }
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static" sx={{ backgroundColor: '#228B22' }}>
        <Toolbar>
          <IconButton
            edge="start"
            color="inherit"
            onClick={onBack}
          >
            <ArrowBackIcon />
          </IconButton>
          <AgricultureIcon sx={{ mr: 2 }} />
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Agriculture DaaS - Precision Farming Solutions
          </Typography>
        </Toolbar>
      </AppBar>
      
      <Container maxWidth="xl" sx={{ mt: 4 }}>
        <Typography variant="h4" gutterBottom sx={{ textAlign: 'center', mb: 2 }}>
          Agricultural Drone Services
        </Typography>
        
        <Typography variant="body1" sx={{ textAlign: 'center', mb: 4, color: 'text.secondary' }}>
          Advanced drone solutions for modern agriculture - from pest control to precision mapping
        </Typography>

        {/* Mission Types Overview */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h5" gutterBottom>Available Missions</Typography>
          <Grid container spacing={2}>
            {missions.map((mission) => (
              <Grid item xs={12} md={4} lg={2.4} key={mission.id}>
                <Card sx={{ textAlign: 'center', p: 2 }}>
                  {mission.icon}
                  <Typography variant="subtitle2" sx={{ mt: 1 }}>
                    {mission.name}
                  </Typography>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Box>

        <Divider sx={{ my: 4 }} />

        {/* Drone Fleet */}
        <Typography variant="h5" gutterBottom>Agricultural Drone Fleet</Typography>
        <Grid container spacing={3}>
          {agricultureDrones.map((drone) => (
            <Grid item xs={12} md={6} lg={4} key={drone.id}>
              <Card sx={{ height: '100%' }}>
                <CardMedia
                  component="img"
                  height="200"
                  image={drone.image}
                  alt={drone.name}
                  sx={{ cursor: 'pointer' }}
                  onClick={() => handleDroneSelect(drone)}
                />
                <CardContent>
                  <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                    <Typography variant="h6">{drone.name}</Typography>
                    <Chip
                      label={drone.availability}
                      color={drone.availability === 'Available' ? 'success' : 'warning'}
                      size="small"
                    />
                  </Box>
                  
                  <Typography variant="h6" color="primary" sx={{ mb: 2 }}>
                    {drone.cost}
                  </Typography>

                  <Box sx={{ mb: 2 }}>
                    <Typography variant="subtitle2" gutterBottom>Capabilities:</Typography>
                    {drone.capabilities.map((capability, index) => (
                      <Chip
                        key={index}
                        label={capability}
                        size="small"
                        sx={{ mr: 0.5, mb: 0.5 }}
                      />
                    ))}
                  </Box>

                  <Box sx={{ mb: 2 }}>
                    <Typography variant="subtitle2" gutterBottom>Suitable For:</Typography>
                    {drone.suitableFor.map((use, index) => (
                      <Typography key={index} variant="caption" display="block">
                        • {use}
                      </Typography>
                    ))}
                  </Box>
                  
                  <TableContainer component={Paper} variant="outlined" sx={{ mb: 2 }}>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell><strong>Specification</strong></TableCell>
                          <TableCell><strong>Value</strong></TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {Object.entries(drone.specifications).slice(0, 6).map(([key, value]) => (
                          <TableRow key={key}>
                            <TableCell>{key}</TableCell>
                            <TableCell>{value}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                  
                  <Button
                    fullWidth
                    variant="contained"
                    onClick={() => handleDroneSelect(drone)}
                    disabled={drone.availability !== 'Available'}
                    sx={{ backgroundColor: '#228B22' }}
                  >
                    Book This Drone
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Advanced Booking Dialog */}
      <Dialog open={bookingDialog} onClose={() => setBookingDialog(false)} maxWidth="lg" fullWidth>
        <DialogTitle>
          <Box display="flex" alignItems="center">
            <AgricultureIcon sx={{ mr: 1 }} />
            Agricultural Mission Booking: {selectedDrone?.name}
          </Box>
        </DialogTitle>
        <DialogContent>
          <Stepper activeStep={activeStep} orientation="vertical">
            {operationalSteps.map((step, index) => (
              <Step key={step.label}>
                <StepLabel>
                  <Typography variant="h6">{step.label}</Typography>
                </StepLabel>
                <StepContent>
                  <Typography sx={{ mb: 2 }}>{step.description}</Typography>
                  {renderStepContent(index)}
                  <Box sx={{ mb: 2, mt: 2 }}>
                    <div>
                      <Button
                        variant="contained"
                        onClick={index === operationalSteps.length - 1 ? handleBookingConfirm : handleNext}
                        sx={{ mt: 1, mr: 1 }}
                        disabled={
                          (index === 0 && !selectedMission) ||
                          (index === 1 && (!missionDetails.farmLocation || !missionDetails.farmSize || !missionDetails.cropType)) ||
                          (index === 2 && (!missionDetails.scheduledDate || !missionDetails.scheduledTime))
                        }
                      >
                        {index === operationalSteps.length - 1 ? 'Confirm Booking' : 'Continue'}
                      </Button>
                      <Button
                        disabled={index === 0}
                        onClick={handleBack}
                        sx={{ mt: 1, mr: 1 }}
                      >
                        Back
                      </Button>
                    </div>
                  </Box>
                </StepContent>
              </Step>
            ))}
          </Stepper>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setBookingDialog(false)}>Cancel</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AgricultureDaaSSubsection;
