
import React, { useState } from 'react';
import {
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Collapse,
  Typography,
  Box,
  Divider,
  IconButton
} from '@mui/material';
import {
  Dashboard as DashboardIcon,
  Business as BusinessIcon,
  Analytics as AnalyticsIcon,
  PrecisionManufacturing as ManufacturingIcon,
  ExpandLess,
  ExpandMore,
  ChevronLeft as ChevronLeftIcon,
  Menu as MenuIcon
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';

const NavigationPanel = ({ open, onToggle, onMouseEnter, onMouseLeave }) => {
  const [expandedSections, setExpandedSections] = useState({
    africaNegoce: false,
    predictiveMaintenance: false,
    manufacturing: false
  });
  
  const navigate = useNavigate();
  const location = useLocation();
  const { canAccessManufacturing, canAccessPredictiveMaintenance, canAccessAfricaNegoce } = useAuth();

  const handleExpand = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const isActive = (path) => location.pathname === path;
  const isParentActive = (basePath) => location.pathname.startsWith(basePath);

  const navigationSections = [
    {
      id: 'dashboard',
      title: 'Main Dashboard',
      icon: <DashboardIcon />,
      path: '/main-dashboard',
      requiresAccess: () => true
    },
    {
      id: 'africaNegoce',
      title: 'Africa Negoce Industrie',
      icon: <BusinessIcon />,
      requiresAccess: canAccessAfricaNegoce,
      expandable: true,
      children: [
        { title: 'Trading Operations', path: '/africa-negoce/trading' },
        { title: 'Supply Chain', path: '/africa-negoce/supply-chain' },
        { title: 'Inventory Management', path: '/africa-negoce/inventory' },
        { title: 'Financial Analytics', path: '/africa-negoce/financial' },
        { title: 'Market Intelligence', path: '/africa-negoce/market' },
        { title: 'Client Portal', path: '/africa-negoce/clients' }
      ]
    },
    {
      id: 'manufacturing',
      title: 'Manufacturing Operations',
      icon: <ManufacturingIcon />,
      requiresAccess: canAccessManufacturing,
      expandable: true,
      children: [
        { title: 'Raw Materials', path: '/magasin-matiere-premiere' },
        { title: 'Fragilisation', path: '/fragilisation' },
        { title: 'Decorticage', path: '/decorticage' },
        { title: 'Sechage', path: '/sechage' },
        { title: 'Depelliculage', path: '/depelliculage' },
        { title: 'Classification', path: '/classification-epuration' },
        { title: 'Packaging', path: '/emballage-produits-fini' },
        { title: 'Maintenance', path: '/maintenance-scheduling' },
        { title: 'Analytics', path: '/reporting-analytics' }
      ]
    },
    {
      id: 'predictiveMaintenance',
      title: 'Predictive Maintenance',
      icon: <AnalyticsIcon />,
      requiresAccess: canAccessPredictiveMaintenance,
      expandable: true,
      children: [
        { title: 'Drilling Equipment', path: '/predictive-maintenance/drilling' },
        { title: 'Pumping Systems', path: '/predictive-maintenance/pumps' },
        { title: 'Pipeline Systems', path: '/predictive-maintenance/pipelines' },
        { title: 'Compressors', path: '/predictive-maintenance/compressors' },
        { title: 'Turbines', path: '/predictive-maintenance/turbines' },
        { title: 'Heat Exchangers', path: '/predictive-maintenance/heat-exchangers' },
        { title: 'Separators', path: '/predictive-maintenance/separators' },
        { title: 'Valves & Controls', path: '/predictive-maintenance/valves' }
      ]
    }
  ];

  const drawerWidth = 280;

  return (
    <Drawer
      variant="temporary"
      anchor="left"
      open={open}
      onClose={onToggle}
      sx={{
        width: open ? drawerWidth : 0,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: drawerWidth,
          boxSizing: 'border-box',
          backgroundColor: '#f8f9fa',
          borderRight: '1px solid #e1e5e9',
          zIndex: 1200
        },
      }}
      PaperProps={{
        onMouseEnter: onMouseEnter,
        onMouseLeave: onMouseLeave
      }}
    >
      <Box sx={{ 
        display: 'flex', 
        alignItems: 'center', 
        padding: '12px 16px',
        backgroundColor: '#0078d4',
        color: 'white'
      }}>
        <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: 600 }}>
          ICARUS System
        </Typography>
        <IconButton 
          onClick={onToggle}
          sx={{ color: 'white' }}
        >
          <ChevronLeftIcon />
        </IconButton>
      </Box>
      
      <Divider />
      
      <List sx={{ padding: 0 }}>
        {navigationSections.map((section) => {
          if (!section.requiresAccess()) return null;
          
          const isExpanded = expandedSections[section.id];
          const hasActiveChild = section.children?.some(child => isActive(child.path));
          
          return (
            <Box key={section.id}>
              <ListItem disablePadding>
                <ListItemButton
                  onClick={() => {
                    if (section.expandable) {
                      handleExpand(section.id);
                    } else {
                      navigate(section.path);
                    }
                  }}
                  sx={{
                    backgroundColor: (isActive(section.path) || hasActiveChild) ? '#e3f2fd' : 'transparent',
                    borderLeft: (isActive(section.path) || hasActiveChild) ? '3px solid #0078d4' : 'none',
                    '&:hover': {
                      backgroundColor: '#f5f5f5'
                    }
                  }}
                >
                  <ListItemIcon sx={{ 
                    color: (isActive(section.path) || hasActiveChild) ? '#0078d4' : '#666',
                    minWidth: 40
                  }}>
                    {section.icon}
                  </ListItemIcon>
                  <ListItemText 
                    primary={section.title}
                    primaryTypographyProps={{
                      fontSize: '14px',
                      fontWeight: (isActive(section.path) || hasActiveChild) ? 600 : 400,
                      color: (isActive(section.path) || hasActiveChild) ? '#0078d4' : '#323130'
                    }}
                  />
                  {section.expandable && (
                    isExpanded ? <ExpandLess /> : <ExpandMore />
                  )}
                </ListItemButton>
              </ListItem>
              
              {section.expandable && (
                <Collapse in={isExpanded} timeout="auto" unmountOnExit>
                  <List component="div" disablePadding>
                    {section.children?.map((child) => (
                      <ListItem key={child.path} disablePadding>
                        <ListItemButton
                          onClick={() => navigate(child.path)}
                          sx={{
                            pl: 6,
                            backgroundColor: isActive(child.path) ? '#e3f2fd' : 'transparent',
                            borderLeft: isActive(child.path) ? '3px solid #0078d4' : 'none',
                            '&:hover': {
                              backgroundColor: '#f5f5f5'
                            }
                          }}
                        >
                          <ListItemText
                            primary={child.title}
                            primaryTypographyProps={{
                              fontSize: '13px',
                              fontWeight: isActive(child.path) ? 600 : 400,
                              color: isActive(child.path) ? '#0078d4' : '#605e5c'
                            }}
                          />
                        </ListItemButton>
                      </ListItem>
                    ))}
                  </List>
                </Collapse>
              )}
            </Box>
          );
        })}
      </List>
    </Drawer>
  );
};

export default NavigationPanel;
