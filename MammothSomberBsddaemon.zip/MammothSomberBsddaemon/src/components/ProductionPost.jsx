import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';

const ProductionPost = ({ title, description }) => {
  return (
    <Card style={{ margin: '20px', padding: '10px' }}>
      <CardContent>
        <Typography variant="h5" component="h2">
          {title}
        </Typography>
        <Typography color="textSecondary">
          {description}
        </Typography>
      </CardContent>
    </Card>
  );
};

export default ProductionPost;
