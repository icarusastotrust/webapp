
import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState(null);

  // Define user roles and their permissions
  const USER_ROLES = {
    ADMIN: 'admin',
    MANUFACTURING_MANAGER: 'manufacturing_manager',
    OPERATOR: 'operator',
    GUEST: 'guest'
  };

  const ROLE_PERMISSIONS = {
    [USER_ROLES.ADMIN]: ['all'],
    [USER_ROLES.MANUFACTURING_MANAGER]: ['manufacturing', 'predictive_maintenance', 'africa_negoce'],
    [USER_ROLES.OPERATOR]: ['manufacturing'],
    [USER_ROLES.GUEST]: ['africa_negoce']
  };

  useEffect(() => {
    // Check if user is already logged in (from localStorage)
    const savedUser = localStorage.getItem('icarus_user');
    const savedRole = localStorage.getItem('icarus_user_role');
    
    if (savedUser && savedRole) {
      setUser(JSON.parse(savedUser));
      setUserRole(savedRole);
      setIsAuthenticated(true);
    }
  }, []);

  const login = async (credentials) => {
    try {
      // Simulate authentication with predefined users
      const validUsers = {
        'admin@icarus.com': { 
          password: 'admin123', 
          role: USER_ROLES.ADMIN,
          name: 'System Administrator',
          department: 'IT Security'
        },
        'manager@icarus.com': { 
          password: 'manager123', 
          role: USER_ROLES.MANUFACTURING_MANAGER,
          name: 'Manufacturing Manager',
          department: 'Production'
        },
        'operator@icarus.com': { 
          password: 'operator123', 
          role: USER_ROLES.OPERATOR,
          name: 'Production Operator',
          department: 'Manufacturing'
        },
        'guest@icarus.com': { 
          password: 'guest123', 
          role: USER_ROLES.GUEST,
          name: 'Guest User',
          department: 'External'
        },
        // Additional test accounts for testers
        'tester1@icarus.com': { 
          password: 'test123', 
          role: USER_ROLES.ADMIN,
          name: 'Test User 1',
          department: 'QA Testing'
        },
        'tester2@icarus.com': { 
          password: 'test123', 
          role: USER_ROLES.MANUFACTURING_MANAGER,
          name: 'Test User 2',
          department: 'QA Testing'
        },
        'tester3@icarus.com': { 
          password: 'test123', 
          role: USER_ROLES.OPERATOR,
          name: 'Test User 3',
          department: 'QA Testing'
        },
        'demo@icarus.com': { 
          password: 'demo123', 
          role: USER_ROLES.ADMIN,
          name: 'Demo Account',
          department: 'Demonstration'
        }
      };

      const userAccount = validUsers[credentials.email];
      
      if (!userAccount || userAccount.password !== credentials.password) {
        throw new Error('Invalid email or password');
      }

      const userData = {
        email: credentials.email,
        name: userAccount.name,
        department: userAccount.department,
        loginTime: new Date().toISOString()
      };

      setUser(userData);
      setUserRole(userAccount.role);
      setIsAuthenticated(true);

      // Save to localStorage
      localStorage.setItem('icarus_user', JSON.stringify(userData));
      localStorage.setItem('icarus_user_role', userAccount.role);

      return { success: true, user: userData, role: userAccount.role };
    } catch (error) {
      throw new Error(error.message);
    }
  };

  const logout = () => {
    setUser(null);
    setUserRole(null);
    setIsAuthenticated(false);
    localStorage.removeItem('icarus_user');
    localStorage.removeItem('icarus_user_role');
  };

  const hasPermission = (requiredPermission) => {
    if (!userRole) return false;
    
    const userPermissions = ROLE_PERMISSIONS[userRole] || [];
    return userPermissions.includes('all') || userPermissions.includes(requiredPermission);
  };

  const canAccessManufacturing = () => {
    return hasPermission('manufacturing') || hasPermission('all');
  };

  const canAccessPredictiveMaintenance = () => {
    return hasPermission('predictive_maintenance') || hasPermission('all');
  };

  const canAccessAfricaNegoce = () => {
    return hasPermission('africa_negoce') || hasPermission('all');
  };

  const value = {
    user,
    userRole,
    isAuthenticated,
    USER_ROLES,
    login,
    logout,
    hasPermission,
    canAccessManufacturing,
    canAccessPredictiveMaintenance,
    canAccessAfricaNegoce
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
