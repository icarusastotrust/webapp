import React, { useState } from 'react';
import { Container, Typography, Grid, TextField, Button, Paper, List, ListItem, ListItemText } from '@mui/material';
import { LocalizationProvider, DateTimePicker } from '@mui/lab';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import { format } from 'date-fns';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';

const localizer = momentLocalizer(moment);

const MaintenanceScheduling = () => {
  const [formData, setFormData] = useState({
    machine: '',
    description: '',
    date: new Date(),
  });

  const [events, setEvents] = useState([]);
  const [upcomingTasks, setUpcomingTasks] = useState([]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleDateChange = (date) => {
    setFormData({ ...formData, date });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newEvent = {
      title: formData.machine,
      start: formData.date,
      end: formData.date,
      allDay: true,
      description: formData.description,
    };
    setEvents([...events, newEvent]);
    setUpcomingTasks([...upcomingTasks, newEvent]);
    setFormData({
      machine: '',
      description: '',
      date: new Date(),
    });
  };

  return (
    <Container component="main" maxWidth="lg">
      <Typography variant="h4" component="h1" gutterBottom>
        Maintenance Scheduling
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Paper style={{ padding: '20px' }}>
            <Typography variant="h6" component="h2" gutterBottom>
              Schedule Maintenance
            </Typography>
            <form onSubmit={handleSubmit}>
              <TextField
                name="machine"
                label="Machine"
                fullWidth
                variant="outlined"
                margin="normal"
                value={formData.machine}
                onChange={handleChange}
              />
              <TextField
                name="description"
                label="Description"
                fullWidth
                variant="outlined"
                margin="normal"
                value={formData.description}
                onChange={handleChange}
              />
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DateTimePicker
                  label="Maintenance Date & Time"
                  value={formData.date}
                  onChange={handleDateChange}
                  renderInput={(props) => <TextField {...props} fullWidth variant="outlined" margin="normal" />}
                />
              </LocalizationProvider>
              <Button type="submit" variant="contained" color="primary" fullWidth>
                Schedule
              </Button>
            </form>
          </Paper>
        </Grid>
        <Grid item xs={12} md={8}>
          <Paper style={{ padding: '20px' }}>
            <Typography variant="h6" component="h2" gutterBottom>
              Upcoming Maintenance Tasks
            </Typography>
            <List>
              {upcomingTasks.map((task, index) => (
                <ListItem key={index}>
                  <ListItemText
                    primary={`${task.title} - ${format(new Date(task.start), 'dd/MM/yyyy HH:mm')}`}
                    secondary={task.description}
                  />
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>
        <Grid item xs={12}>
          <Paper style={{ padding: '20px' }}>
            <Typography variant="h6" component="h2" gutterBottom>
              Maintenance Calendar
            </Typography>
            <Calendar
              localizer={localizer}
              events={events}
              startAccessor="start"
              endAccessor="end"
              style={{ height: 500 }}
            />
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default MaintenanceScheduling;
