import React from 'react';
import { Container, Typography, Grid, Tabs, Tab, Box } from '@mui/material';
import { Link, Route, Routes } from 'react-router-dom';
import MaintenanceDashboard from './MaintenanceDashboard';
import ProductionLinePerformance from './ProductionLinePerformance';
import PerformanceQuality from './PerformanceQuality';
import MaintenanceScheduling from './MaintenanceScheduling';
import ReportingAnalytics from './ReportingAnalytics';
import MagasinMatierePremiere from './MagasinMatierePremiere';
import QRCodeScanner from './QRCodeScanner';
import QRAnalytics from './QRAnalytics';
import DashboardSection from './DashboardSection'; 
import SectionButton from './SectionButton';
import BuildIcon from '@mui/icons-material/Build'; // Example icon, add more as needed

const mainSections = [
  { icon: <BuildIcon />, title: 'APPROVISIONNEUR', subtitle: 'Supply Management', link: '/dashboard/approvisionneur' },
  { icon: <BuildIcon />, title: 'MAGASIN MATIÈRE PREMIÈRE-CONTRE/TEST QUALITÉ', subtitle: 'Raw Material Testing', link: '/dashboard/magasin-matiere-premiere' },
  { icon: <BuildIcon />, title: 'FRAGILISATION', subtitle: 'Fragilization', link: '/dashboard/fragilisation' },
  { icon: <BuildIcon />, title: 'DÉCORTICAGE', subtitle: 'Shelling', link: '/dashboard/decorticage' },
  { icon: <BuildIcon />, title: 'SÉCHAGE', subtitle: 'Drying', link: '/dashboard/sechage' },
  { icon: <BuildIcon />, title: 'DÉPELLICULAGE', subtitle: 'Peeling', link: '/dashboard/depelliculage' },
  { icon: <BuildIcon />, title: 'CLASSIFICATION+ÉPURATION', subtitle: 'Classification and Purification', link: '/dashboard/classification-epuration' },
  { icon: <BuildIcon />, title: 'EMBALLAGE PRODUITS FINI', subtitle: 'Finished Product Packaging', link: '/dashboard/emballage-produits-fini' },
];

const Dashboard = () => {
  return (
    <Container>
      <Typography variant="h4" component="h1" gutterBottom>
        Traceability Dashboard
      </Typography>
      <Tabs>
        <Tab label="Main Dashboard" component={Link} to="/dashboard" />
        <Tab label="Machinery Maintenance" component={Link} to="/dashboard/maintenance" />
        <Tab label="Production Line Performance" component={Link} to="/dashboard/production-line-performance" />
      </Tabs>
      <Box mt={3}>
        <Routes>
          <Route path="/" element={<MainDashboard />} />
          <Route path="maintenance" element={<MaintenanceDashboard />} />
          <Route path="maintenance-scheduling" element={<MaintenanceScheduling />} />
          <Route path="reporting-analytics" element={<ReportingAnalytics />} />
          <Route path="production-line-performance" element={<ProductionLinePerformance />} />
          <Route path="performance-quality" element={<PerformanceQuality />} />
          <Route path="approvisionneur" element={<DashboardSection name="APPROVISIONNEUR" />} />
          <Route path="magasin-matiere-premiere" element={<MagasinMatierePremiere />} />
          <Route path="qr-scanner" element={<QRCodeScanner />} />
          <Route path="qr-analytics" element={<QRAnalytics />} />
          <Route path="fragilisation" element={<DashboardSection name="FRAGILISATION" />} />
          <Route path="decorticage" element={<DashboardSection name="DÉCORTICAGE" />} />
          <Route path="sechage" element={<DashboardSection name="SÉCHAGE" />} />
          <Route path="depelliculage" element={<DashboardSection name="DÉPELLICULAGE" />} />
          <Route path="classification-epuration" element={<DashboardSection name="CLASSIFICATION+ÉPURATION" />} />
          <Route path="emballage-produits-fini" element={<DashboardSection name="EMBALLAGE PRODUITS FINI" />} />
          <Route path="predictive-maintenance" element={<DashboardSection name="Predictive Maintenance" />} />
          <Route path="maintenance-scheduling" element={<DashboardSection name="Maintenance Scheduling" />} />
          <Route path="alert-system" element={<DashboardSection name="Alert System" />} />
          <Route path="maintenance-records" element={<DashboardSection name="Maintenance Records" />} />
          <Route path="reporting-analytics" element={<DashboardSection name="Reporting & Analytics" />} />
          <Route path="user-management" element={<DashboardSection name="User Management" />} />
          <Route path="iot-integration" element={<DashboardSection name="IoT Integration" />} />
          <Route path="performance-quality" element={<DashboardSection name="Performance Quality" />} />
          <Route path="performance-energy" element={<DashboardSection name="Performance Energy" />} />
          <Route path="performance-production" element={<DashboardSection name="Performance Production" />} />
        </Routes>
      </Box>
    </Container>
  );
};

const MainDashboard = () => {
  return (
    <Container>
      <Grid container justifyContent="center">
        {mainSections.map((section, index) => (
          <Grid item key={index}>
            <SectionButton
              icon={section.icon}
              title={section.title}
              subtitle={section.subtitle}
              link={section.link}
            />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default Dashboard;
