
const mongoose = require('mongoose');

// Lot Schema for raw materials
const lotSchema = new mongoose.Schema({
  lotNumber: {
    type: String,
    required: true,
    unique: true
  },
  dateOfArriving: {
    type: Date,
    required: true
  },
  calibre: {
    type: String,
    required: true
  },
  korTestResult: {
    type: String,
    required: true
  },
  country: {
    type: String,
    default: 'Not specified'
  },
  weight: {
    type: Number,
    default: 0
  },
  status: {
    type: String,
    enum: ['received', 'processing', 'completed'],
    default: 'received'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// QR Code Schema for traceability
const qrCodeSchema = new mongoose.Schema({
  batchCode: {
    type: String,
    required: true
  },
  uniqueId: {
    type: String,
    required: true,
    unique: true
  },
  sequenceNumber: {
    type: Number,
    required: true
  },
  lotNumber: {
    type: String,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  data: {
    type: Object,
    required: true
  },
  isActive: {
    type: Boolean,
    default: true
  }
});

// User Schema
const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  role: {
    type: String,
    enum: ['admin', 'manager', 'operator'],
    default: 'operator'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const Lot = mongoose.model('Lot', lotSchema);
const QRCode = mongoose.model('QRCode', qrCodeSchema);
const User = mongoose.model('User', userSchema);

module.exports = {
  Lot,
  QRCode,
  User
};
