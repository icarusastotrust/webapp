
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config();

// Import models
const { Lot, QRCode, User } = require('./models');

// In-memory storage for development
let lotsStorage = [];
let qrCodesStorage = [];
let lotCounter = 1;
let qrCounter = 1;

// Create express app
const app = express();

// Middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

app.use(bodyParser.json());
app.use(cors({
  origin: '*',
  credentials: false,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Access-Control-Allow-Origin']
}));

// For development - using in-memory storage
console.log('Using in-memory storage for development');

// Add sample lots for testing
lotsStorage = [
  {
    id: 1,
    lotNumber: 'LOT-001',
    dateOfArriving: '2024-01-15',
    calibre: 'Premium',
    korTestResult: 'Passed',
    country: 'Cameroon',
    weight: 1000,
    status: 'received',
    createdAt: new Date().toISOString()
  },
  {
    id: 2,
    lotNumber: 'LOT-002',
    dateOfArriving: '2024-01-16',
    calibre: 'Standard',
    korTestResult: 'Passed',
    country: 'Ghana',
    weight: 800,
    status: 'received',
    createdAt: new Date().toISOString()
  }
];
lotCounter = 3;

// Routes
app.get('/', (req, res) => {
  res.json({ message: 'ICARUS System Backend API', version: '1.0.0' });
});

// Lot Management Routes
app.get('/api/lots', (req, res) => {
  try {
    const lots = lotsStorage.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json(lots);
  } catch (error) {
    console.error('Error fetching lots:', error);
    res.status(500).json({ error: 'Failed to fetch lots' });
  }
});

app.post('/api/lots', (req, res) => {
  try {
    const { lotNumber, dateOfArriving, calibre, korTestResult, country, weight } = req.body;
    
    // Check if lot already exists
    const existingLot = lotsStorage.find(lot => lot.lotNumber === lotNumber);
    if (existingLot) {
      return res.status(400).json({ error: 'Lot number already exists' });
    }

    const newLot = {
      id: lotCounter++,
      lotNumber,
      dateOfArriving,
      calibre,
      korTestResult,
      country: country || 'Not specified',
      weight: weight || 0,
      status: 'received',
      createdAt: new Date().toISOString()
    };

    lotsStorage.push(newLot);
    res.status(201).json(newLot);
  } catch (error) {
    console.error('Error creating lot:', error);
    res.status(500).json({ error: 'Failed to create lot' });
  }
});

// QR Code Management Routes
app.get('/api/qrcode', async (req, res) => {
  try {
    const qrCodes = await QRCode.find().sort({ timestamp: -1 });
    res.json(qrCodes);
  } catch (error) {
    console.error('Error fetching QR codes:', error);
    res.status(500).json({ error: 'Failed to fetch QR codes' });
  }
});

app.post('/api/qrcode', async (req, res) => {
  try {
    const { batchCode, uniqueId, sequenceNumber, lotNumber, data } = req.body;
    
    // Check if QR code with this uniqueId already exists
    const existingQR = await QRCode.findOne({ uniqueId });
    if (existingQR) {
      return res.status(400).json({ error: 'QR code with this unique ID already exists' });
    }

    const newQRCode = new QRCode({
      batchCode,
      uniqueId,
      sequenceNumber,
      lotNumber,
      data
    });

    const savedQRCode = await newQRCode.save();
    res.status(201).json(savedQRCode);
  } catch (error) {
    console.error('Error creating QR code:', error);
    res.status(500).json({ error: 'Failed to create QR code' });
  }
});

// Batch QR Code generation
app.post('/api/qrcode/batch', (req, res) => {
  try {
    const { batchCode, lotNumber, quantity } = req.body;
    
    if (!batchCode || !lotNumber || !quantity) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const qrCodes = [];
    for (let i = 1; i <= quantity; i++) {
      const uniqueId = `${batchCode}-QR-${String(i).padStart(4, '0')}`;
      const qrData = {
        batchCode,
        uniqueId,
        sequenceNumber: i,
        timestamp: new Date().toISOString(),
        lotNumber
      };

      const newQRCode = {
        id: qrCounter++,
        batchCode,
        uniqueId,
        sequenceNumber: i,
        lotNumber,
        timestamp: new Date().toISOString(),
        data: qrData,
        isActive: true
      };

      qrCodes.push(newQRCode);
      qrCodesStorage.push(newQRCode);
    }

    res.status(201).json({
      message: `${quantity} QR codes generated successfully`,
      qrCodes: qrCodes
    });
  } catch (error) {
    console.error('Error generating batch QR codes:', error);
    res.status(500).json({ error: 'Failed to generate QR codes' });
  }
});

// Get QR codes by lot number
app.get('/api/qrcode/lot/:lotNumber', async (req, res) => {
  try {
    const { lotNumber } = req.params;
    const qrCodes = await QRCode.find({ lotNumber }).sort({ sequenceNumber: 1 });
    res.json(qrCodes);
  } catch (error) {
    console.error('Error fetching QR codes for lot:', error);
    res.status(500).json({ error: 'Failed to fetch QR codes for lot' });
  }
});

// In-memory storage for scans and deactivated QR codes
let scanStorage = [];
let deactivatedQRStorage = [];
let scanCounter = 1;

// QR Code Status Check
app.get('/api/qrcode/status/:uniqueId', (req, res) => {
  try {
    const { uniqueId } = req.params;
    
    // Check if QR code is deactivated
    const deactivatedQR = deactivatedQRStorage.find(qr => qr.uniqueId === uniqueId);
    
    if (deactivatedQR) {
      return res.json({
        isActive: false,
        status: 'deactivated',
        reason: deactivatedQR.reason,
        deactivatedAt: deactivatedQR.timestamp
      });
    }

    // Check if QR code exists in qrCodesStorage
    const qrCode = qrCodesStorage.find(qr => qr.uniqueId === uniqueId);
    
    if (!qrCode) {
      return res.status(404).json({ error: 'QR code not found' });
    }

    res.json({
      isActive: qrCode.isActive !== false,
      status: 'active',
      qrCode: qrCode
    });
  } catch (error) {
    console.error('Error checking QR code status:', error);
    res.status(500).json({ error: 'Failed to check QR code status' });
  }
});

// Record QR Code Scan
app.post('/api/qrcode/scan', (req, res) => {
  try {
    const scanData = req.body;
    
    const scanRecord = {
      id: scanCounter++,
      ...scanData,
      scanTimestamp: scanData.scanTimestamp || new Date().toISOString()
    };

    scanStorage.push(scanRecord);
    
    console.log('QR Code scan recorded:', scanRecord.qrCodeId);
    
    res.status(201).json({
      message: 'Scan recorded successfully',
      scanId: scanRecord.id,
      scanRecord: scanRecord
    });
  } catch (error) {
    console.error('Error recording QR code scan:', error);
    res.status(500).json({ error: 'Failed to record scan' });
  }
});

// Get Scan History
app.get('/api/qrcode/scans', (req, res) => {
  try {
    const scans = scanStorage
      .sort((a, b) => new Date(b.scanTimestamp) - new Date(a.scanTimestamp))
      .slice(0, 100); // Return last 100 scans
    
    res.json(scans);
  } catch (error) {
    console.error('Error fetching scan history:', error);
    res.status(500).json({ error: 'Failed to fetch scan history' });
  }
});

// Get Scans by QR Code ID
app.get('/api/qrcode/scans/:uniqueId', (req, res) => {
  try {
    const { uniqueId } = req.params;
    const scans = scanStorage
      .filter(scan => scan.qrCodeId === uniqueId)
      .sort((a, b) => new Date(b.scanTimestamp) - new Date(a.scanTimestamp));
    
    res.json(scans);
  } catch (error) {
    console.error('Error fetching scans for QR code:', error);
    res.status(500).json({ error: 'Failed to fetch scans for QR code' });
  }
});

// Admin Action: Activate/Deactivate QR Codes
app.post('/api/qrcode/admin-action', (req, res) => {
  try {
    const { batchCode, uniqueId, action, reason, timestamp, adminId } = req.body;
    
    // Find the QR code
    const qrCodeIndex = qrCodesStorage.findIndex(qr => 
      qr.uniqueId === uniqueId && qr.batchCode === batchCode
    );
    
    if (qrCodeIndex === -1) {
      return res.status(404).json({ error: 'QR code not found' });
    }

    if (action === 'deactivate') {
      // Add to deactivated storage
      const deactivationRecord = {
        uniqueId,
        batchCode,
        reason,
        timestamp: timestamp || new Date().toISOString(),
        adminId,
        originalQRCode: qrCodesStorage[qrCodeIndex]
      };
      
      deactivatedQRStorage.push(deactivationRecord);
      
      // Mark as inactive in main storage
      qrCodesStorage[qrCodeIndex].isActive = false;
      qrCodesStorage[qrCodeIndex].deactivatedAt = timestamp || new Date().toISOString();
      qrCodesStorage[qrCodeIndex].deactivationReason = reason;
      
      console.log('QR Code deactivated:', uniqueId);
      
      res.json({
        message: 'QR code deactivated successfully',
        action: 'deactivated',
        uniqueId,
        reason
      });
      
    } else if (action === 'activate') {
      // Remove from deactivated storage
      const deactivatedIndex = deactivatedQRStorage.findIndex(qr => qr.uniqueId === uniqueId);
      if (deactivatedIndex !== -1) {
        deactivatedQRStorage.splice(deactivatedIndex, 1);
      }
      
      // Mark as active in main storage
      qrCodesStorage[qrCodeIndex].isActive = true;
      delete qrCodesStorage[qrCodeIndex].deactivatedAt;
      delete qrCodesStorage[qrCodeIndex].deactivationReason;
      
      console.log('QR Code activated:', uniqueId);
      
      res.json({
        message: 'QR code activated successfully',
        action: 'activated',
        uniqueId
      });
    } else {
      return res.status(400).json({ error: 'Invalid action. Use "activate" or "deactivate"' });
    }
    
  } catch (error) {
    console.error('Error performing admin action:', error);
    res.status(500).json({ error: 'Failed to perform admin action' });
  }
});

// Get Deactivated QR Codes
app.get('/api/qrcode/deactivated', (req, res) => {
  try {
    const deactivated = deactivatedQRStorage
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    res.json(deactivated);
  } catch (error) {
    console.error('Error fetching deactivated QR codes:', error);
    res.status(500).json({ error: 'Failed to fetch deactivated QR codes' });
  }
});

// License Management Routes
app.get('/api/admin/licenses', (req, res) => {
  try {
    res.json({
      licenseTypes: LICENSE_TYPES,
      users: usersStorage.map(user => ({
        id: user.id,
        username: user.username,
        email: user.email,
        license: user.license,
        status: user.status
      }))
    });
  } catch (error) {
    console.error('Error fetching licenses:', error);
    res.status(500).json({ error: 'Failed to fetch licenses' });
  }
});

app.post('/api/admin/licenses/extend', (req, res) => {
  try {
    const { userId, duration, licenseType } = req.body;
    
    const userIndex = usersStorage.findIndex(user => user.id === userId);
    if (userIndex === -1) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const user = usersStorage[userIndex];
    const licenseConfig = LICENSE_TYPES[licenseType] || LICENSE_TYPES[user.license.type];
    
    // Calculate new expiration date
    const currentExpiry = user.license.expiresAt ? new Date(user.license.expiresAt) : new Date();
    const newExpiry = licenseType === 'enterprise' ? null : 
      new Date(currentExpiry.getTime() + duration * 24 * 60 * 60 * 1000).toISOString();
    
    user.license = {
      ...user.license,
      type: licenseType || user.license.type,
      status: 'active',
      expiresAt: newExpiry,
      features: licenseConfig.features,
      extendedAt: new Date().toISOString()
    };
    
    user.status = 'active';
    
    console.log('License extended for user:', user.username);
    res.json({ message: 'License extended successfully', user });
  } catch (error) {
    console.error('Error extending license:', error);
    res.status(500).json({ error: 'Failed to extend license' });
  }
});

app.post('/api/admin/licenses/revoke', (req, res) => {
  try {
    const { userId, reason } = req.body;
    
    const userIndex = usersStorage.findIndex(user => user.id === userId);
    if (userIndex === -1) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const user = usersStorage[userIndex];
    user.license.status = 'revoked';
    user.license.revokedAt = new Date().toISOString();
    user.license.revocationReason = reason;
    user.status = 'inactive';
    
    console.log('License revoked for user:', user.username);
    res.json({ message: 'License revoked successfully', user });
  } catch (error) {
    console.error('Error revoking license:', error);
    res.status(500).json({ error: 'Failed to revoke license' });
  }
});

// Check user license status
app.get('/api/user/license/:userId', (req, res) => {
  try {
    const { userId } = req.params;
    const user = usersStorage.find(user => user.id === parseInt(userId));
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const isExpired = user.license.expiresAt && new Date(user.license.expiresAt) < new Date();
    const daysRemaining = user.license.expiresAt ? 
      Math.ceil((new Date(user.license.expiresAt) - new Date()) / (1000 * 60 * 60 * 24)) : null;
    
    res.json({
      license: user.license,
      isExpired,
      daysRemaining,
      canAccess: user.license.status === 'active' && !isExpired
    });
  } catch (error) {
    console.error('Error checking license:', error);
    res.status(500).json({ error: 'Failed to check license' });
  }
});

// Get QR Code Analytics
app.get('/api/qrcode/analytics', (req, res) => {
  try {
    const analytics = {
      totalQRCodes: qrCodesStorage.length,
      activeQRCodes: qrCodesStorage.filter(qr => qr.isActive !== false).length,
      deactivatedQRCodes: deactivatedQRStorage.length,
      totalScans: scanStorage.length,
      uniqueScannedQRs: [...new Set(scanStorage.map(scan => scan.qrCodeId))].length,
      scansByStage: scanStorage.reduce((acc, scan) => {
        const stage = scan.scanData?.processStage || 'unknown';
        acc[stage] = (acc[stage] || 0) + 1;
        return acc;
      }, {}),
      recentActivity: {
        scansLast24h: scanStorage.filter(scan => 
          new Date(scan.scanTimestamp) > new Date(Date.now() - 24 * 60 * 60 * 1000)
        ).length,
        deactivationsLast24h: deactivatedQRStorage.filter(qr => 
          new Date(qr.timestamp) > new Date(Date.now() - 24 * 60 * 60 * 1000)
        ).length
      }
    };
    
    res.json(analytics);
  } catch (error) {
    console.error('Error fetching QR code analytics:', error);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

// Equipment Database Management
let equipmentStorage = [
  {
    id: 'EQ001',
    name: 'Mud Pump #1',
    type: 'Drilling Equipment',
    location: 'Drilling Platform A',
    status: 'operational',
    lastMaintenance: '2024-01-15',
    nextMaintenance: '2024-04-15',
    manufacturer: 'National Oilwell Varco',
    model: 'NOV-3NB1600',
    serialNumber: 'NOV2024001',
    installationDate: '2023-06-01',
    criticality: 'high',
    maintenanceHistory: [
      { date: '2024-01-15', type: 'Preventive', description: 'Seal replacement and inspection' },
      { date: '2023-10-15', type: 'Corrective', description: 'Bearing replacement' }
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'EQ002',
    name: 'Top Drive System',
    type: 'Drilling Equipment',
    location: 'Drilling Platform A',
    status: 'maintenance',
    lastMaintenance: '2024-01-20',
    nextMaintenance: '2024-03-20',
    manufacturer: 'Cameron',
    model: 'TDS-11SA',
    serialNumber: 'CAM2024002',
    installationDate: '2023-07-15',
    criticality: 'high',
    maintenanceHistory: [
      { date: '2024-01-20', type: 'Preventive', description: 'Motor bearing inspection' }
    ],
    createdAt: new Date().toISOString()
  }
];
let equipmentCounter = 3;

// Equipment Routes
app.get('/api/equipment', (req, res) => {
  try {
    const { status, type, criticality, search } = req.query;
    let filtered = equipmentStorage;

    if (status && status !== 'all') {
      filtered = filtered.filter(eq => eq.status === status);
    }
    if (type) {
      filtered = filtered.filter(eq => eq.type === type);
    }
    if (criticality) {
      filtered = filtered.filter(eq => eq.criticality === criticality);
    }
    if (search) {
      const searchLower = search.toLowerCase();
      filtered = filtered.filter(eq => 
        eq.name.toLowerCase().includes(searchLower) ||
        eq.location.toLowerCase().includes(searchLower) ||
        eq.manufacturer.toLowerCase().includes(searchLower) ||
        eq.model.toLowerCase().includes(searchLower)
      );
    }

    res.json(filtered);
  } catch (error) {
    console.error('Error fetching equipment:', error);
    res.status(500).json({ error: 'Failed to fetch equipment' });
  }
});

app.get('/api/equipment/:id', (req, res) => {
  try {
    const equipment = equipmentStorage.find(eq => eq.id === req.params.id);
    if (!equipment) {
      return res.status(404).json({ error: 'Equipment not found' });
    }
    res.json(equipment);
  } catch (error) {
    console.error('Error fetching equipment:', error);
    res.status(500).json({ error: 'Failed to fetch equipment' });
  }
});

app.post('/api/equipment', (req, res) => {
  try {
    const {
      name, type, location, status, manufacturer, model, serialNumber,
      installationDate, criticality, lastMaintenance, nextMaintenance
    } = req.body;

    if (!name || !type || !location) {
      return res.status(400).json({ error: 'Name, type, and location are required' });
    }

    const newEquipment = {
      id: `EQ${String(equipmentCounter++).padStart(3, '0')}`,
      name,
      type,
      location,
      status: status || 'operational',
      manufacturer: manufacturer || '',
      model: model || '',
      serialNumber: serialNumber || '',
      installationDate: installationDate || '',
      criticality: criticality || 'medium',
      lastMaintenance: lastMaintenance || '',
      nextMaintenance: nextMaintenance || '',
      maintenanceHistory: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    equipmentStorage.push(newEquipment);
    console.log('Equipment created:', newEquipment.id);
    res.status(201).json(newEquipment);
  } catch (error) {
    console.error('Error creating equipment:', error);
    res.status(500).json({ error: 'Failed to create equipment' });
  }
});

app.put('/api/equipment/:id', (req, res) => {
  try {
    const equipmentIndex = equipmentStorage.findIndex(eq => eq.id === req.params.id);
    if (equipmentIndex === -1) {
      return res.status(404).json({ error: 'Equipment not found' });
    }

    const updatedEquipment = {
      ...equipmentStorage[equipmentIndex],
      ...req.body,
      id: req.params.id, // Ensure ID doesn't change
      updatedAt: new Date().toISOString()
    };

    equipmentStorage[equipmentIndex] = updatedEquipment;
    console.log('Equipment updated:', updatedEquipment.id);
    res.json(updatedEquipment);
  } catch (error) {
    console.error('Error updating equipment:', error);
    res.status(500).json({ error: 'Failed to update equipment' });
  }
});

app.delete('/api/equipment/:id', (req, res) => {
  try {
    const equipmentIndex = equipmentStorage.findIndex(eq => eq.id === req.params.id);
    if (equipmentIndex === -1) {
      return res.status(404).json({ error: 'Equipment not found' });
    }

    const deletedEquipment = equipmentStorage.splice(equipmentIndex, 1)[0];
    console.log('Equipment deleted:', deletedEquipment.id);
    res.json({ message: 'Equipment deleted successfully', equipment: deletedEquipment });
  } catch (error) {
    console.error('Error deleting equipment:', error);
    res.status(500).json({ error: 'Failed to delete equipment' });
  }
});

// Equipment Analytics
app.get('/api/equipment/analytics/dashboard', (req, res) => {
  try {
    const analytics = {
      totalEquipment: equipmentStorage.length,
      operationalCount: equipmentStorage.filter(eq => eq.status === 'operational').length,
      maintenanceCount: equipmentStorage.filter(eq => eq.status === 'maintenance').length,
      outOfOrderCount: equipmentStorage.filter(eq => eq.status === 'out_of_order').length,
      highCriticalityCount: equipmentStorage.filter(eq => eq.criticality === 'high').length,
      mediumCriticalityCount: equipmentStorage.filter(eq => eq.criticality === 'medium').length,
      lowCriticalityCount: equipmentStorage.filter(eq => eq.criticality === 'low').length,
      equipmentByType: equipmentStorage.reduce((acc, eq) => {
        acc[eq.type] = (acc[eq.type] || 0) + 1;
        return acc;
      }, {}),
      upcomingMaintenanceCount: equipmentStorage.filter(eq => {
        if (!eq.nextMaintenance) return false;
        const nextDate = new Date(eq.nextMaintenance);
        const thirtyDaysFromNow = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
        return nextDate <= thirtyDaysFromNow;
      }).length
    };

    res.json(analytics);
  } catch (error) {
    console.error('Error fetching equipment analytics:', error);
    res.status(500).json({ error: 'Failed to fetch equipment analytics' });
  }
});

// Add maintenance record to equipment
app.post('/api/equipment/:id/maintenance', (req, res) => {
  try {
    const equipmentIndex = equipmentStorage.findIndex(eq => eq.id === req.params.id);
    if (equipmentIndex === -1) {
      return res.status(404).json({ error: 'Equipment not found' });
    }

    const { type, description, cost, technician, date } = req.body;
    const maintenanceRecord = {
      id: `MAINT-${Date.now()}`,
      type: type || 'General',
      description: description || '',
      cost: cost || 0,
      technician: technician || '',
      date: date || new Date().toISOString(),
      createdAt: new Date().toISOString()
    };

    equipmentStorage[equipmentIndex].maintenanceHistory.push(maintenanceRecord);
    equipmentStorage[equipmentIndex].lastMaintenance = maintenanceRecord.date;
    equipmentStorage[equipmentIndex].updatedAt = new Date().toISOString();

    console.log('Maintenance record added:', maintenanceRecord.id);
    res.status(201).json(maintenanceRecord);
  } catch (error) {
    console.error('Error adding maintenance record:', error);
    res.status(500).json({ error: 'Failed to add maintenance record' });
  }
});

// In-memory storage for users and licenses
let usersStorage = [
  { 
    id: 1, 
    username: 'admin', 
    email: 'admin@icarus.com', 
    role: 'admin', 
    status: 'active', 
    lastLogin: '2024-01-15T10:30:00Z',
    license: {
      type: 'enterprise',
      status: 'active',
      expiresAt: null, // Admin license never expires
      trialPeriod: false
    }
  },
  { 
    id: 2, 
    username: 'manager', 
    email: 'manager@icarus.com', 
    role: 'manufacturing_manager', 
    status: 'active', 
    lastLogin: '2024-01-15T09:15:00Z',
    license: {
      type: 'professional',
      status: 'active',
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
      trialPeriod: true
    }
  },
  { 
    id: 3, 
    username: 'operator', 
    email: 'operator@icarus.com', 
    role: 'operator', 
    status: 'active', 
    lastLogin: '2024-01-15T08:45:00Z',
    license: {
      type: 'basic',
      status: 'active',
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days trial
      trialPeriod: true
    }
  }
];
let userCounter = 4;

// License configuration
const LICENSE_TYPES = {
  trial: { duration: 7, features: ['basic_access'] },
  basic: { duration: 30, features: ['basic_access', 'qr_scanning'] },
  professional: { duration: 90, features: ['basic_access', 'qr_scanning', 'analytics', 'manufacturing'] },
  enterprise: { duration: 365, features: ['all_features'] }
};

// Admin User Management Routes
app.get('/api/admin/users', (req, res) => {
  try {
    // Check license expiration for all users
    const currentTime = new Date();
    const updatedUsers = usersStorage.map(user => {
      if (user.license.expiresAt && new Date(user.license.expiresAt) < currentTime) {
        return {
          ...user,
          license: { ...user.license, status: 'expired' },
          status: 'inactive'
        };
      }
      return user;
    });
    
    usersStorage = updatedUsers;
    res.json(updatedUsers);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

app.post('/api/admin/users', (req, res) => {
  try {
    const { username, email, password, role, licenseType = 'trial' } = req.body;
    
    // Validate required fields
    if (!username || !email || !password || !role) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    
    // Check if user already exists
    const existingUser = usersStorage.find(user => user.email === email || user.username === username);
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists with this email or username' });
    }
    
    // Calculate license expiration
    const licenseConfig = LICENSE_TYPES[licenseType] || LICENSE_TYPES.trial;
    const expiresAt = licenseType === 'enterprise' ? null : 
      new Date(Date.now() + licenseConfig.duration * 24 * 60 * 60 * 1000).toISOString();
    
    const newUser = {
      id: userCounter++,
      username,
      email,
      role,
      status: 'active',
      createdAt: new Date().toISOString(),
      lastLogin: null,
      license: {
        type: licenseType,
        status: 'active',
        expiresAt,
        trialPeriod: licenseType === 'trial',
        features: licenseConfig.features
      }
    };
    
    usersStorage.push(newUser);
    console.log('User created:', newUser);
    res.status(201).json(newUser);
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ error: 'Failed to create user' });
  }
});

app.put('/api/admin/users/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { username, email, role, status, licenseType } = req.body;
    
    const userIndex = usersStorage.findIndex(user => user.id === parseInt(id));
    if (userIndex === -1) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const user = usersStorage[userIndex];
    
    // Update license if licenseType is provided
    if (licenseType && licenseType !== user.license.type) {
      const licenseConfig = LICENSE_TYPES[licenseType] || LICENSE_TYPES.trial;
      const expiresAt = licenseType === 'enterprise' ? null : 
        new Date(Date.now() + licenseConfig.duration * 24 * 60 * 60 * 1000).toISOString();
      
      user.license = {
        type: licenseType,
        status: 'active',
        expiresAt,
        trialPeriod: licenseType === 'trial',
        features: licenseConfig.features
      };
    }
    
    // Update other fields
    if (username) user.username = username;
    if (email) user.email = email;
    if (role) user.role = role;
    if (status) user.status = status;
    
    user.updatedAt = new Date().toISOString();
    
    console.log('User updated:', user);
    res.json({ message: 'User updated successfully', user });
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

app.delete('/api/admin/users/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { adminId } = req.body; // Track who performed the deletion
    
    const userIndex = usersStorage.findIndex(user => user.id === parseInt(id));
    if (userIndex === -1) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const deletedUser = usersStorage[userIndex];
    
    // Prevent admin from deleting themselves
    if (deletedUser.role === 'admin' && deletedUser.id === adminId) {
      return res.status(400).json({ error: 'Cannot delete your own admin account' });
    }
    
    // Remove user from storage
    usersStorage.splice(userIndex, 1);
    
    console.log('User deleted:', { id, deletedUser: deletedUser.username, deletedBy: adminId });
    res.json({ 
      message: 'User deleted successfully', 
      deletedUser: {
        id: deletedUser.id,
        username: deletedUser.username,
        email: deletedUser.email
      }
    });
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

// Data Operations Routes
app.post('/api/admin/import', (req, res) => {
  try {
    const { data, type } = req.body;
    
    console.log('Data import requested:', { type, recordCount: data?.length || 0 });
    
    // Simulate data processing
    setTimeout(() => {
      res.json({ 
        message: 'Data imported successfully', 
        recordsProcessed: data?.length || 0,
        timestamp: new Date().toISOString()
      });
    }, 2000);
  } catch (error) {
    console.error('Error importing data:', error);
    res.status(500).json({ error: 'Failed to import data' });
  }
});

app.get('/api/admin/export', (req, res) => {
  try {
    const { format, tables } = req.query;
    
    const exportData = {
      metadata: {
        exportedAt: new Date().toISOString(),
        format: format || 'json',
        tables: tables || 'all'
      },
      lots: lotsStorage,
      qrCodes: qrCodesStorage.slice(0, 100), // Limit for demo
      scans: scanStorage.slice(0, 100),
      users: [
        { id: 1, username: 'admin', email: 'admin@icarus.com', role: 'admin' },
        { id: 2, username: 'manager', email: 'manager@icarus.com', role: 'manufacturing_manager' }
      ]
    };
    
    res.json(exportData);
  } catch (error) {
    console.error('Error exporting data:', error);
    res.status(500).json({ error: 'Failed to export data' });
  }
});

// System Operations Routes
app.post('/api/admin/backup', (req, res) => {
  try {
    console.log('Manual backup triggered');
    
    res.json({ 
      message: 'Backup completed successfully',
      backupId: `backup_${Date.now()}`,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error creating backup:', error);
    res.status(500).json({ error: 'Failed to create backup' });
  }
});

app.get('/api/admin/logs', (req, res) => {
  try {
    const logs = [
      { timestamp: new Date().toISOString(), level: 'INFO', message: 'User login: admin@icarus.com' },
      { timestamp: new Date(Date.now() - 60000).toISOString(), level: 'INFO', message: 'QR code scanned: LOT-001-QR-0001' },
      { timestamp: new Date(Date.now() - 120000).toISOString(), level: 'WARN', message: 'Failed login attempt: operator@icarus.com' },
      { timestamp: new Date(Date.now() - 180000).toISOString(), level: 'INFO', message: 'Backup completed successfully' }
    ];
    
    res.json(logs);
  } catch (error) {
    console.error('Error fetching logs:', error);
    res.status(500).json({ error: 'Failed to fetch logs' });
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`ICARUS System Backend running on port ${PORT}`);
  console.log(`Server accessible at: http://0.0.0.0:${PORT}`);
});
