
import React from 'react';
import { Box, Typography, Chip } from '@mui/material';
import { styled } from '@mui/system';
import IcarusLogo from './IcarusLogo';
import { useAuth } from './AuthContext';

const BannerContainer = styled(Box)({
  background: 'linear-gradient(135deg, #1976d2, #42a5f5)',
  color: 'white',
  padding: '16px 24px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
  borderBottom: '3px solid #0d47a1',
});

const TopBanner = () => {
  const { user, userRole } = useAuth();

  return (
    <BannerContainer>
      <Box display="flex" alignItems="center" gap={2}>
        <IcarusLogo size="small" />
        <Box>
          <Typography variant="h6" sx={{ fontWeight: 'bold', margin: 0 }}>
            ICARUS SYSTEM WEB APP PORTAL
          </Typography>
          <Typography variant="body2" sx={{ opacity: 0.9 }}>
            Integrated Control & Advanced Reporting Universal System
          </Typography>
        </Box>
      </Box>
      
      {user && (
        <Box display="flex" alignItems="center" gap={2}>
          <Box textAlign="right">
            <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
              {user.name}
            </Typography>
            <Typography variant="caption" sx={{ opacity: 0.8 }}>
              {user.department}
            </Typography>
          </Box>
          <Chip 
            label={userRole} 
            size="small" 
            sx={{ 
              backgroundColor: 'rgba(255,255,255,0.2)', 
              color: 'white',
              fontWeight: 'bold'
            }} 
          />
        </Box>
      )}
    </BannerContainer>
  );
};

export default TopBanner;
