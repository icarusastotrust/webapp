import React from 'react';
import { Container, Grid } from '@mui/material';
import SectionButton from './SectionButton';

const MainDashboard = () => {
  return (
    <Container>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6} md={4}>
          <SectionButton title="MAGASIN MATIÈRE PREMIÈRE" link="/magasin-matiere-premiere" />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <SectionButton title="FRAGILISATION" link="/fragilisation" />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <SectionButton title="DÉCORTICAGE" link="/decorticage" />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <SectionButton title="SÉCHAGE" link="/sechage" />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <SectionButton title="DÉPELLICULAGE" link="/depelliculage" />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <SectionButton title="CLASSIFICATION+ÉPURATION" link="/classification-epuration" />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <SectionButton title="EMBALLAGE PRODUITS FINI" link="/emballage-produits-fini" />
        </Grid>
      </Grid>
    </Container>
  );
};

export default MainDashboard;
