import React from 'react';
import { Container, Grid, Typography } from '@mui/material';
import SectionButton from './SectionButton';
import SpeedIcon from '@mui/icons-material/Speed'; // Example icon, add more as needed

const performanceSections = [
  { icon: <SpeedIcon />, title: 'Performance Quality', subtitle: 'Quality Performance Metrics', link: '/dashboard/performance-quality' },
  { icon: <SpeedIcon />, title: 'Performance Energy', subtitle: 'Energy Performance Metrics', link: '/dashboard/performance-energy' },
  { icon: <SpeedIcon />, title: 'Performance Production', subtitle: 'Production Performance Metrics', link: '/dashboard/performance-production' },
];

const ProductionLinePerformance = () => {
  return (
    <Container>
      <Typography variant="h4" component="h1" gutterBottom>
        Production Line Performance Dashboard
      </Typography>
      <Grid container justifyContent="center">
        {performanceSections.map((section, index) => (
          <Grid item key={index}>
            <SectionButton
              icon={section.icon}
              title={section.title}
              subtitle={section.subtitle}
              link={section.link}
            />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default ProductionLinePerformance;
