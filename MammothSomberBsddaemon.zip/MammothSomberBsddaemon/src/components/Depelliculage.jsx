import React from 'react';
import { Container, Typography } from '@mui/material';

const Depelliculage = () => {
  return (
    <Container>
      <Typography variant="h4">Dépelliculage</Typography>
      {/* Add your content here */}
    </Container>
  );
};

export default Depelliculage;
