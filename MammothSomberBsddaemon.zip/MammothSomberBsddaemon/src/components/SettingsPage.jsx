import React, { useState, useEffect } from 'react';
import {
  Container, Typography, Card, CardContent, CardHeader, Grid, Switch, 
  FormControl, InputLabel, Select, MenuItem, Button, List, ListItem, 
  ListItemText, ListItemSecondaryAction, Tabs, Tab, Box, TextField,
  Slider, Chip, Divider, Alert, Dialog, DialogTitle, DialogContent,
  DialogActions, Table, TableBody, TableCell, TableContainer, TableHead,
  TableRow, Paper, IconButton, Avatar, Checkbox, FormControlLabel,
  FormGroup, LinearProgress, Snackbar
} from '@mui/material';
import {
  Settings as SettingsIcon,
  Person as PersonIcon,
  Security as SecurityIcon,
  Notifications as NotificationsIcon,
  Palette as PaletteIcon,
  Language as LanguageIcon,
  Storage as StorageIcon,
  CloudSync as CloudSyncIcon,
  Backup as BackupIcon,
  History as HistoryIcon,
  Edit as EditIcon,
  Add as AddIcon,
  Download as DownloadIcon,
  Upload as UploadIcon,
  CloudUpload as CloudUploadIcon,
  GetApp as GetAppIcon,
  Delete as DeleteIcon,
  AdminPanelSettings as AdminIcon,
  SupervisorAccount as SupervisorIcon,
  PersonAdd as PersonAddIcon,
  Block as BlockIcon,
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon
} from '@mui/icons-material';
import { useAuth } from './AuthContext';
import AppLayout from './AppLayout';
import NavigationBreadcrumb from './NavigationBreadcrumb';

const SettingsPage = () => {
  const { user, userRole } = useAuth();
  const [tabValue, setTabValue] = useState(0);
  const [settings, setSettings] = useState({
    // Profile Settings
    profile: {
      firstName: user?.name?.split(' ')[0] || '',
      lastName: user?.name?.split(' ')[1] || '',
      email: user?.email || '',
      phone: '',
      department: '',
      position: ''
    },
    // Security Settings
    security: {
      twoFactorAuth: false,
      sessionTimeout: 30,
      passwordExpiry: 90,
      loginNotifications: true,
      ipWhitelist: [],
      apiAccess: false
    },
    // Notification Settings
    notifications: {
      emailNotifications: true,
      pushNotifications: true,
      maintenanceAlerts: true,
      systemUpdates: true,
      securityAlerts: true,
      reportNotifications: false,
      digestFrequency: 'daily'
    },
    // System Preferences
    system: {
      theme: 'light',
      language: 'en',
      timezone: 'UTC',
      dateFormat: 'DD/MM/YYYY',
      currency: 'USD',
      autoSave: true,
      dataRetention: 365
    },
    // Data & Backup
    backup: {
      autoBackup: true,
      backupFrequency: 'weekly',
      retentionPeriod: 30,
      includeReports: true,
      includeAnalytics: false
    }
  });

  // Admin states
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [userDialogOpen, setUserDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [licenseDialogOpen, setLicenseDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);
  const [newUser, setNewUser] = useState({
    username: '',
    email: '',
    password: '',
    role: 'operator',
    licenseType: 'trial',
    permissions: []
  });
  const [licenseData, setLicenseData] = useState({
    userId: null,
    licenseType: 'trial',
    duration: 30
  });

  // License types configuration
  const LICENSE_TYPES = {
    trial: { duration: 7, label: 'Trial (7 days)', color: 'info' },
    basic: { duration: 30, label: 'Basic (30 days)', color: 'primary' },
    professional: { duration: 90, label: 'Professional (90 days)', color: 'warning' },
    enterprise: { duration: 365, label: 'Enterprise (1 year)', color: 'success' }
  };
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [exportDialogOpen, setExportDialogOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [dataOperations, setDataOperations] = useState({
    export: {
      tables: [],
      format: 'json',
      dateRange: 'all'
    }
  });

  const [openDialog, setOpenDialog] = useState(false);
  const [dialogType, setDialogType] = useState('');
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [newApiKey, setNewApiKey] = useState('');

  useEffect(() => {
    if (userRole === 'admin') {
      fetchUsers();
    }
  }, [userRole]);

  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/admin/users');
      if (response.ok) {
        const userData = await response.json();
        setUsers(userData);
      }
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleSettingChange = (category, setting, value) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [setting]: value
      }
    }));
  };

  const handleSaveSettings = async () => {
    try {
      setSnackbar({ open: true, message: 'Settings saved successfully!', severity: 'success' });
    } catch (error) {
      setSnackbar({ open: true, message: 'Error saving settings', severity: 'error' });
    }
  };

  const handleCreateUser = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/admin/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newUser),
      });

      if (response.ok) {
        const createdUser = await response.json();
        setUsers([...users, createdUser]);
        setUserDialogOpen(false);
        setSnackbar({ open: true, message: 'User created successfully!', severity: 'success' });
        setNewUser({
          username: '',
          email: '',
          password: '',
          role: 'operator',
          licenseType: 'trial',
          permissions: []
        });
      } else {
        const error = await response.json();
        setSnackbar({ open: true, message: error.error || 'Error creating user', severity: 'error' });
      }
    } catch (error) {
      console.error('Error creating user:', error);
      setSnackbar({ open: true, message: 'Error creating user', severity: 'error' });
    }
  };

  const handleUpdateUser = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/admin/users/${selectedUser.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newUser),
      });

      if (response.ok) {
        const result = await response.json();
        setUsers(users.map(user => user.id === selectedUser.id ? result.user : user));
        setUserDialogOpen(false);
        setSnackbar({ open: true, message: 'User updated successfully!', severity: 'success' });
      } else {
        const error = await response.json();
        setSnackbar({ open: true, message: error.error || 'Error updating user', severity: 'error' });
      }
    } catch (error) {
      console.error('Error updating user:', error);
      setSnackbar({ open: true, message: 'Error updating user', severity: 'error' });
    }
  };

  const handleDeleteUser = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/admin/users/${userToDelete.id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ adminId: user?.id }),
      });

      if (response.ok) {
        setUsers(users.filter(user => user.id !== userToDelete.id));
        setDeleteDialogOpen(false);
        setSnackbar({ open: true, message: 'User deleted successfully!', severity: 'success' });
      } else {
        const error = await response.json();
        setSnackbar({ open: true, message: error.error || 'Error deleting user', severity: 'error' });
      }
    } catch (error) {
      console.error('Error deleting user:', error);
      setSnackbar({ open: true, message: 'Error deleting user', severity: 'error' });
    }
  };

  const handleExtendLicense = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/admin/licenses/extend', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(licenseData),
      });

      if (response.ok) {
        const result = await response.json();
        setUsers(users.map(user => user.id === licenseData.userId ? result.user : user));
        setLicenseDialogOpen(false);
        setSnackbar({ open: true, message: 'License extended successfully!', severity: 'success' });
      } else {
        const error = await response.json();
        setSnackbar({ open: true, message: error.error || 'Error extending license', severity: 'error' });
      }
    } catch (error) {
      console.error('Error extending license:', error);
      setSnackbar({ open: true, message: 'Error extending license', severity: 'error' });
    }
  };

  const handleBackup = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/admin/backup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const result = await response.json();
        setSnackbar({ open: true, message: 'Backup created successfully!', severity: 'success' });
      } else {
        setSnackbar({ open: true, message: 'Error creating backup', severity: 'error' });
      }
    } catch (error) {
      console.error('Error creating backup:', error);
      setSnackbar({ open: true, message: 'Error creating backup', severity: 'error' });
    }
  };

  // Fetch users on component mount (fetchUsers already defined above)
  useEffect(() => {
    if (userRole === 'admin') {
      fetchUsers();
    }
  }, [userRole]);

  const handleExportSettings = () => {
    const dataStr = JSON.stringify(settings, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'icarus-settings.json';
    link.click();
  };

  // Helper functions
  const handleEditUser = (user) => {
    setSelectedUser(user);
    setNewUser({
      username: user.username,
      email: user.email,
      password: '',
      role: user.role,
      licenseType: user.license?.type || 'trial',
      permissions: []
    });
    setUserDialogOpen(true);
  };

  const getLicenseStatusColor = (license) => {
    if (!license) return 'default';
    if (license.status === 'expired') return 'error';
    if (license.status === 'revoked') return 'error';
    if (license.trialPeriod) return 'warning';
    return 'success';
  };

  const getDaysRemaining = (expiresAt) => {
    if (!expiresAt) return 'Never expires';
    const days = Math.ceil((new Date(expiresAt) - new Date()) / (1000 * 60 * 60 * 24));
    if (days < 0) return 'Expired';
    if (days === 0) return 'Expires today';
    return `${days} days left`;
  };

  const confirmDeleteUser = (user) => {
    setUserToDelete(user);
    setDeleteDialogOpen(true);
  };

  const openLicenseDialog = (user) => {
    setLicenseData({
      userId: user.id,
      licenseType: user.license?.type || 'trial',
      duration: LICENSE_TYPES[user.license?.type || 'trial'].duration
    });
    setLicenseDialogOpen(true);
  };

  const handleToggleUserStatus = (userId) => {
    const updatedUsers = users.map(user =>
      user.id === userId ? { ...user, status: user.status === 'active' ? 'inactive' : 'active' } : user
    );
    setUsers(updatedUsers);
    setSnackbar({ open: true, message: 'User status updated!', severity: 'success' });
  };

  const handleFileUpload = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleDataExport = () => {
    console.log('Exporting data in', dataOperations.export.format, 'format');
    setSnackbar({ open: true, message: `Exporting data in ${dataOperations.export.format} format`, severity: 'info' });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const handleChangeTab = (event, newValue) => {
    setTabValue(newValue);
  };

  // Define all render functions
  const renderProfileSettings = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Profile Information" />
          <CardContent>
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="First Name"
                  value={settings.profile.firstName}
                  onChange={(e) => handleSettingChange('profile', 'firstName', e.target.value)}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Last Name"
                  value={settings.profile.lastName}
                  onChange={(e) => handleSettingChange('profile', 'lastName', e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Email"
                  type="email"
                  value={settings.profile.email}
                  onChange={(e) => handleSettingChange('profile', 'email', e.target.value)}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Phone"
                  value={settings.profile.phone}
                  onChange={(e) => handleSettingChange('profile', 'phone', e.target.value)}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  fullWidth
                  label="Department"
                  value={settings.profile.department}
                  onChange={(e) => handleSettingChange('profile', 'department', e.target.value)}
                />
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Grid>
      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Account Settings" />
          <CardContent>
            <List>
              <ListItem>
                <ListItemText primary="Profile Visibility" secondary="Make profile visible to other users" />
                <ListItemSecondaryAction>
                  <Switch defaultChecked />
                </ListItemSecondaryAction>
              </ListItem>
              <ListItem>
                <ListItemText primary="Activity Status" secondary="Show online status" />
                <ListItemSecondaryAction>
                  <Switch defaultChecked />
                </ListItemSecondaryAction>
              </ListItem>
            </List>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  const renderSecuritySettings = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Security Options" />
          <CardContent>
            <List>
              <ListItem>
                <ListItemText 
                  primary="Two-Factor Authentication" 
                  secondary="Add an extra layer of security to your account" 
                />
                <ListItemSecondaryAction>
                  <Switch 
                    checked={settings.security.twoFactorAuth}
                    onChange={(e) => handleSettingChange('security', 'twoFactorAuth', e.target.checked)}
                  />
                </ListItemSecondaryAction>
              </ListItem>
              <ListItem>
                <ListItemText 
                  primary="Login Notifications" 
                  secondary="Get notified when someone logs into your account" 
                />
                <ListItemSecondaryAction>
                  <Switch 
                    checked={settings.security.loginNotifications}
                    onChange={(e) => handleSettingChange('security', 'loginNotifications', e.target.checked)}
                  />
                </ListItemSecondaryAction>
              </ListItem>
              <ListItem>
                <ListItemText 
                  primary="API Access" 
                  secondary="Allow API access to your account" 
                />
                <ListItemSecondaryAction>
                  <Switch 
                    checked={settings.security.apiAccess}
                    onChange={(e) => handleSettingChange('security', 'apiAccess', e.target.checked)}
                  />
                </ListItemSecondaryAction>
              </ListItem>
            </List>
          </CardContent>
        </Card>
      </Grid>
      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Session Management" />
          <CardContent>
            <Typography variant="body2" gutterBottom>Session Timeout (minutes)</Typography>
            <Slider
              value={settings.security.sessionTimeout}
              onChange={(e, value) => handleSettingChange('security', 'sessionTimeout', value)}
              min={5}
              max={120}
              step={5}
              marks
              valueLabelDisplay="auto"
            />
            <Typography variant="body2" gutterBottom sx={{ mt: 2 }}>Password Expiry (days)</Typography>
            <Slider
              value={settings.security.passwordExpiry}
              onChange={(e, value) => handleSettingChange('security', 'passwordExpiry', value)}
              min={30}
              max={365}
              step={30}
              marks
              valueLabelDisplay="auto"
            />
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  const renderNotificationSettings = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Notification Preferences" />
          <CardContent>
            <List>
              <ListItem>
                <ListItemText primary="Email Notifications" secondary="Receive notifications via email" />
                <ListItemSecondaryAction>
                  <Switch 
                    checked={settings.notifications.emailNotifications}
                    onChange={(e) => handleSettingChange('notifications', 'emailNotifications', e.target.checked)}
                  />
                </ListItemSecondaryAction>
              </ListItem>
              <ListItem>
                <ListItemText primary="Push Notifications" secondary="Receive browser push notifications" />
                <ListItemSecondaryAction>
                  <Switch 
                    checked={settings.notifications.pushNotifications}
                    onChange={(e) => handleSettingChange('notifications', 'pushNotifications', e.target.checked)}
                  />
                </ListItemSecondaryAction>
              </ListItem>
              <ListItem>
                <ListItemText primary="Maintenance Alerts" secondary="Get notified about maintenance activities" />
                <ListItemSecondaryAction>
                  <Switch 
                    checked={settings.notifications.maintenanceAlerts}
                    onChange={(e) => handleSettingChange('notifications', 'maintenanceAlerts', e.target.checked)}
                  />
                </ListItemSecondaryAction>
              </ListItem>
              <ListItem>
                <ListItemText primary="System Updates" secondary="Notifications about system updates" />
                <ListItemSecondaryAction>
                  <Switch 
                    checked={settings.notifications.systemUpdates}
                    onChange={(e) => handleSettingChange('notifications', 'systemUpdates', e.target.checked)}
                  />
                </ListItemSecondaryAction>
              </ListItem>
            </List>
          </CardContent>
        </Card>
      </Grid>
      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Digest Settings" />
          <CardContent>
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel>Digest Frequency</InputLabel>
              <Select
                value={settings.notifications.digestFrequency}
                onChange={(e) => handleSettingChange('notifications', 'digestFrequency', e.target.value)}
              >
                <MenuItem value="realtime">Real-time</MenuItem>
                <MenuItem value="hourly">Hourly</MenuItem>
                <MenuItem value="daily">Daily</MenuItem>
                <MenuItem value="weekly">Weekly</MenuItem>
              </Select>
            </FormControl>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  const renderSystemSettings = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Appearance" />
          <CardContent>
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel>Theme</InputLabel>
              <Select
                value={settings.system.theme}
                onChange={(e) => handleSettingChange('system', 'theme', e.target.value)}
              >
                <MenuItem value="light">Light</MenuItem>
                <MenuItem value="dark">Dark</MenuItem>
                <MenuItem value="auto">Auto</MenuItem>
              </Select>
            </FormControl>
            <FormControl fullWidth>
              <InputLabel>Language</InputLabel>
              <Select
                value={settings.system.language}
                onChange={(e) => handleSettingChange('system', 'language', e.target.value)}
              >
                <MenuItem value="en">English</MenuItem>
                <MenuItem value="fr">French</MenuItem>
                <MenuItem value="es">Spanish</MenuItem>
              </Select>
            </FormControl>
          </CardContent>
        </Card>
      </Grid>
      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Regional Settings" />
          <CardContent>
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel>Timezone</InputLabel>
              <Select
                value={settings.system.timezone}
                onChange={(e) => handleSettingChange('system', 'timezone', e.target.value)}
              >
                <MenuItem value="UTC">UTC</MenuItem>
                <MenuItem value="EST">Eastern Time</MenuItem>
                <MenuItem value="PST">Pacific Time</MenuItem>
                <MenuItem value="CET">Central European Time</MenuItem>
              </Select>
            </FormControl>
            <FormControl fullWidth>
              <InputLabel>Date Format</InputLabel>
              <Select
                value={settings.system.dateFormat}
                onChange={(e) => handleSettingChange('system', 'dateFormat', e.target.value)}
              >
                <MenuItem value="DD/MM/YYYY">DD/MM/YYYY</MenuItem>
                <MenuItem value="MM/DD/YYYY">MM/DD/YYYY</MenuItem>
                <MenuItem value="YYYY-MM-DD">YYYY-MM-DD</MenuItem>
              </Select>
            </FormControl>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  const renderDataSettings = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Backup Settings" />
          <CardContent>
            <List>
              <ListItem>
                <ListItemText primary="Auto Backup" secondary="Automatically backup your data" />
                <ListItemSecondaryAction>
                  <Switch 
                    checked={settings.backup.autoBackup}
                    onChange={(e) => handleSettingChange('backup', 'autoBackup', e.target.checked)}
                  />
                </ListItemSecondaryAction>
              </ListItem>
              <ListItem>
                <ListItemText primary="Include Reports" secondary="Include reports in backups" />
                <ListItemSecondaryAction>
                  <Switch 
                    checked={settings.backup.includeReports}
                    onChange={(e) => handleSettingChange('backup', 'includeReports', e.target.checked)}
                  />
                </ListItemSecondaryAction>
              </ListItem>
            </List>
            <FormControl fullWidth sx={{ mt: 2 }}>
              <InputLabel>Backup Frequency</InputLabel>
              <Select
                value={settings.backup.backupFrequency}
                onChange={(e) => handleSettingChange('backup', 'backupFrequency', e.target.value)}
              >
                <MenuItem value="daily">Daily</MenuItem>
                <MenuItem value="weekly">Weekly</MenuItem>
                <MenuItem value="monthly">Monthly</MenuItem>
              </Select>
            </FormControl>
          </CardContent>
        </Card>
      </Grid>
      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Data Management" />
          <CardContent>
            <Typography variant="body2" gutterBottom>Data Retention (days)</Typography>
            <Slider
              value={settings.system.dataRetention}
              onChange={(e, value) => handleSettingChange('system', 'dataRetention', value)}
              min={30}
              max={1095}
              step={30}
              marks
              valueLabelDisplay="auto"
            />
            <List sx={{ mt: 2 }}>
              <ListItem>
                <ListItemText primary="Auto Save" secondary="Automatically save changes" />
                <ListItemSecondaryAction>
                  <Switch 
                    checked={settings.system.autoSave}
                    onChange={(e) => handleSettingChange('system', 'autoSave', e.target.checked)}
                  />
                </ListItemSecondaryAction>
              </ListItem>
            </List>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  const renderUserManagement = () => (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="h6">User Management</Typography>
          <Button
            variant="contained"
            startIcon={<PersonAddIcon />}
            onClick={() => setUserDialogOpen(true)}
          >
            Add User
          </Button>
        </Box>

        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>User</TableCell>
                <TableCell>Role</TableCell>
                <TableCell>License</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Last Login</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Avatar sx={{ mr: 2, bgcolor: user.status === 'active' ? 'success.main' : 'grey.500' }}>
                        <PersonIcon />
                      </Avatar>
                      <Box>
                        <Typography variant="body2" fontWeight="bold">{user.username}</Typography>
                        <Typography variant="caption" color="text.secondary">{user.email}</Typography>
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Chip 
                      label={user.role.replace('_', ' ').toUpperCase()} 
                      color={user.role === 'admin' ? 'error' : user.role === 'manufacturing_manager' ? 'warning' : 'primary'}
                      size="small"
                    />
                  </TableCell>
                  <TableCell>
                    <Box>
                      <Chip 
                        label={user.license?.type?.toUpperCase() || 'TRIAL'} 
                        color={getLicenseStatusColor(user.license)}
                        size="small"
                        sx={{ mb: 0.5 }}
                      />
                      <Typography variant="caption" display="block" color="text.secondary">
                        {getDaysRemaining(user.license?.expiresAt)}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Chip 
                      label={user.status} 
                      color={user.status === 'active' ? 'success' : 'default'}
                      size="small"
                      icon={user.status === 'active' ? <CheckCircleIcon /> : <BlockIcon />}
                    />
                  </TableCell>
                  <TableCell>
                    {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : 'Never'}
                  </TableCell>
                  <TableCell align="right">
                    <IconButton onClick={() => handleEditUser(user)} color="primary" title="Edit User">
                      <EditIcon />
                    </IconButton>
                    <IconButton onClick={() => openLicenseDialog(user)} color="info" title="Manage License">
                      <SecurityIcon />
                    </IconButton>
                    <IconButton onClick={() => handleToggleUserStatus(user.id)} color="warning" title="Toggle Status">
                      {user.status === 'active' ? <BlockIcon /> : <CheckCircleIcon />}
                    </IconButton>
                    {user.role !== 'admin' && (
                      <IconButton onClick={() => confirmDeleteUser(user)} color="error" title="Delete User">
                        <DeleteIcon />
                      </IconButton>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Grid>
    </Grid>
  );

  const renderAccessControl = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Role Permissions" />
          <CardContent>
            <Typography variant="body2" gutterBottom>Configure access levels for each role:</Typography>

            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle2" gutterBottom>Administrator</Typography>
              <FormGroup>
                <FormControlLabel control={<Checkbox defaultChecked disabled />} label="Full System Access" />
                <FormControlLabel control={<Checkbox defaultChecked disabled />} label="User Management" />
                <FormControlLabel control={<Checkbox defaultChecked disabled />} label="Data Operations" />
                <FormControlLabel control={<Checkbox defaultChecked disabled />} label="System Settings" />
              </FormGroup>
            </Box>

            <Divider sx={{ my: 2 }} />

            <Box>
              <Typography variant="subtitle2" gutterBottom>Manufacturing Manager</Typography>
              <FormGroup>
                <FormControlLabel control={<Checkbox defaultChecked />} label="Manufacturing Operations" />
                <FormControlLabel control={<Checkbox defaultChecked />} label="QR Code Management" />
                <FormControlLabel control={<Checkbox defaultChecked />} label="Predictive Maintenance" />
                <FormControlLabel control={<Checkbox />} label="User Management" />
              </FormGroup>
            </Box>

            <Divider sx={{ my: 2 }} />

            <Box>
              <Typography variant="subtitle2" gutterBottom>Operator</Typography>
              <FormGroup>
                <FormControlLabel control={<Checkbox defaultChecked />} label="Manufacturing Operations" />
                <FormControlLabel control={<Checkbox defaultChecked />} label="QR Code Scanning" />
                <FormControlLabel control={<Checkbox />} label="QR Code Management" />
                <FormControlLabel control={<Checkbox />} label="System Settings" />
              </FormGroup>
            </Box>
          </CardContent>
        </Card>
      </Grid>

      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Security Policies" />
          <CardContent>
            <List>
              <ListItem>
                <ListItemText primary="Password Complexity" secondary="Minimum 8 characters with uppercase, lowercase, and numbers" />
                <ListItemSecondaryAction>
                  <Switch defaultChecked />
                </ListItemSecondaryAction>
              </ListItem>
              <ListItem>
                <ListItemText primary="Session Timeout" secondary="Auto-logout after inactivity" />
                <ListItemSecondaryAction>
                  <Switch defaultChecked />
                </ListItemSecondaryAction>
              </ListItem>
              <ListItem>
                <ListItemText primary="Login Attempt Limits" secondary="Lock account after failed attempts" />
                <ListItemSecondaryAction>
                  <Switch defaultChecked />
                </ListItemSecondaryAction>
              </ListItem>
              <ListItem>
                <ListItemText primary="Audit Logging" secondary="Track all user actions" />
                <ListItemSecondaryAction>
                  <Switch defaultChecked />
                </ListItemSecondaryAction>
              </ListItem>
            </List>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  const renderDataOperations = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Data Import" />
          <CardContent>
            <Typography variant="body2" gutterBottom>
              Upload data files to import into the system
            </Typography>

            <Button
              variant="outlined"
              component="label"
              fullWidth
              startIcon={<CloudUploadIcon />}
              sx={{ mt: 2, mb: 2 }}
            >
              Select File to Upload
              <input type="file" hidden onChange={handleFileUpload} accept=".json,.csv,.xlsx" />
            </Button>

            {selectedFile && (
              <Alert severity="info" sx={{ mt: 1 }}>
                Selected: {selectedFile.name}
              </Alert>
            )}

            <Button
              variant="contained"
              fullWidth
              startIcon={<UploadIcon />}
              disabled={!selectedFile}
              onClick={() => setUploadDialogOpen(true)}
              sx={{ mt: 2 }}
            >
              Import Data
            </Button>

            <Typography variant="caption" display="block" sx={{ mt: 2 }}>
              Supported formats: JSON, CSV, Excel (.xlsx)
            </Typography>
          </CardContent>
        </Card>
      </Grid>

      <Grid item xs={12} md={6}>
        <Card>
          <CardHeader title="Data Export" />
          <CardContent>
            <Typography variant="body2" gutterBottom>
              Export system data for backup or analysis
            </Typography>

            <FormControl fullWidth sx={{ mt: 2, mb: 2 }}>
              <InputLabel>Export Format</InputLabel>
              <Select
                value={dataOperations.export.format}
                onChange={(e) => setDataOperations({
                  ...dataOperations,
                  export: { ...dataOperations.export, format: e.target.value }
                })}
              >
                <MenuItem value="json">JSON</MenuItem>
                <MenuItem value="csv">CSV</MenuItem>
                <MenuItem value="excel">Excel</MenuItem>
              </Select>
            </FormControl>

            <Button
              variant="contained"
              fullWidth
              startIcon={<GetAppIcon />}
              onClick={() => setExportDialogOpen(true)}
              sx={{ mb: 2 }}
            >
              Export Data
            </Button>

            <Button
              variant="outlined"
              fullWidth
              startIcon={<DownloadIcon />}
              onClick={handleDataExport}
            >
              Quick Export (JSON)
            </Button>
          </CardContent>
        </Card>
      </Grid>

      <Grid item xs={12}>
        <Card>
          <CardHeader title="System Maintenance" />
          <CardContent>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6} md={3}>
                <Button variant="outlined" fullWidth startIcon={<BackupIcon />} onClick={handleBackup}>
                  Manual Backup
                </Button>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Button variant="outlined" fullWidth startIcon={<HistoryIcon />}>
                  View Logs
                </Button>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Button variant="outlined" fullWidth startIcon={<WarningIcon />} color="warning">
                  Clear Cache
                </Button>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Button variant="outlined" fullWidth startIcon={<SecurityIcon />} color="error">
                  Security Scan
                </Button>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );

  // Define tabs array after all render functions are defined
  const tabs = [
    { label: 'Profile', icon: <PersonIcon />, content: renderProfileSettings },
    { label: 'Security', icon: <SecurityIcon />, content: renderSecuritySettings },
    { label: 'Notifications', icon: <NotificationsIcon />, content: renderNotificationSettings },
    { label: 'System', icon: <PaletteIcon />, content: renderSystemSettings },
    { label: 'Data & Backup', icon: <StorageIcon />, content: renderDataSettings },
    ...(userRole === 'admin' ? [
      { label: 'User Management', icon: <AdminIcon />, content: renderUserManagement },
      { label: 'Access Control', icon: <SupervisorIcon />, content: renderAccessControl },
      { label: 'Data Operations', icon: <CloudUploadIcon />, content: renderDataOperations }
    ] : [])
  ];

  return (
    <AppLayout>
      <Container maxWidth="xl" sx={{ py: 3 }}>
        <NavigationBreadcrumb />

        <Box display="flex" alignItems="center" mb={3}>
          <SettingsIcon sx={{ mr: 2, fontSize: 32, color: 'primary.main' }} />
          <Typography variant="h4" fontWeight={700}>
            Settings & Preferences
          </Typography>
        </Box>

        <Paper sx={{ width: '100%' }}>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            variant="scrollable"
            scrollButtons="auto"
            sx={{ borderBottom: 1, borderColor: 'divider' }}
          >
            {tabs.map((tab, index) => (
              <Tab
                key={index}
                icon={tab.icon}
                label={tab.label}
                iconPosition="start"
                sx={{ minHeight: 'auto', py: 2 }}
              />
            ))}
          </Tabs>

          <Box sx={{ p: 3 }}>
            {tabs[tabValue].content()}
          </Box>

          <Box sx={{ p: 3, pt: 0 }}>
            <Divider sx={{ mb: 3 }} />
            <Box display="flex" gap={2} justifyContent="flex-end">
              <Button variant="outlined" onClick={handleExportSettings}>
                Export Settings
              </Button>
              <Button variant="contained" onClick={handleSaveSettings}>
                Save Changes
              </Button>
            </Box>
          </Box>
        </Paper>

        <Snackbar
          open={snackbar.open}
          autoHideDuration={3000}
          onClose={handleCloseSnackbar}
        >
          <Alert severity={snackbar.severity} onClose={handleCloseSnackbar}>
            {snackbar.message}
          </Alert>
        </Snackbar>

        {/* User Management Dialog */}
        <Dialog open={userDialogOpen} onClose={() => setUserDialogOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>{selectedUser ? 'Edit User' : 'Create New User'}</DialogTitle>
          <DialogContent>
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Username"
                  value={newUser.username}
                  onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Password"
                  type="password"
                  value={newUser.password}
                  onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                  helperText={selectedUser ? "Leave blank to keep current password" : "Required for new users"}
                />
              </Grid>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>Role</InputLabel>
                  <Select
                    value={newUser.role}
                    onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                  >
                    <MenuItem value="admin">Administrator</MenuItem>
                    <MenuItem value="manufacturing_manager">Manufacturing Manager</MenuItem>
                    <MenuItem value="operator">Operator</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>License Type</InputLabel>
                  <Select
                    value={newUser.licenseType}
                    onChange={(e) => setNewUser({ ...newUser, licenseType: e.target.value })}
                  >
                    {Object.entries(LICENSE_TYPES).map(([key, config]) => (
                      <MenuItem key={key} value={key}>
                        {config.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setUserDialogOpen(false)}>Cancel</Button>
            <Button 
              onClick={selectedUser ? handleUpdateUser : handleCreateUser} 
              variant="contained"
            >
              {selectedUser ? 'Update' : 'Create'} User
            </Button>
          </DialogActions>
        </Dialog>

        {/* Upload Dialog */}
        <Dialog open={uploadDialogOpen} onClose={() => setUploadDialogOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>Import Data</DialogTitle>
          <DialogContent>
            <Typography variant="body2" gutterBottom>
              Import {selectedFile?.name} into the system?
            </Typography>
            <LinearProgress variant="determinate" value={0} sx={{ mt: 2 }} />
            <Typography variant="caption" sx={{ mt: 1 }}>
              This operation may take a few minutes depending on file size.
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setUploadDialogOpen(false)}>Cancel</Button>
            <Button variant="contained" color="primary">
              Import
            </Button>
          </DialogActions>
        </Dialog>

        {/* Export Dialog */}
        <Dialog open={exportDialogOpen} onClose={() => setExportDialogOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>Export Data</DialogTitle>
          <DialogContent>
            <Typography variant="body2" gutterBottom>
              Select data to export:
            </Typography>
            <FormGroup sx={{ mt: 2 }}>
              <FormControlLabel control={<Checkbox defaultChecked />} label="User Data" />
              <FormControlLabel control={<Checkbox defaultChecked />} label="QR Codes" />
              <FormControlLabel control={<Checkbox defaultChecked />} label="Scan History" />
              <FormControlLabel control={<Checkbox defaultChecked />} label="Lot Information" />
            </FormGroup>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setExportDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleDataExport} variant="contained" color="primary">
              Export
            </Button>
          </DialogActions>
        </Dialog>

        {/* Delete User Confirmation Dialog */}
        <Dialog open={deleteDialogOpen} onClose={() => setDeleteDialogOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle sx={{ color: 'error.main' }}>
            <Box display="flex" alignItems="center">
              <WarningIcon sx={{ mr: 1 }} />
              Confirm User Deletion
            </Box>
          </DialogTitle>
          <DialogContent>
            <Alert severity="warning" sx={{ mb: 2 }}>
              This action cannot be undone. The user will lose access to all data and functionality.
            </Alert>
            <Typography variant="body1" gutterBottom>
              Are you sure you want to delete the following user?
            </Typography>
            {userToDelete && (
              <Box sx={{ mt: 2, p: 2, bgcolor: 'grey.100', borderRadius: 1 }}>
                <Typography variant="body2"><strong>Username:</strong> {userToDelete.username}</Typography>
                <Typography variant="body2"><strong>Email:</strong> {userToDelete.email}</Typography>
                <Typography variant="body2"><strong>Role:</strong> {userToDelete.role}</Typography>
                <Typography variant="body2"><strong>License:</strong> {userToDelete.license?.type || 'Trial'}</Typography>
              </Box>
            )}
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleDeleteUser} variant="contained" color="error">
              Delete User
            </Button>
          </DialogActions>
        </Dialog>

        {/* License Management Dialog */}
        <Dialog open={licenseDialogOpen} onClose={() => setLicenseDialogOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>
            <Box display="flex" alignItems="center">
              <SecurityIcon sx={{ mr: 1, color: 'primary.main' }} />
              Manage User License
            </Box>
          </DialogTitle>
          <DialogContent>
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>License Type</InputLabel>
                  <Select
                    value={licenseData.licenseType}
                    onChange={(e) => {
                      const newType = e.target.value;
                      setLicenseData({
                        ...licenseData,
                        licenseType: newType,
                        duration: LICENSE_TYPES[newType].duration
                      });
                    }}
                  >
                    {Object.entries(LICENSE_TYPES).map(([key, config]) => (
                      <MenuItem key={key} value={key}>
                        {config.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Duration (days)"
                  type="number"
                  value={licenseData.duration}
                  onChange={(e) => setLicenseData({ ...licenseData, duration: parseInt(e.target.value) })}
                  helperText="Set to 0 for unlimited duration (Enterprise only)"
                  disabled={licenseData.licenseType === 'enterprise'}
                />
              </Grid>
              <Grid item xs={12}>
                <Alert severity="info">
                  This will extend the user's license from the current expiration date or activate an expired license.
                </Alert>
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setLicenseDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleExtendLicense} variant="contained" color="primary">
              Update License
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </AppLayout>
  );
};

export default SettingsPage;