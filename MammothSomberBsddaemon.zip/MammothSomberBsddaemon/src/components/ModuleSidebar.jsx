import React, { useState } from 'react';
import {
  Drawer,
  Box,
  Typography,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Collapse,
  Divider,
  Badge,
  Tooltip,
  IconButton,
  Avatar,
  Chip
} from '@mui/material';
import {
  Dashboard as DashboardIcon,
  Factory as FactoryIcon,
  Analytics as AnalyticsIcon,
  Settings as SettingsIcon,
  Description as DescriptionIcon,
  Notifications as NotificationsIcon,
  ExpandLess,
  ExpandMore,
  FiberManualRecord as DotIcon,
  ChevronLeft as ChevronLeftIcon,
  Menu as MenuIcon,
  Business as BusinessIcon,
  Factory as ManufacturingIcon
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';

const ModuleSidebar = ({ open, onToggle, onMouseEnter, onMouseLeave, compact = false }) => {
  const [expandedModules, setExpandedModules] = useState({
    africaNegoce: false,
    manufacturing: false,
    predictiveMaintenance: false,
    analytics: false
  });

  const navigate = useNavigate();
  const location = useLocation();
  const { user, canAccessManufacturing, canAccessPredictiveMaintenance, canAccessAfricaNegoce } = useAuth();

  const handleExpand = (moduleId) => {
    setExpandedModules(prev => ({
      ...prev,
      [moduleId]: !prev[moduleId]
    }));
  };

  const isActive = (path) => location.pathname === path;
  const isModuleActive = (basePath) => location.pathname.startsWith(basePath);

  const modules = [
    {
      id: 'dashboard',
      title: 'Overview',
      icon: <DashboardIcon />,
      path: '/main-dashboard',
      notifications: 0,
      status: 'active',
      requiresAccess: () => true
    },
    {
      id: 'africaNegoce',
      title: 'Africa Negoce',
      icon: <BusinessIcon />,
      notifications: 3,
      status: 'active',
      requiresAccess: canAccessAfricaNegoce,
      expandable: true,
      children: [
        { title: 'Trading Operations', path: '/africa-negoce/trading', status: 'active' },
        { title: 'Supply Chain', path: '/africa-negoce/supply-chain', status: 'active' },
        { title: 'Inventory Management', path: '/africa-negoce/inventory', status: 'development' },
        { title: 'Financial Analytics', path: '/africa-negoce/financial', status: 'development' },
        { title: 'Market Intelligence', path: '/africa-negoce/market', status: 'development' },
        { title: 'Client Portal', path: '/africa-negoce/clients', status: 'development' }
      ]
    },
    {
      id: 'manufacturing',
      title: 'Manufacturing',
      icon: <ManufacturingIcon />,
      notifications: 1,
      status: 'warning',
      requiresAccess: canAccessManufacturing,
      expandable: true,
      children: [
        { title: 'Raw Materials', path: '/magasin-matiere-premiere', status: 'active' },
        { title: 'Fragilisation', path: '/fragilisation', status: 'active' },
        { title: 'Decorticage', path: '/decorticage', status: 'active' },
        { title: 'Séchage', path: '/sechage', status: 'active' },
        { title: 'Dépelliculage', path: '/depelliculage', status: 'active' },
        { title: 'Classification', path: '/classification-epuration', status: 'active' },
        { title: 'Packaging', path: '/emballage-produits-fini', status: 'active' },
        { title: 'QR Code Scanner', path: '/qr-scanner', status: 'active' },
        { title: 'QR Analytics', path: '/qr-analytics', status: 'active' },
        { title: 'Equipment Database', path: '/maintenance-equipment-database', status: 'active' },
        { title: 'Maintenance Schedule', path: '/maintenance-scheduling', status: 'warning' },
        { title: 'Analytics', path: '/reporting-analytics', status: 'active' }
      ]
    },
    {
      id: 'predictiveMaintenance',
      title: 'Predictive Maintenance',
      icon: <AnalyticsIcon />,
      notifications: 5,
      status: 'active',
      requiresAccess: canAccessPredictiveMaintenance,
      expandable: true,
      children: [
        { title: 'Drilling Equipment', path: '/predictive-maintenance/drilling', status: 'active' },
        { title: 'Pumping Systems', path: '/predictive-maintenance/pumps', status: 'active' },
        { title: 'Pipeline Systems', path: '/predictive-maintenance/pipelines', status: 'active' },
        { title: 'Compressors', path: '/predictive-maintenance/compressors', status: 'development' },
        { title: 'Turbines', path: '/predictive-maintenance/turbines', status: 'development' },
        { title: 'Heat Exchangers', path: '/predictive-maintenance/heat-exchangers', status: 'development' },
        { title: 'Separators', path: '/predictive-maintenance/separators', status: 'development' },
        { title: 'Valves & Controls', path: '/predictive-maintenance/valves', status: 'development' }
      ]
    },
    {
      id: 'settings',
      title: 'Settings',
      icon: <SettingsIcon />,
      path: '/settings',
      status: 'active',
      requiresAccess: () => true
    },
    { 
      id: 'documentation',
      title: 'Documentation', 
      path: '/documentation', 
      status: 'active',
      requiresAccess: () => true,
      icon: <DescriptionIcon />
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'success';
      case 'warning': return 'warning';
      case 'error': return 'error';
      case 'development': return 'info';
      default: return 'default';
    }
  };

  const drawerWidth = compact ? 72 : 320;

  return (
    <Drawer
      variant="temporary"
      anchor="left"
      open={open}
      onClose={onToggle}
      sx={{
        width: open ? drawerWidth : 0,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: drawerWidth,
          boxSizing: 'border-box',
          backgroundColor: '#ffffff',
          borderRight: '1px solid #e0e0e0',
          zIndex: 1200,
          boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
        },
      }}
      PaperProps={{
        onMouseEnter: onMouseEnter,
        onMouseLeave: onMouseLeave
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          p: 2,
          backgroundColor: 'primary.main',
          color: 'white',
          minHeight: 64
        }}
      >
        {!compact && (
          <Box display="flex" alignItems="center" gap={2}>
            <Avatar sx={{ bgcolor: 'white', color: 'primary.main', width: 32, height: 32 }}>
              I
            </Avatar>
            <Box>
              <Typography variant="h6" sx={{ fontWeight: 700, lineHeight: 1 }}>
                ICARUS
              </Typography>
              <Typography variant="caption" sx={{ opacity: 0.8 }}>
                System Portal
              </Typography>
            </Box>
          </Box>
        )}
        <IconButton onClick={onToggle} sx={{ color: 'white' }}>
          <ChevronLeftIcon />
        </IconButton>
      </Box>

      {/* User Profile Section */}
      {!compact && (
        <Box sx={{ p: 2, borderBottom: '1px solid #e0e0e0' }}>
          <Box display="flex" alignItems="center" gap={2}>
            <Avatar sx={{ bgcolor: 'primary.100', color: 'primary.main' }}>
              {user?.name?.charAt(0)}
            </Avatar>
            <Box flex={1}>
              <Typography variant="subtitle2" fontWeight={600}>
                {user?.name}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {user?.role || 'User'}
              </Typography>
            </Box>
            <IconButton size="small">
              <Badge badgeContent={7} color="error">
                <NotificationsIcon fontSize="small" />
              </Badge>
            </IconButton>
          </Box>
        </Box>
      )}

      {/* Navigation */}
      <List sx={{ px: 1, py: 2 }}>
        {modules.map((module) => {
          if (!module.requiresAccess()) return null;

          const isExpanded = expandedModules[module.id];
          const isModuleCurrentlyActive = isActive(module.path) || isModuleActive(module.path?.split('/')[1] ? `/${module.path.split('/')[1]}` : '');

          return (
            <Box key={module.id}>
              <ListItem disablePadding sx={{ mb: 0.5 }}>
                <Tooltip title={compact ? module.title : ''} placement="right">
                  <ListItemButton
                    onClick={() => {
                      if (module.expandable) {
                        handleExpand(module.id);
                      } else if (module.path) {
                        navigate(module.path);
                      }
                    }}
                    sx={{
                      borderRadius: 2,
                      mx: 1,
                      backgroundColor: isModuleCurrentlyActive ? 'primary.50' : 'transparent',
                      border: isModuleCurrentlyActive ? '1px solid' : 'none',
                      borderColor: isModuleCurrentlyActive ? 'primary.200' : 'transparent',
                      '&:hover': {
                        backgroundColor: 'primary.50'
                      }
                    }}
                  >
                    <ListItemIcon sx={{ 
                      color: isModuleCurrentlyActive ? 'primary.main' : 'text.secondary',
                      minWidth: compact ? 'auto' : 40
                    }}>
                      <Badge
                        badgeContent={module.notifications}
                        color="error"
                        max={99}
                        invisible={module.notifications === 0}
                      >
                        {module.icon}
                      </Badge>
                    </ListItemIcon>

                    {!compact && (
                      <>
                        <ListItemText
                          primary={module.title}
                          primaryTypographyProps={{
                            fontWeight: isModuleCurrentlyActive ? 600 : 400,
                            color: isModuleCurrentlyActive ? 'primary.main' : 'text.primary'
                          }}
                        />
                        <Box display="flex" alignItems="center" gap={1}>
                          <DotIcon
                            sx={{
                              fontSize: 8,
                              color: `${getStatusColor(module.status)}.main`
                            }}
                          />
                          {module.expandable && (
                            isExpanded ? <ExpandLess /> : <ExpandMore />
                          )}
                        </Box>
                      </>
                    )}
                  </ListItemButton>
                </Tooltip>
              </ListItem>

              {/* Submenu */}
              {module.expandable && !compact && (
                <Collapse in={isExpanded} timeout="auto" unmountOnExit>
                  <List component="div" disablePadding sx={{ ml: 2 }}>
                    {module.children?.map((child) => (
                      <ListItem key={child.path} disablePadding sx={{ mb: 0.25 }}>
                        <ListItemButton
                          onClick={() => navigate(child.path)}
                          sx={{
                            borderRadius: 1.5,
                            py: 0.75,
                            backgroundColor: isActive(child.path) ? 'primary.50' : 'transparent',
                            '&:hover': {
                              backgroundColor: 'primary.50'
                            }
                          }}
                        >
                          <Box display="flex" alignItems="center" gap={1} width="100%">
                            <DotIcon
                              sx={{
                                fontSize: 6,
                                color: `${getStatusColor(child.status)}.main`
                              }}
                            />
                            <ListItemText
                              primary={child.title}
                              primaryTypographyProps={{
                                fontSize: '0.875rem',
                                fontWeight: isActive(child.path) ? 600 : 400,
                                color: isActive(child.path) ? 'primary.main' : 'text.secondary'
                              }}
                            />
                            {child.status === 'development' && (
                              <Chip
                                label="Dev"
                                size="small"
                                color="info"
                                variant="outlined"
                                sx={{ height: 20, fontSize: '0.6rem' }}
                              />
                            )}
                          </Box>
                        </ListItemButton>
                      </ListItem>
                    ))}
                  </List>
                </Collapse>
              )}
            </Box>
          );
        })}
      </List>

      {/* Settings Section */}
      {!compact && (
        <>
          <Divider sx={{ mx: 2 }} />
          <List sx={{ px: 1, py: 1 }}>
            <ListItem disablePadding>
              <ListItemButton 
                onClick={() => navigate('/settings')}
                sx={{ 
                  borderRadius: 2, 
                  mx: 1,
                  backgroundColor: isActive('/settings') ? 'primary.50' : 'transparent',
                  '&:hover': {
                    backgroundColor: 'primary.50'
                  }
                }}
              >
                <ListItemIcon sx={{ 
                  color: isActive('/settings') ? 'primary.main' : 'text.secondary'
                }}>
                  <SettingsIcon />
                </ListItemIcon>
                <ListItemText 
                  primary="Settings" 
                  primaryTypographyProps={{
                    fontWeight: isActive('/settings') ? 600 : 400,
                    color: isActive('/settings') ? 'primary.main' : 'text.primary'
                  }}
                />
              </ListItemButton>
            </ListItem>
          </List>
        </>
      )}
    </Drawer>
  );
};

export default ModuleSidebar;