
import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Box, 
  Tabs, 
  Tab, 
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  LinearProgress
} from '@mui/material';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import TimelineIcon from '@mui/icons-material/Timeline';
import InventoryIcon from '@mui/icons-material/Inventory';

const AfricaNegoceSupplyChain = () => {
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const shipments = [
    { id: 'SH001', destination: 'Port of Lagos', status: 'In Transit', progress: 65 },
    { id: 'SH002', destination: 'Port of Abidjan', status: 'Loading', progress: 25 },
    { id: 'SH003', destination: 'Port of Tema', status: 'Delivered', progress: 100 },
    { id: 'SH004', destination: 'Port of Dakar', status: 'Preparing', progress: 10 },
  ];

  return (
    <Container component="main" maxWidth="lg">
      <Box display="flex" alignItems="center" mb={3}>
        <LocalShippingIcon sx={{ fontSize: 40, color: 'primary.main', mr: 2 }} />
        <Typography variant="h4" component="h1">
          AFRICA NEGOCE - Supply Chain Management
        </Typography>
      </Box>

      <Paper sx={{ mb: 3 }}>
        <Tabs value={tabValue} onChange={handleTabChange} aria-label="supply chain tabs">
          <Tab label="Shipment Tracking" />
          <Tab label="Logistics Network" />
          <Tab label="Warehouse Management" />
          <Tab label="Distribution" />
        </Tabs>
      </Paper>

      {tabValue === 0 && (
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Active Shipments
                </Typography>
                <List>
                  {shipments.map((shipment) => (
                    <ListItem key={shipment.id}>
                      <ListItemIcon>
                        <LocationOnIcon color="primary" />
                      </ListItemIcon>
                      <ListItemText
                        primary={`Shipment ${shipment.id} - ${shipment.destination}`}
                        secondary={
                          <Box>
                            <Box display="flex" alignItems="center" mb={1}>
                              <Chip 
                                label={shipment.status} 
                                size="small" 
                                color={shipment.status === 'Delivered' ? 'success' : 'primary'} 
                              />
                            </Box>
                            <LinearProgress 
                              variant="determinate" 
                              value={shipment.progress} 
                              sx={{ width: '100%' }}
                            />
                            <Typography variant="caption" color="text.secondary">
                              {shipment.progress}% Complete
                            </Typography>
                          </Box>
                        }
                      />
                    </ListItem>
                  ))}
                </List>
              </CardContent>
            </Card>
          </Grid>
          
          <Grid item xs={12} md={4}>
            <Card>
              <CardContent>
                <Box display="flex" alignItems="center" mb={2}>
                  <TimelineIcon color="primary" />
                  <Typography variant="h6" sx={{ ml: 1 }}>
                    Logistics KPIs
                  </Typography>
                </Box>
                <Box mb={2}>
                  <Typography variant="body2" color="text.secondary">
                    On-Time Delivery Rate
                  </Typography>
                  <Typography variant="h5" color="success.main">
                    94.5%
                  </Typography>
                </Box>
                <Box mb={2}>
                  <Typography variant="body2" color="text.secondary">
                    Average Transit Time
                  </Typography>
                  <Typography variant="h5" color="primary">
                    12 days
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Cost per Shipment
                  </Typography>
                  <Typography variant="h5" color="warning.main">
                    $2,450
                  </Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {tabValue === 1 && (
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Logistics Network Overview
                </Typography>
                <Typography variant="body1" color="text.secondary">
                  Interactive map showing distribution centers, transportation routes, and partner locations across Africa.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {tabValue === 2 && (
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Warehouse Operations
                </Typography>
                <Typography variant="body1" color="text.secondary">
                  Warehouse capacity, inventory levels, and storage optimization metrics.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {tabValue === 3 && (
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Distribution Management
                </Typography>
                <Typography variant="body1" color="text.secondary">
                  Distribution planning, route optimization, and delivery scheduling.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}
    </Container>
  );
};

export default AfricaNegoceSupplyChain;
