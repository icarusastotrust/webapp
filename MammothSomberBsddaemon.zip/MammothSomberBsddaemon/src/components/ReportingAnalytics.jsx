
import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Grid,
  Paper,
  Box,
  Card,
  CardContent,
  IconButton,
  AppBar,
  Toolbar,
  Avatar,
  Badge,
  Button,
  Chip,
  LinearProgress,
  Tab,
  Tabs,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow
} from '@mui/material';
import {
  Analytics as AnalyticsIcon,
  TrendingUp as TrendingUpIcon,
  Assessment as AssessmentIcon,
  PieChart as PieChartIcon,
  BarChart as BarChartIcon,
  Notifications as NotificationsIcon,
  Settings as SettingsIcon,
  MenuBook as MenuBookIcon,
  Menu as MenuIcon,
  ArrowBack as ArrowBackIcon,
  Download as DownloadIcon,
  DateRange as DateRangeIcon,
  FilterList as FilterListIcon
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import ModuleSidebar from './ModuleSidebar';
import TopBanner from './TopBanner';
import NavigationBreadcrumb from './NavigationBreadcrumb';

const ReportingAnalytics = () => {
  const navigate = useNavigate();
  const { user, userRole } = useAuth();
  const [navigationOpen, setNavigationOpen] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const [tabValue, setTabValue] = useState(0);
  const [timeRange, setTimeRange] = useState('7days');

  const handleNavigationToggle = () => {
    setNavigationOpen(!navigationOpen);
  };

  const handleMouseEnterTrigger = () => {
    setIsHovering(true);
    setNavigationOpen(true);
  };

  const handleMouseLeaveTrigger = () => {
    setIsHovering(false);
    setTimeout(() => {
      if (!isHovering) {
        setNavigationOpen(false);
      }
    }, 300);
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  // Sample analytics data
  const productionMetrics = [
    { label: 'Production Efficiency', value: 94.2, trend: '+2.1%', color: 'success' },
    { label: 'Quality Score', value: 98.7, trend: '+1.3%', color: 'success' },
    { label: 'Equipment Utilization', value: 87.5, trend: '-0.8%', color: 'warning' },
    { label: 'Energy Efficiency', value: 91.3, trend: '+3.2%', color: 'success' }
  ];

  // Raw Materials Request Analytics
  const rawMaterialsRequests = [
    { date: '2024-01-15', requests: 12, from: 'Fragilisation', approved: 10, rejected: 2 },
    { date: '2024-01-14', requests: 8, from: 'Fragilisation', approved: 8, rejected: 0 },
    { date: '2024-01-13', requests: 15, from: 'Fragilisation', approved: 13, rejected: 2 },
    { date: '2024-01-12', requests: 6, from: 'Fragilisation', approved: 6, rejected: 0 },
    { date: '2024-01-11', requests: 9, from: 'Fragilisation', approved: 8, rejected: 1 }
  ];

  const requestMetrics = {
    totalRequests: rawMaterialsRequests.reduce((sum, day) => sum + day.requests, 0),
    todayRequests: rawMaterialsRequests[0]?.requests || 0,
    approvalRate: Math.round((rawMaterialsRequests.reduce((sum, day) => sum + day.approved, 0) / rawMaterialsRequests.reduce((sum, day) => sum + day.requests, 0)) * 100),
    averageDaily: Math.round(rawMaterialsRequests.reduce((sum, day) => sum + day.requests, 0) / rawMaterialsRequests.length)
  };

  const recentReports = [
    { name: 'Daily Production Summary', date: '2024-01-15', type: 'Production', status: 'Complete' },
    { name: 'Quality Control Analysis', date: '2024-01-14', type: 'Quality', status: 'Complete' },
    { name: 'Maintenance Performance', date: '2024-01-13', type: 'Maintenance', status: 'Processing' },
    { name: 'Energy Consumption Report', date: '2024-01-12', type: 'Energy', status: 'Complete' }
  ];

  const TabPanel = ({ children, value, index, ...other }) => (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`analytics-tabpanel-${index}`}
      aria-labelledby={`analytics-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', backgroundColor: '#f8fafc', position: 'relative' }}>
      <TopBanner />

      {/* Hover trigger zone for navigation */}
      <Box
        sx={{
          position: 'fixed',
          left: 0,
          top: 0,
          width: '20px',
          height: '100vh',
          zIndex: 1300,
          backgroundColor: 'transparent'
        }}
        onMouseEnter={handleMouseEnterTrigger}
      />

      <ModuleSidebar 
        open={navigationOpen} 
        onToggle={handleNavigationToggle}
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={handleMouseLeaveTrigger}
      />

      <Box 
        component="main" 
        sx={{ 
          flexGrow: 1,
          transition: 'margin-left 0.3s ease',
          marginLeft: 0,
          width: '100%',
          minHeight: '100vh'
        }}
      >
        {/* Modern Header */}
        <AppBar 
          position="static" 
          elevation={0}
          sx={{ 
            backgroundColor: 'white',
            borderBottom: '1px solid #e0e7ff',
            color: 'text.primary',
            backdropFilter: 'blur(10px)'
          }}
        >
          <Toolbar sx={{ py: 1 }}>
            <IconButton
              onClick={handleNavigationToggle}
              sx={{ mr: 2, color: 'primary.main' }}
            >
              <MenuIcon />
            </IconButton>
            <IconButton
              onClick={() => navigate('/main-dashboard')}
              sx={{ mr: 2, color: 'primary.main' }}
            >
              <ArrowBackIcon />
            </IconButton>
            <AnalyticsIcon sx={{ mr: 2, color: 'primary.main', fontSize: 32 }} />
            <Box sx={{ flexGrow: 1 }}>
              <Typography variant="h5" sx={{ fontWeight: 700, color: 'primary.main' }}>
                Reporting & Analytics
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Performance insights and data visualization
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button
                color="inherit"
                startIcon={<SettingsIcon />}
                onClick={() => navigate('/settings')}
                sx={{ color: 'primary.main' }}
              >
                Settings
              </Button>
              <Button
                color="inherit"
                startIcon={<MenuBookIcon />}
                onClick={() => navigate('/documentation')}
                sx={{ color: 'primary.main' }}
              >
                Docs
              </Button>
            </Box>

            <Box display="flex" alignItems="center" gap={3}>
              <Badge badgeContent={5} color="error">
                <IconButton>
                  <NotificationsIcon />
                </IconButton>
              </Badge>

              <Box display="flex" alignItems="center" gap={2}>
                <Avatar sx={{ bgcolor: 'primary.main', width: 40, height: 40 }}>
                  {user?.name?.charAt(0)}
                </Avatar>
                <Box>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                    {user?.name}
                  </Typography>
                  <Chip 
                    label={userRole} 
                    size="small" 
                    color="primary"
                    variant="outlined"
                    sx={{ height: 20, fontSize: '0.6rem' }}
                  />
                </Box>
              </Box>
            </Box>
          </Toolbar>
        </AppBar>

        <Container maxWidth="xl" sx={{ py: 4 }}>
          <NavigationBreadcrumb />

          {/* Hero Section */}
          <Card 
            sx={{ 
              mb: 4,
              background: 'linear-gradient(135deg, #673ab7 0%, #9c27b0 100%)',
              color: 'white',
              borderRadius: 3
            }}
          >
            <CardContent sx={{ p: 4 }}>
              <Grid container spacing={4} alignItems="center">
                <Grid item xs={12} md={8}>
                  <Typography variant="h3" sx={{ fontWeight: 700, mb: 2 }}>
                    Analytics Dashboard
                  </Typography>
                  <Typography variant="h6" sx={{ opacity: 0.9, mb: 3 }}>
                    Track performance metrics, generate reports, and gain insights from your data
                  </Typography>
                  <Box display="flex" gap={2}>
                    <Button 
                      variant="contained" 
                      size="large"
                      startIcon={<DownloadIcon />}
                      sx={{ 
                        backgroundColor: 'white', 
                        color: 'primary.main',
                        '&:hover': { backgroundColor: 'grey.100' }
                      }}
                    >
                      Export Report
                    </Button>
                    <Button 
                      variant="outlined" 
                      size="large"
                      startIcon={<DateRangeIcon />}
                      sx={{ 
                        borderColor: 'white', 
                        color: 'white',
                        '&:hover': { backgroundColor: 'rgba(255,255,255,0.1)' }
                      }}
                    >
                      Custom Date Range
                    </Button>
                  </Box>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Box textAlign="center">
                    <AnalyticsIcon sx={{ fontSize: 120, opacity: 0.3 }} />
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Controls */}
          <Card sx={{ mb: 4, borderRadius: 3 }}>
            <CardContent>
              <Grid container spacing={3} alignItems="center">
                <Grid item xs={12} md={4}>
                  <FormControl fullWidth>
                    <InputLabel>Time Range</InputLabel>
                    <Select
                      value={timeRange}
                      label="Time Range"
                      onChange={(e) => setTimeRange(e.target.value)}
                    >
                      <MenuItem value="24hours">Last 24 Hours</MenuItem>
                      <MenuItem value="7days">Last 7 Days</MenuItem>
                      <MenuItem value="30days">Last 30 Days</MenuItem>
                      <MenuItem value="90days">Last 90 Days</MenuItem>
                      <MenuItem value="custom">Custom Range</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} md={8}>
                  <Box display="flex" gap={2} justifyContent="flex-end">
                    <Button
                      variant="outlined"
                      startIcon={<FilterListIcon />}
                      sx={{ borderRadius: 2 }}
                    >
                      Advanced Filters
                    </Button>
                    <Button
                      variant="contained"
                      startIcon={<DownloadIcon />}
                      sx={{ borderRadius: 2 }}
                    >
                      Export Data
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Performance Metrics */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            {productionMetrics.map((metric, index) => (
              <Grid item xs={12} sm={6} md={3} key={index}>
                <Card sx={{ borderRadius: 3, height: '100%' }}>
                  <CardContent>
                    <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                      <Typography variant="body2" color="text.secondary">
                        {metric.label}
                      </Typography>
                      <TrendingUpIcon color={metric.color} sx={{ fontSize: 20 }} />
                    </Box>
                    <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
                      {metric.value}%
                    </Typography>
                    <LinearProgress 
                      variant="determinate" 
                      value={metric.value} 
                      color={metric.color}
                      sx={{ borderRadius: 1, height: 6, mb: 1 }}
                    />
                    <Chip 
                      label={metric.trend}
                      size="small"
                      color={metric.color}
                      variant="outlined"
                    />
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>

          {/* Analytics Tabs */}
          <Card sx={{ borderRadius: 3 }}>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <Tabs value={tabValue} onChange={handleTabChange} aria-label="analytics tabs">
                <Tab 
                  label="Production Analytics" 
                  icon={<BarChartIcon />} 
                  iconPosition="start"
                />
                <Tab 
                  label="Quality Metrics" 
                  icon={<AssessmentIcon />} 
                  iconPosition="start"
                />
                <Tab 
                  label="Maintenance Reports" 
                  icon={<PieChartIcon />} 
                  iconPosition="start"
                />
                <Tab 
                  label="Raw Materials Requests" 
                  icon={<AnalyticsIcon />} 
                  iconPosition="start"
                />
                <Tab 
                  label="Recent Reports" 
                  icon={<AnalyticsIcon />} 
                  iconPosition="start"
                />
              </Tabs>
            </Box>

            <TabPanel value={tabValue} index={0}>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                Production Performance
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12} md={8}>
                  <Box
                    sx={{
                      height: 400,
                      backgroundColor: 'grey.50',
                      borderRadius: 2,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      border: '2px dashed',
                      borderColor: 'grey.300'
                    }}
                  >
                    <Typography variant="h6" color="text.secondary">
                      Production Chart Placeholder
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Box display="flex" flexDirection="column" gap={2}>
                    <Card variant="outlined">
                      <CardContent>
                        <Typography variant="subtitle2" color="text.secondary">
                          Daily Output
                        </Typography>
                        <Typography variant="h5" sx={{ fontWeight: 600 }}>
                          2,450 units
                        </Typography>
                      </CardContent>
                    </Card>
                    <Card variant="outlined">
                      <CardContent>
                        <Typography variant="subtitle2" color="text.secondary">
                          Efficiency Rate
                        </Typography>
                        <Typography variant="h5" sx={{ fontWeight: 600 }}>
                          94.2%
                        </Typography>
                      </CardContent>
                    </Card>
                    <Card variant="outlined">
                      <CardContent>
                        <Typography variant="subtitle2" color="text.secondary">
                          Downtime
                        </Typography>
                        <Typography variant="h5" sx={{ fontWeight: 600 }}>
                          1.2 hours
                        </Typography>
                      </CardContent>
                    </Card>
                  </Box>
                </Grid>
              </Grid>
            </TabPanel>

            <TabPanel value={tabValue} index={1}>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                Quality Control Metrics
              </Typography>
              <Box
                sx={{
                  height: 400,
                  backgroundColor: 'grey.50',
                  borderRadius: 2,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: '2px dashed',
                  borderColor: 'grey.300'
                }}
              >
                <Typography variant="h6" color="text.secondary">
                  Quality Metrics Chart Placeholder
                </Typography>
              </Box>
            </TabPanel>

            <TabPanel value={tabValue} index={2}>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                Maintenance Performance
              </Typography>
              <Box
                sx={{
                  height: 400,
                  backgroundColor: 'grey.50',
                  borderRadius: 2,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: '2px dashed',
                  borderColor: 'grey.300'
                }}
              >
                <Typography variant="h6" color="text.secondary">
                  Maintenance Reports Chart Placeholder
                </Typography>
              </Box>
            </TabPanel>

            <TabPanel value={tabValue} index={3}>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                Raw Materials Request Analytics
              </Typography>
              
              {/* Request Metrics Cards */}
              <Grid container spacing={3} sx={{ mb: 4 }}>
                <Grid item xs={12} sm={6} md={3}>
                  <Card variant="outlined">
                    <CardContent sx={{ textAlign: 'center' }}>
                      <Typography variant="h4" color="primary" sx={{ fontWeight: 700 }}>
                        {requestMetrics.totalRequests}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Total Requests (5 days)
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Card variant="outlined">
                    <CardContent sx={{ textAlign: 'center' }}>
                      <Typography variant="h4" color="success.main" sx={{ fontWeight: 700 }}>
                        {requestMetrics.todayRequests}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Today's Requests
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Card variant="outlined">
                    <CardContent sx={{ textAlign: 'center' }}>
                      <Typography variant="h4" color="info.main" sx={{ fontWeight: 700 }}>
                        {requestMetrics.approvalRate}%
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Approval Rate
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Card variant="outlined">
                    <CardContent sx={{ textAlign: 'center' }}>
                      <Typography variant="h4" color="warning.main" sx={{ fontWeight: 700 }}>
                        {requestMetrics.averageDaily}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Average Daily Requests
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>

              {/* Request History Table */}
              <Card variant="outlined">
                <CardContent>
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                    Request History (Fragilisation → Raw Materials)
                  </Typography>
                  <TableContainer>
                    <Table>
                      <TableHead>
                        <TableRow>
                          <TableCell>Date</TableCell>
                          <TableCell>Requesting Section</TableCell>
                          <TableCell align="center">Total Requests</TableCell>
                          <TableCell align="center">Approved</TableCell>
                          <TableCell align="center">Rejected</TableCell>
                          <TableCell align="center">Approval Rate</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {rawMaterialsRequests.map((dayData, index) => (
                          <TableRow key={index}>
                            <TableCell>{dayData.date}</TableCell>
                            <TableCell>{dayData.from}</TableCell>
                            <TableCell align="center">
                              <Chip 
                                label={dayData.requests} 
                                color="primary" 
                                size="small"
                                variant="outlined"
                              />
                            </TableCell>
                            <TableCell align="center">
                              <Chip 
                                label={dayData.approved} 
                                color="success" 
                                size="small"
                              />
                            </TableCell>
                            <TableCell align="center">
                              <Chip 
                                label={dayData.rejected} 
                                color="error" 
                                size="small"
                              />
                            </TableCell>
                            <TableCell align="center">
                              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                                {Math.round((dayData.approved / dayData.requests) * 100)}%
                              </Typography>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </CardContent>
              </Card>
            </TabPanel>

            <TabPanel value={tabValue} index={4}>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                Recent Reports
              </Typography>
              <Grid container spacing={2}>
                {recentReports.map((report, index) => (
                  <Grid item xs={12} md={6} key={index}>
                    <Card variant="outlined">
                      <CardContent>
                        <Box display="flex" justifyContent="space-between" alignItems="center">
                          <Box>
                            <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                              {report.name}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              {report.date} • {report.type}
                            </Typography>
                          </Box>
                          <Chip
                            label={report.status}
                            color={report.status === 'Complete' ? 'success' : 'warning'}
                            size="small"
                            variant="outlined"
                          />
                        </Box>
                        <Box mt={2}>
                          <Button size="small" startIcon={<DownloadIcon />}>
                            Download
                          </Button>
                        </Box>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </TabPanel>
          </Card>
        </Container>
      </Box>
    </Box>
  );
};

export default ReportingAnalytics;
