import React from 'react';
import { Container, Typography } from '@mui/material';

const EmballageProduitsFini = () => {
  return (
    <Container>
      <Typography variant="h4">Emballage Produits Fini</Typography>
      {/* Add your content here */}
    </Container>
  );
};

export default EmballageProduitsFini;
