import React, { useState, useEffect } from 'react';
import {
  Container, Typography, Card, CardContent, CardHeader, Grid, Accordion,
  AccordionSummary, AccordionDetails, Chip, Box, Tab, Tabs, List, ListItem,
  ListItemText, ListItemIcon, Divider, Paper, Alert, Button, TextField,
  Dialog, DialogTitle, DialogContent, DialogActions, IconButton, Fab
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  Description as DocumentationIcon,
  Code as CodeIcon,
  Settings as SettingsIcon,
  Analytics as AnalyticsIcon,
  Factory as ManufacturingIcon,
  Security as SecurityIcon,
  QrCode as QrCodeIcon,
  Add as AddIcon,
  Edit as EditIcon,
  Save as SaveIcon,
  Download as DownloadIcon,
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  Info as InfoIcon
} from '@mui/icons-material';
import { useAuth } from './AuthContext';
import AppLayout from './AppLayout';
import NavigationBreadcrumb from './NavigationBreadcrumb';

const DocumentationPage = () => {
  const { userRole } = useAuth();
  const [tabValue, setTabValue] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [newFeatureDialog, setNewFeatureDialog] = useState(false);
  const [newFeature, setNewFeature] = useState({
    section: '',
    feature: '',
    description: '',
    functionality: '',
    parameters: '',
    usage: '',
    permissions: ''
  });

  // Comprehensive documentation data structure
  const [documentationData, setDocumentationData] = useState({
    manufacturing: {
      title: "Manufacturing Operations",
      icon: <ManufacturingIcon />,
      sections: {
        "magasin-matiere-premiere": {
          title: "Raw Material Storage",
          description: "Management system for incoming raw materials and inventory tracking",
          features: {
            "lot-management": {
              name: "Lot Management",
              description: "Create, track, and manage raw material lots",
              functionality: "Allows users to register new lots with batch information, track quality parameters, and monitor inventory levels",
              parameters: "Lot Number, Date of Arrival, Calibre, KOR Test Result, Country of Origin, Weight",
              usage: "Navigate to Raw Material Storage → Add New Lot → Fill required fields → Submit",
              permissions: "Manufacturing Manager, Operator",
              lastUpdated: "2024-01-15"
            },
            "qr-generation": {
              name: "QR Code Generation",
              description: "Generate QR codes for lot tracking and traceability",
              functionality: "Creates unique QR codes for each lot with embedded lot information and tracking capabilities",
              parameters: "Batch Code, Lot Number, Quantity, Sequence Numbers",
              usage: "Select lot → Generate QR Codes → Specify quantity → Download/Print codes",
              permissions: "Manufacturing Manager",
              lastUpdated: "2024-01-15"
            },
            "inventory-tracking": {
              name: "Inventory Tracking",
              description: "Real-time inventory monitoring and stock level alerts",
              functionality: "Tracks current stock levels, consumption rates, and automatically alerts when reorder points are reached",
              parameters: "Stock Level, Reorder Point, Consumption Rate, Alert Thresholds",
              usage: "View dashboard → Monitor stock levels → Set alerts → Receive notifications",
              permissions: "All users",
              lastUpdated: "2024-01-15"
            }
          }
        },
        "fragilisation": {
          title: "Fragilization Process",
          description: "Pre-processing stage for raw material preparation",
          features: {
            "process-control": {
              name: "Process Control",
              description: "Monitor and control fragilization parameters",
              functionality: "Controls temperature, timing, and mechanical parameters for optimal fragilization",
              parameters: "Temperature, Duration, Pressure, Speed Settings",
              usage: "Access control panel → Set parameters → Start process → Monitor progress",
              permissions: "Manufacturing Manager, Operator",
              lastUpdated: "2024-01-15"
            }
          }
        },
        "decorticage": {
          title: "Decorticating Process",
          description: "Shell removal and kernel extraction process",
          features: {
            "shell-removal": {
              name: "Shell Removal Control",
              description: "Automated shell removal with quality monitoring",
              functionality: "Controls decorticating machinery with real-time quality assessment and yield optimization",
              parameters: "Feed Rate, Blade Settings, Quality Thresholds, Yield Targets",
              usage: "Configure machine settings → Start process → Monitor quality metrics → Adjust as needed",
              permissions: "Manufacturing Manager, Operator",
              lastUpdated: "2024-01-15"
            }
          }
        },
        "sechage": {
          title: "Drying Process",
          description: "Moisture control and drying optimization",
          features: {
            "moisture-control": {
              name: "Moisture Control",
              description: "Automated moisture monitoring and drying control",
              functionality: "Maintains optimal moisture levels through controlled drying with continuous monitoring",
              parameters: "Target Moisture %, Temperature, Airflow, Duration",
              usage: "Set target moisture → Configure drying parameters → Start process → Monitor progress",
              permissions: "Manufacturing Manager, Operator",
              lastUpdated: "2024-01-15"
            }
          }
        },
        "depelliculage": {
          title: "Pellicle Removal",
          description: "Final cleaning and pellicle removal process",
          features: {
            "pellicle-removal": {
              name: "Pellicle Removal Control",
              description: "Automated pellicle removal with quality control",
              functionality: "Removes thin skin layer from kernels while maintaining kernel integrity and quality",
              parameters: "Speed Settings, Suction Power, Quality Filters, Rejection Rates",
              usage: "Configure removal parameters → Start process → Monitor quality → Adjust settings",
              permissions: "Manufacturing Manager, Operator",
              lastUpdated: "2024-01-15"
            }
          }
        },
        "classification-epuration": {
          title: "Classification & Purification",
          description: "Final product grading and quality sorting",
          features: {
            "quality-grading": {
              name: "Quality Grading",
              description: "Automated quality assessment and product grading",
              functionality: "Sorts products by quality grades using visual inspection and size classification",
              parameters: "Size Categories, Quality Grades, Defect Thresholds, Sorting Criteria",
              usage: "Configure grading criteria → Start sorting → Monitor quality distribution → Generate reports",
              permissions: "Manufacturing Manager, Operator",
              lastUpdated: "2024-01-15"
            }
          }
        },
        "emballage-produits-fini": {
          title: "Final Product Packaging",
          description: "Packaging and labeling of finished products",
          features: {
            "packaging-control": {
              name: "Packaging Control",
              description: "Automated packaging with weight control and labeling",
              functionality: "Controls packaging machinery, ensures accurate weights, and applies proper labeling",
              parameters: "Package Size, Weight Targets, Label Information, Batch Tracking",
              usage: "Set package specifications → Configure labeling → Start packaging → Monitor weights",
              permissions: "Manufacturing Manager, Operator",
              lastUpdated: "2024-01-15"
            }
          }
        }
      }
    },
    qrTracking: {
      title: "QR Code Tracking System",
      icon: <QrCodeIcon />,
      sections: {
        "qr-scanner": {
          title: "QR Code Scanner",
          description: "Mobile and web-based QR code scanning for traceability",
          features: {
            "scan-tracking": {
              name: "Scan Tracking",
              description: "Track QR code scans throughout the production process",
              functionality: "Records scan events with timestamp, location, user, and process stage information",
              parameters: "QR Code ID, Scanner Location, User ID, Process Stage, Timestamp, Additional Data",
              usage: "Open scanner → Scan QR code → Fill required fields → Submit scan data",
              permissions: "All users",
              lastUpdated: "2024-01-15"
            },
            "form-validation": {
              name: "Dynamic Form System",
              description: "Customizable forms for data collection during scans",
              functionality: "Presents stage-specific forms with validation rules and mandatory fields",
              parameters: "Form Fields, Validation Rules, Mandatory Fields, Stage Configuration",
              usage: "Scan QR code → Complete presented form → Validate data → Submit to backend",
              permissions: "Manufacturing Manager, Operator",
              lastUpdated: "2024-01-15"
            },
            "offline-capability": {
              name: "Offline Scanning",
              description: "Scan capability without internet connection",
              functionality: "Stores scan data locally when offline and syncs when connection is restored",
              parameters: "Local Storage, Sync Queue, Connection Status, Data Validation",
              usage: "Continue scanning offline → Data stored locally → Auto-sync when online",
              permissions: "All users",
              lastUpdated: "2024-01-15"
            }
          }
        },
        "qr-analytics": {
          title: "QR Analytics Dashboard",
          description: "Analytics and reporting for QR code usage and tracking",
          features: {
            "scan-analytics": {
              name: "Scan Analytics",
              description: "Comprehensive analytics on QR code scanning patterns",
              functionality: "Provides insights into scan frequency, user activity, process bottlenecks, and traceability coverage",
              parameters: "Time Ranges, User Filters, Process Stages, Statistical Metrics",
              usage: "Access analytics dashboard → Select filters → View reports → Export data",
              permissions: "Manufacturing Manager, Admin",
              lastUpdated: "2024-01-15"
            },
            "traceability-reports": {
              name: "Traceability Reports",
              description: "Complete traceability chain reports for products",
              functionality: "Generates end-to-end traceability reports showing complete journey of products",
              parameters: "Product ID, Date Ranges, Process Stages, Quality Data, Audit Trail",
              usage: "Select product → Generate traceability report → Review chain → Export report",
              permissions: "Manufacturing Manager, Admin",
              lastUpdated: "2024-01-15"
            }
          }
        },
        "qr-admin": {
          title: "QR Code Administration",
          description: "Administrative controls for QR code management",
          features: {
            "code-activation": {
              name: "Code Activation/Deactivation",
              description: "Admin controls for QR code lifecycle management",
              functionality: "Allows administrators to activate or deactivate QR codes with reason tracking",
              parameters: "QR Code ID, Batch Number, Action Type, Reason, Admin ID, Timestamp",
              usage: "Access admin panel → Select QR code → Choose action → Provide reason → Confirm",
              permissions: "Admin only",
              lastUpdated: "2024-01-15"
            },
            "deactivated-management": {
              name: "Deactivated Code Management",
              description: "Management system for deactivated QR codes",
              functionality: "Maintains folder structure for deactivated codes with reason tracking and audit trail",
              parameters: "Deactivation Reason, Admin ID, Timestamp, Original Code Data, Folder Structure",
              usage: "View deactivated codes → Filter by reason → Review audit trail → Reactivate if needed",
              permissions: "Admin only",
              lastUpdated: "2024-01-15"
            }
          }
        }
      }
    },
    systemManagement: {
      title: "System Management",
      icon: <SettingsIcon />,
      sections: {
        "user-management": {
          title: "User Management",
          description: "Comprehensive user account creation, management, and access control system",
          features: {
            "user-creation": {
              name: "User Account Creation",
              description: "Create new user accounts with role assignment and license management",
              functionality: "Allows administrators to create new user accounts, assign roles, set permissions, and configure license types with automatic expiration",
              parameters: "Username, Email, Password, Role (admin/manufacturing_manager/operator), License Type (trial/basic/professional/enterprise), Permissions Array",
              usage: "Admin Settings → User Management → Add User → Fill details → Select license type → Save",
              permissions: "Admin only",
              lastUpdated: "2024-01-15"
            },
            "user-deletion": {
              name: "User Account Deletion",
              description: "Secure deletion of user accounts with audit trail",
              functionality: "Allows administrators to permanently delete user accounts with confirmation dialog and audit logging. Prevents self-deletion of admin accounts",
              parameters: "User ID, Admin ID (for audit), Confirmation Dialog, Deletion Reason",
              usage: "Admin Settings → User Management → Select User → Delete → Confirm → Provide reason",
              permissions: "Admin only (cannot delete own account)",
              lastUpdated: "2024-01-15"
            },
            "user-editing": {
              name: "User Account Modification",
              description: "Edit existing user account details and permissions",
              functionality: "Modify user information including username, email, role assignment, and license type changes with automatic license recalculation",
              parameters: "User ID, Username, Email, Role, Status, License Type, Updated Permissions",
              usage: "Admin Settings → User Management → Select User → Edit → Modify fields → Save",
              permissions: "Admin only",
              lastUpdated: "2024-01-15"
            },
            "license-management": {
              name: "License System Management",
              description: "Comprehensive license management with trial periods and expiration tracking",
              functionality: "Manages user licenses with different tiers, automatic expiration tracking, trial period management, and license extension capabilities",
              parameters: "License Type (trial/basic/professional/enterprise), Duration (7/30/90/365 days), Features Array, Expiration Date, Trial Status",
              usage: "Admin Settings → User Management → Select User → Manage License → Set type/duration → Save",
              permissions: "Admin only",
              lastUpdated: "2024-01-15"
            },
            "license-extension": {
              name: "License Extension System",
              description: "Extend user licenses with configurable duration",
              functionality: "Allows administrators to extend user licenses, change license types, and manage trial to paid conversions with automatic feature access updates",
              parameters: "User ID, Extension Duration (days), New License Type, Extension Reason, Admin ID",
              usage: "Admin Settings → Licenses → Select User → Extend License → Set duration → Confirm",
              permissions: "Admin only",
              lastUpdated: "2024-01-15"
            },
            "license-revocation": {
              name: "License Revocation System",
              description: "Revoke user licenses with reason tracking",
              functionality: "Immediately revokes user access by changing license status to revoked, logs revocation reason, and updates user status to inactive",
              parameters: "User ID, Revocation Reason, Admin ID, Revocation Timestamp",
              usage: "Admin Settings → Licenses → Select User → Revoke License → Provide reason → Confirm",
              permissions: "Admin only",
              lastUpdated: "2024-01-15"
            }
          }
        },
        "data-operations": {
          title: "Data Operations",
          description: "Data import, export, and backup management",
          features: {
            "data-import": {
              name: "Data Import System",
              description: "Import data from external sources and files",
              functionality: "Supports multiple file formats for data import with validation and error handling",
              parameters: "File Format, Data Type, Validation Rules, Error Handling, Batch Size",
              usage: "Select import type → Upload file → Validate data → Review errors → Import",
              permissions: "Admin only",
              lastUpdated: "2024-01-15"
            },
            "data-export": {
              name: "Data Export System",
              description: "Export system data in various formats for analysis",
              functionality: "Exports data in multiple formats with filtering and customization options",
              parameters: "Export Format, Date Range, Data Tables, Filters, Compression Options",
              usage: "Configure export → Select data → Choose format → Generate file → Download",
              permissions: "Admin, Manufacturing Manager",
              lastUpdated: "2024-01-15"
            },
            "backup-management": {
              name: "Backup Management",
              description: "Automated and manual backup operations",
              functionality: "Manages system backups with scheduling, retention policies, and restoration capabilities",
              parameters: "Backup Schedule, Retention Period, Storage Location, Compression, Encryption",
              usage: "Configure backup settings → Schedule backups → Monitor status → Restore if needed",
              permissions: "Admin only",
              lastUpdated: "2024-01-15"
            }
          }
        }
      }
    },
    analytics: {
      title: "Analytics & Reporting",
      icon: <AnalyticsIcon />,
      sections: {
        "maintenance-analytics": {
          title: "Maintenance Analytics",
          description: "Predictive maintenance and equipment monitoring",
          features: {
            "predictive-maintenance": {
              name: "Predictive Maintenance System",
              description: "AI-powered predictive maintenance for manufacturing equipment",
              functionality: "Uses machine learning to predict equipment failures and optimize maintenance schedules",
              parameters: "Sensor Data, Historical Maintenance, Failure Patterns, Alert Thresholds",
              usage: "Monitor equipment health → Review predictions → Schedule maintenance → Track performance",
              permissions: "Manufacturing Manager, Maintenance Team",
              lastUpdated: "2024-01-15"
            }
          }
        },
        "production-analytics": {
          title: "Production Analytics",
          description: "Production performance monitoring and optimization",
          features: {
            "performance-tracking": {
              name: "Production Performance Tracking",
              description: "Real-time monitoring of production metrics and KPIs",
              functionality: "Tracks production rates, quality metrics, downtime, and efficiency indicators",
              parameters: "Production Rate, Quality Score, Downtime Duration, Efficiency %, OEE",
              usage: "View production dashboard → Monitor KPIs → Analyze trends → Generate reports",
              permissions: "Manufacturing Manager, Operator",
              lastUpdated: "2024-01-15"
            }
          }
        }
      }
    }
  });

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleAddFeature = () => {
    // Add new feature to documentation
    const updatedData = { ...documentationData };
    const section = updatedData[newFeature.section];
    if (section && section.sections[newFeature.feature]) {
      section.sections[newFeature.feature].features[Date.now()] = {
        name: newFeature.feature,
        description: newFeature.description,
        functionality: newFeature.functionality,
        parameters: newFeature.parameters,
        usage: newFeature.usage,
        permissions: newFeature.permissions,
        lastUpdated: new Date().toISOString().split('T')[0]
      };
      setDocumentationData(updatedData);
    }
    setNewFeatureDialog(false);
    setNewFeature({
      section: '',
      feature: '',
      description: '',
      functionality: '',
      parameters: '',
      usage: '',
      permissions: ''
    });
  };

  const filteredSections = Object.entries(documentationData).filter(([key, section]) =>
    section.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    Object.values(section.sections).some(subsection =>
      subsection.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      Object.values(subsection.features).some(feature =>
        feature.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        feature.description.toLowerCase().includes(searchTerm.toLowerCase())
      )
    )
  );

  const renderFeatureDocumentation = (feature, featureKey) => (
    <Card key={featureKey} sx={{ mb: 2, border: '1px solid #e0e0e0' }}>
      <CardHeader
        title={feature.name}
        subheader={`Last Updated: ${feature.lastUpdated}`}
        action={
          <Chip
            label={feature.permissions}
            color="primary"
            variant="outlined"
            size="small"
          />
        }
      />
      <CardContent>
        <Typography variant="body2" color="text.secondary" paragraph>
          {feature.description}
        </Typography>

        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="subtitle2">Functionality Details</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body2" paragraph>
              <strong>How it works:</strong> {feature.functionality}
            </Typography>
            <Typography variant="body2" paragraph>
              <strong>Parameters:</strong> {feature.parameters}
            </Typography>
            <Typography variant="body2" paragraph>
              <strong>Usage Instructions:</strong> {feature.usage}
            </Typography>
            <Typography variant="body2">
              <strong>Required Permissions:</strong> {feature.permissions}
            </Typography>
          </AccordionDetails>
        </Accordion>
      </CardContent>
    </Card>
  );

  const renderSectionDocumentation = (section, sectionKey) => (
    <Accordion key={sectionKey} sx={{ mb: 1 }}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
        <Box display="flex" alignItems="center">
          {section.icon}
          <Typography variant="h6" sx={{ ml: 1 }}>
            {section.title}
          </Typography>
        </Box>
      </AccordionSummary>
      <AccordionDetails>
        {Object.entries(section.sections).map(([subsectionKey, subsection]) => (
          <Box key={subsectionKey} sx={{ mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              {subsection.title}
            </Typography>
            <Typography variant="body2" color="text.secondary" paragraph>
              {subsection.description}
            </Typography>

            {Object.entries(subsection.features).map(([featureKey, feature]) =>
              renderFeatureDocumentation(feature, featureKey)
            )}
          </Box>
        ))}
      </AccordionDetails>
    </Accordion>
  );

  const generateDocumentationTemplate = () => {
    return `
# ICARUS System Documentation Template

## New Feature Documentation Routine

### When implementing a new feature or workflow, follow these steps:

1. **Feature Identification**
   - Feature Name: [Unique identifier for the feature]
   - Section: [Which system section this belongs to]
   - Type: [Workflow, Function, Component, API, etc.]

2. **Functional Description**
   - Purpose: [What problem does this solve?]
   - Description: [Brief overview of the feature]
   - Functionality: [Detailed explanation of how it works]

3. **Technical Specifications**
   - Parameters: [Input parameters, configuration options]
   - Dependencies: [Required components, services, permissions]
   - Integration Points: [How it connects with other features]

4. **Usage Documentation**
   - User Instructions: [Step-by-step usage guide]
   - Access Requirements: [Required permissions/roles]
   - Prerequisites: [What needs to be set up first]

5. **Quality Assurance**
   - Testing Procedures: [How to test the feature]
   - Validation Steps: [How to verify it works correctly]
   - Error Handling: [What to do when things go wrong]

6. **Maintenance Information**
   - Update Schedule: [When this needs to be reviewed]
   - Responsible Team: [Who maintains this feature]
   - Related Documentation: [Links to related docs]

### Documentation Update Process:
1. Create feature documentation using this template
2. Add to the appropriate section in DocumentationPage.jsx
3. Update the feature registry in the documentation data structure
4. Test the documentation for accuracy and completeness
5. Review with team members for clarity and completeness
6. Publish and notify relevant users

### Quality Standards:
- All features must have complete documentation before deployment
- Documentation must be updated within 24 hours of feature release
- All documentation must be reviewed by at least one team member
- Usage examples must be tested and verified
- Screenshots should be included for UI features
    `;
  };

  return (
    <AppLayout>
      <Container maxWidth="xl" sx={{ py: 3 }}>
        <NavigationBreadcrumb />

        <Box display="flex" alignItems="center" justifyContent="space-between" mb={3}>
          <Box display="flex" alignItems="center">
            <DocumentationIcon sx={{ mr: 2, fontSize: 32, color: 'primary.main' }} />
            <Typography variant="h4" fontWeight={700}>
              System Documentation
            </Typography>
          </Box>

          {userRole === 'admin' && (
            <Box display="flex" gap={2}>
              <Button
                variant="outlined"
                startIcon={<DownloadIcon />}
                onClick={() => {
                  const template = generateDocumentationTemplate();
                  const blob = new Blob([template], { type: 'text/markdown' });
                  const url = URL.createObjectURL(blob);
                  const link = document.createElement('a');
                  link.href = url;
                  link.download = 'documentation-template.md';
                  link.click();
                }}
              >
                Download Template
              </Button>
              <Button
                variant="contained"
                startIcon={<AddIcon />}
                onClick={() => setNewFeatureDialog(true)}
              >
                Add Feature
              </Button>
            </Box>
          )}
        </Box>

        <Alert severity="info" sx={{ mb: 3 }}>
          <Typography variant="body2">
            <strong>Documentation Routine:</strong> This documentation is automatically updated when new features are added. 
            All developers must document new features using the standardized template and update this registry within 24 hours of deployment.
          </Typography>
        </Alert>

        <TextField
          fullWidth
          label="Search Documentation"
          variant="outlined"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          sx={{ mb: 3 }}
        />

        <Paper sx={{ width: '100%' }}>
          <Box sx={{ p: 3 }}>
            {filteredSections.map(([sectionKey, section]) =>
              renderSectionDocumentation(section, sectionKey)
            )}
          </Box>
        </Paper>

        {/* Add Feature Dialog */}
        <Dialog open={newFeatureDialog} onClose={() => setNewFeatureDialog(false)} maxWidth="md" fullWidth>
          <DialogTitle>Add New Feature Documentation</DialogTitle>
          <DialogContent>
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Section"
                  value={newFeature.section}
                  onChange={(e) => setNewFeature({ ...newFeature, section: e.target.value })}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Feature Name"
                  value={newFeature.feature}
                  onChange={(e) => setNewFeature({ ...newFeature, feature: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Description"
                  multiline
                  rows={2}
                  value={newFeature.description}
                  onChange={(e) => setNewFeature({ ...newFeature, description: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Functionality"
                  multiline
                  rows={3}
                  value={newFeature.functionality}
                  onChange={(e) => setNewFeature({ ...newFeature, functionality: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Parameters"
                  multiline
                  rows={2}
                  value={newFeature.parameters}
                  onChange={(e) => setNewFeature({ ...newFeature, parameters: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Usage Instructions"
                  multiline
                  rows={3}
                  value={newFeature.usage}
                  onChange={(e) => setNewFeature({ ...newFeature, usage: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Required Permissions"
                  value={newFeature.permissions}
                  onChange={(e) => setNewFeature({ ...newFeature, permissions: e.target.value })}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setNewFeatureDialog(false)}>Cancel</Button>
            <Button onClick={handleAddFeature} variant="contained">
              Add Feature
            </Button>
          </DialogActions>
        </Dialog>

        {userRole === 'admin' && (
          <Fab
            color="primary"
            aria-label="add documentation"
            sx={{ position: 'fixed', bottom: 16, right: 16 }}
            onClick={() => setNewFeatureDialog(true)}
          >
            <AddIcon />
          </Fab>
        )}
      </Container>
    </AppLayout>
  );
};

export default DocumentationPage;