
import React from 'react';
import { useAuth } from './AuthContext';
import { Paper, Typography, Button, Box, Alert } from '@mui/material';
import { Security as SecurityIcon, Block as BlockIcon } from '@mui/icons-material';

const ProtectedRoute = ({ children, requiredPermission, fallbackMessage = "Access Denied" }) => {
  const { isAuthenticated, hasPermission, user, userRole } = useAuth();

  if (!isAuthenticated) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <Paper elevation={3} sx={{ p: 4, textAlign: 'center', maxWidth: 500 }}>
          <SecurityIcon sx={{ fontSize: 60, color: 'warning.main', mb: 2 }} />
          <Typography variant="h5" gutterBottom>
            Authentication Required
          </Typography>
          <Typography variant="body1" color="text.secondary" mb={3}>
            You must be logged in to access this section.
          </Typography>
          <Button 
            variant="contained" 
            color="primary" 
            href="/"
          >
            Return to Login
          </Button>
        </Paper>
      </Box>
    );
  }

  if (requiredPermission && !hasPermission(requiredPermission)) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <Paper elevation={3} sx={{ p: 4, textAlign: 'center', maxWidth: 500 }}>
          <BlockIcon sx={{ fontSize: 60, color: 'error.main', mb: 2 }} />
          <Typography variant="h5" gutterBottom color="error">
            Access Denied
          </Typography>
          <Typography variant="body1" color="text.secondary" mb={2}>
            {fallbackMessage}
          </Typography>
          <Alert severity="warning" sx={{ mb: 3 }}>
            <Typography variant="body2">
              <strong>User:</strong> {user?.name}<br />
              <strong>Role:</strong> {userRole}<br />
              <strong>Required Permission:</strong> {requiredPermission}
            </Typography>
          </Alert>
          <Button 
            variant="contained" 
            color="primary" 
            href="/main-dashboard"
          >
            Return to Dashboard
          </Button>
        </Paper>
      </Box>
    );
  }

  return children;
};

export default ProtectedRoute;
