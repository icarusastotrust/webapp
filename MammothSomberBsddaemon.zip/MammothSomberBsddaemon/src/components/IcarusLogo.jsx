
import React from 'react';
import { Box, Typography } from '@mui/material';
import { styled } from '@mui/system';

const LogoContainer = styled(Box)({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  flexDirection: 'column',
  marginBottom: '20px',
});

const LogoIcon = styled(Box)({
  width: '80px',
  height: '80px',
  borderRadius: '50%',
  background: 'linear-gradient(135deg, #1976d2, #42a5f5)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  marginBottom: '10px',
  boxShadow: '0 4px 20px rgba(25, 118, 210, 0.3)',
  animation: 'pulse 2s infinite',
  '@keyframes pulse': {
    '0%': {
      transform: 'scale(1)',
      boxShadow: '0 4px 20px rgba(25, 118, 210, 0.3)',
    },
    '50%': {
      transform: 'scale(1.05)',
      boxShadow: '0 6px 30px rgba(25, 118, 210, 0.5)',
    },
    '100%': {
      transform: 'scale(1)',
      boxShadow: '0 4px 20px rgba(25, 118, 210, 0.3)',
    },
  },
});

const LogoText = styled(Typography)({
  fontWeight: 'bold',
  color: '#1976d2',
  textAlign: 'center',
  fontSize: '3rem',
  textShadow: '2px 2px 4px rgba(0,0,0,0.1)',
});

const IcarusLogo = ({ size = 'large' }) => {
  const isSmall = size === 'small';
  
  return (
    <LogoContainer>
      <LogoIcon sx={{ 
        width: isSmall ? '40px' : '80px', 
        height: isSmall ? '40px' : '80px' 
      }}>
        <Typography 
          variant="h4" 
          sx={{ 
            color: 'white', 
            fontWeight: 'bold',
            fontSize: isSmall ? '1.2rem' : '2rem'
          }}
        >
          I
        </Typography>
      </LogoIcon>
      <LogoText variant={isSmall ? "h6" : "h4"}>
        ICARUS SYSTEM
      </LogoText>
      {!isSmall && (
        <Typography variant="subtitle1" color="text.secondary" textAlign="center">
          Integrated Control & Advanced Reporting Universal System
        </Typography>
      )}
    </LogoContainer>
  );
};

export default IcarusLogo;
