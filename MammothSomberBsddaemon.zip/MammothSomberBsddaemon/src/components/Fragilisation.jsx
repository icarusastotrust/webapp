import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Paper, 
  TextField, 
  Button, 
  List, 
  ListItem, 
  ListItemText,
  Alert,
  Box,
  Chip,
  Card,
  CardContent,
  Divider,
  Badge,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid
} from '@mui/material';
import { 
  Notifications as NotificationsIcon,
  CheckCircle as CheckCircleIcon,
  Schedule as ScheduleIcon,
  Send as SendIcon,
  Add as AddIcon 
} from '@mui/icons-material';

const Fragilisation = () => {
  const [requestData, setRequestData] = useState({
    caliber: '',
    numBags: '',
    rawCashew: '',
    netWeight: ''
  });
  const [requests, setRequests] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [warehouseRequestData, setWarehouseRequestData] = useState({
    requestType: 'material_request',
    caliber: '',
    quantity: '',
    urgency: 'normal',
    notes: ''
  });
  const [showWarehouseRequestForm, setShowWarehouseRequestForm] = useState(false);
  const [sentRequests, setSentRequests] = useState([]);

  // Simulate receiving notifications from Raw Materials
  useEffect(() => {
    // Listen for notifications (in real implementation, this would be via WebSocket or API polling)
    const interval = setInterval(() => {
      // This is a simulation - in real app, you'd check for new notifications
      const mockNotifications = JSON.parse(localStorage.getItem('fragilisation_notifications') || '[]');
      if (mockNotifications.length > notifications.length) {
        setNotifications(mockNotifications);
        setUnreadCount(mockNotifications.filter(n => !n.read).length);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [notifications.length]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setRequestData({
      ...requestData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setRequests([...requests, requestData]);
    setRequestData({
      caliber: '',
      numBags: '',
      rawCashew: '',
      netWeight: ''
    });
  };

  const markNotificationAsRead = (notificationId) => {
    const updatedNotifications = notifications.map(n => 
      n.id === notificationId ? { ...n, read: true } : n
    );
    setNotifications(updatedNotifications);
    setUnreadCount(updatedNotifications.filter(n => !n.read).length);
    localStorage.setItem('fragilisation_notifications', JSON.stringify(updatedNotifications));
  };

  const acknowledgeQRBatch = (notification) => {
    markNotificationAsRead(notification.id);
    // Add to processing queue or handle as needed
    alert(`QR batch acknowledged for lot ${notification.data.lotNumber}. Ready for fragilisation processing.`);
  };

  const handleWarehouseRequestChange = (e) => {
    const { name, value } = e.target;
    setWarehouseRequestData({
      ...warehouseRequestData,
      [name]: value
    });
  };

  const sendRequestToWarehouse = () => {
    const request = {
      id: Date.now(),
      timestamp: new Date().toISOString(),
      from: 'Fragilisation Section',
      to: 'Raw Materials Warehouse',
      type: warehouseRequestData.requestType,
      status: 'pending',
      data: {
        caliber: warehouseRequestData.caliber,
        quantity: warehouseRequestData.quantity,
        urgency: warehouseRequestData.urgency,
        notes: warehouseRequestData.notes
      }
    };

    // Store in localStorage for Raw Materials warehouse to receive
    const existingRequests = JSON.parse(localStorage.getItem('warehouse_requests') || '[]');
    const updatedRequests = [...existingRequests, request];
    localStorage.setItem('warehouse_requests', JSON.stringify(updatedRequests));

    // Add to sent requests for tracking
    setSentRequests([...sentRequests, request]);

    // Reset form
    setWarehouseRequestData({
      requestType: 'material_request',
      caliber: '',
      quantity: '',
      urgency: 'normal',
      notes: ''
    });
    setShowWarehouseRequestForm(false);

    alert(`Request sent to Raw Materials warehouse for ${warehouseRequestData.quantity} units of caliber ${warehouseRequestData.caliber}`);
  };

  return (
    <Container>
      <Box display="flex" alignItems="center" justifyContent="space-between" sx={{ mb: 3 }}>
        <Typography variant="h4">
          Fragilisation Section
        </Typography>
        <Badge badgeContent={unreadCount} color="error">
          <IconButton>
            <NotificationsIcon />
          </IconButton>
        </Badge>
      </Box>

      {/* Notifications Section */}
      {notifications.length > 0 && (
        <Paper sx={{ p: 2, mb: 3 }}>
          <Typography variant="h6" gutterBottom>
            QR Batch Notifications from Raw Materials
          </Typography>
          {notifications.slice(-3).reverse().map((notification) => (
            <Card key={notification.id} sx={{ mb: 2, border: notification.read ? 'none' : '2px solid #4caf50' }}>
              <CardContent>
                <Box display="flex" justifyContent="space-between" alignItems="start">
                  <Box>
                    <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                      {notification.message}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                      Lot: {notification.data.lotNumber} | Batch: {notification.data.batchNumber}
                    </Typography>
                    <Box display="flex" gap={1} sx={{ mb: 1 }}>
                      <Chip label={`${notification.data.weight}kg`} size="small" />
                      <Chip label={notification.data.calibre} size="small" />
                      <Chip label={`${notification.data.qrCodesGenerated} QR codes`} size="small" color="success" />
                    </Box>
                    <Typography variant="caption" color="text.secondary">
                      From: {notification.from} | {new Date(notification.timestamp).toLocaleString()}
                    </Typography>
                  </Box>
                  <Box>
                    {!notification.read && (
                      <Button
                        variant="contained"
                        size="small"
                        startIcon={<CheckCircleIcon />}
                        onClick={() => acknowledgeQRBatch(notification)}
                        sx={{ mr: 1 }}
                      >
                        Acknowledge
                      </Button>
                    )}
                    <Chip 
                      label={notification.read ? "Read" : "New"} 
                      color={notification.read ? "default" : "success"}
                      size="small"
                    />
                  </Box>
                </Box>
              </CardContent>
            </Card>
          ))}
        </Paper>
      )}

      <Divider sx={{ mb: 3 }} />

      {/* Request to Warehouse Section */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box display="flex" justifyContent="between" alignItems="center" sx={{ mb: 2 }}>
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Request Raw Materials from Warehouse
          </Typography>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => setShowWarehouseRequestForm(true)}
            sx={{ ml: 'auto' }}
          >
            New Request
          </Button>
        </Box>

        {/* Sent Requests List */}
        {sentRequests.length > 0 && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
              Recent Requests:
            </Typography>
            {sentRequests.slice(-3).reverse().map((request) => (
              <Card key={request.id} sx={{ mb: 1, backgroundColor: '#f8f9fa' }}>
                <CardContent sx={{ py: 2 }}>
                  <Box display="flex" justifyContent="between" alignItems="center">
                    <Box>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {request.data.quantity} units - Caliber {request.data.caliber}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {new Date(request.timestamp).toLocaleString()} | Priority: {request.data.urgency}
                      </Typography>
                    </Box>
                    <Chip label={request.status} size="small" color="warning" />
                  </Box>
                  {request.data.notes && (
                    <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                      Notes: {request.data.notes}
                    </Typography>
                  )}
                </CardContent>
              </Card>
            ))}
          </Box>
        )}
      </Paper>

      <Divider sx={{ mb: 3 }} />
      <Paper style={{ padding: '20px', marginBottom: '20px' }}>
        <form onSubmit={handleSubmit}>
          <TextField
            label="Caliber"
            name="caliber"
            value={requestData.caliber}
            onChange={handleChange}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Number of Bags"
            name="numBags"
            value={requestData.numBags}
            onChange={handleChange}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Raw Cashew"
            name="rawCashew"
            value={requestData.rawCashew}
            onChange={handleChange}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Net Weight"
            name="netWeight"
            value={requestData.netWeight}
            onChange={handleChange}
            fullWidth
            margin="normal"
          />
          <Button type="submit" variant="contained" color="primary" fullWidth>
            Submit Request
          </Button>
        </form>
      </Paper>
      <Typography variant="h5" gutterBottom>
        Submitted Requests
      </Typography>
      <List>
        {requests.map((request, index) => (
          <ListItem key={index}>
            <ListItemText
              primary={`Caliber: ${request.caliber}, Bags: ${request.numBags}, Raw Cashew: ${request.rawCashew}, Net Weight: ${request.netWeight}`}
            />
          </ListItem>
        ))}
      </List>

      {/* Warehouse Request Dialog */}
      <Dialog open={showWarehouseRequestForm} onClose={() => setShowWarehouseRequestForm(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Request Raw Materials from Warehouse</DialogTitle>
        <DialogContent>
          <Grid container spacing={3} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Request Type</InputLabel>
                <Select
                  name="requestType"
                  value={warehouseRequestData.requestType}
                  onChange={handleWarehouseRequestChange}
                  label="Request Type"
                >
                  <MenuItem value="material_request">Material Request</MenuItem>
                  <MenuItem value="quality_check">Quality Check Request</MenuItem>
                  <MenuItem value="urgent_supply">Urgent Supply</MenuItem>
                  <MenuItem value="batch_inquiry">Batch Inquiry</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Caliber"
                name="caliber"
                value={warehouseRequestData.caliber}
                onChange={handleWarehouseRequestChange}
                placeholder="e.g., 180-200"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Quantity (kg)"
                name="quantity"
                type="number"
                value={warehouseRequestData.quantity}
                onChange={handleWarehouseRequestChange}
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Urgency</InputLabel>
                <Select
                  name="urgency"
                  value={warehouseRequestData.urgency}
                  onChange={handleWarehouseRequestChange}
                  label="Urgency"
                >
                  <MenuItem value="low">Low</MenuItem>
                  <MenuItem value="normal">Normal</MenuItem>
                  <MenuItem value="high">High</MenuItem>
                  <MenuItem value="urgent">Urgent</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Notes"
                name="notes"
                value={warehouseRequestData.notes}
                onChange={handleWarehouseRequestChange}
                multiline
                rows={3}
                placeholder="Additional requirements or specifications..."
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowWarehouseRequestForm(false)}>Cancel</Button>
          <Button 
            variant="contained" 
            startIcon={<SendIcon />}
            onClick={sendRequestToWarehouse}
            disabled={!warehouseRequestData.caliber || !warehouseRequestData.quantity}
          >
            Send Request
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default Fragilisation;
