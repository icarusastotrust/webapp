import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Grid,
  Paper,
  Box,
  Card,
  CardContent,
  IconButton,
  AppBar,
  Toolbar,
  Avatar,
  Badge,
  Button,
  Chip,
  LinearProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Fab,
  Alert,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider
} from '@mui/material';
import {
  Inventory as InventoryIcon,
  Add as AddIcon,
  Search as SearchIcon,
  FilterList as FilterListIcon,
  Notifications as NotificationsIcon,
  Settings as SettingsIcon,
  MenuBook as MenuBookIcon,
  Menu as MenuIcon,
  ArrowBack as ArrowBackIcon,
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  Error as ErrorIcon,
  QrCode as QrCodeIcon,
  Download as DownloadIcon,
  Print as PrintIcon,
  Visibility as VisibilityIcon,
  Analytics as AnalyticsIcon
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import ModuleSidebar from './ModuleSidebar';
import TopBanner from './TopBanner';
import NavigationBreadcrumb from './NavigationBreadcrumb';

const MagasinMatierePremiere = () => {
  const navigate = useNavigate();
  const { user, userRole } = useAuth();
  const [navigationOpen, setNavigationOpen] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [openDialog, setOpenDialog] = useState(false);
  const [openQRDialog, setOpenQRDialog] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [selectedLot, setSelectedLot] = useState(null);
  const [qrGenerationData, setQrGenerationData] = useState({
    batchCode: '',
    quantity: 1,
    sequenceStart: 1
  });
  const [generatedQRCodes, setGeneratedQRCodes] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [incomingRequests, setIncomingRequests] = useState([]);
  const [newLot, setNewLot] = useState({
    lotNumber: '',
    dateOfArriving: new Date().toISOString().split('T')[0],
    calibre: '',
    korTestResult: '',
    country: '',
    weight: '',
    supplier: '',
    storage: '',
    price: ''
  });

  // Analytics state for request tracking
  const [requestAnalytics, setRequestAnalytics] = useState({
    totalRequests: 0,
    todayRequests: 0,
    weeklyRequests: 0,
    monthlyRequests: 0,
    requestHistory: []
  });

  // Monitor incoming requests from Fragilisation
  useEffect(() => {
    const interval = setInterval(() => {
      const requests = JSON.parse(localStorage.getItem('warehouse_requests') || '[]');
      if (requests.length > incomingRequests.length) {
        setIncomingRequests(requests);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [incomingRequests.length]);

  // Sample data for raw materials with QR code tracking
  const [materials, setMaterials] = useState([
    {
      id: 'RM001',
      lotNumber: 'LOT-2024-001',
      name: 'Raw Cashew Nuts - Grade A',
      supplier: 'West Africa Suppliers Ltd',
      quantity: 2500,
      unit: 'kg',
      qualityStatus: 'approved',
      arrivalDate: '2024-01-10',
      expiryDate: '2024-07-10',
      batchNumber: 'WAS-240110-001',
      storage: 'Warehouse A-1',
      price: 3.50,
      calibre: '180-200',
      korTestResult: '95%',
      country: 'Ivory Coast',
      weight: 2500,
      qrCodesGenerated: 0,
      hasQRCodes: false
    },
    {
      id: 'RM002',
      lotNumber: 'LOT-2024-002',
      name: 'Raw Cashew Nuts - Grade B',
      supplier: 'Ivory Coast Traders',
      quantity: 1800,
      unit: 'kg',
      qualityStatus: 'pending',
      arrivalDate: '2024-01-12',
      expiryDate: '2024-07-12',
      batchNumber: 'ICT-240112-002',
      storage: 'Warehouse A-2',
      price: 3.20,
      calibre: '200-240',
      korTestResult: '92%',
      country: 'Ghana',
      weight: 1800,
      qrCodesGenerated: 25,
      hasQRCodes: true
    },
    {
      id: 'RM003',
      lotNumber: 'LOT-2024-003',
      name: 'Packaging Materials',
      supplier: 'Local Packaging Co',
      quantity: 500,
      unit: 'units',
      qualityStatus: 'rejected',
      arrivalDate: '2024-01-08',
      expiryDate: '2025-01-08',
      batchNumber: 'LPC-240108-003',
      storage: 'Warehouse B-1',
      price: 0.75,
      calibre: 'N/A',
      korTestResult: 'N/A',
      country: 'Local',
      weight: 500,
      qrCodesGenerated: 0,
      hasQRCodes: false
    }
  ]);

  const handleNavigationToggle = () => {
    setNavigationOpen(!navigationOpen);
  };

  const handleMouseEnterTrigger = () => {
    setIsHovering(true);
    setNavigationOpen(true);
  };

  const handleMouseLeaveTrigger = () => {
    setIsHovering(false);
    setTimeout(() => {
      if (!isHovering) {
        setNavigationOpen(false);
      }
    }, 300);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved': return 'success';
      case 'pending': return 'warning';
      case 'rejected': return 'error';
      default: return 'default';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved': return <CheckCircleIcon />;
      case 'pending': return <WarningIcon />;
      case 'rejected': return <ErrorIcon />;
      default: return <CheckCircleIcon />;
    }
  };

  const handleAddLot = () => {
    const lotId = `RM${(materials.length + 1).toString().padStart(3, '0')}`;
    const newLotData = {
      id: lotId,
      lotNumber: newLot.lotNumber,
      name: newLot.name || 'Raw Cashew Nuts',
      supplier: newLot.supplier,
      quantity: parseInt(newLot.weight),
      unit: 'kg',
      qualityStatus: 'pending',
      arrivalDate: newLot.dateOfArriving,
      expiryDate: new Date(new Date(newLot.dateOfArriving).getTime() + 180*24*60*60*1000).toISOString().split('T')[0],
      batchNumber: `${newLot.supplier.substring(0,3).toUpperCase()}-${newLot.dateOfArriving.replace(/-/g, '')}-${(materials.length + 1).toString().padStart(3, '0')}`,
      storage: newLot.storage,
      price: parseFloat(newLot.price),
      calibre: newLot.calibre,
      korTestResult: newLot.korTestResult,
      country: newLot.country,
      weight: parseInt(newLot.weight),
      qrCodesGenerated: 0,
      hasQRCodes: false
    };

    setMaterials([...materials, newLotData]);
    setOpenDialog(false);
    setNewLot({
      lotNumber: '',
      dateOfArriving: new Date().toISOString().split('T')[0],
      calibre: '',
      korTestResult: '',
      country: '',
      weight: '',
      supplier: '',
      storage: '',
      price: ''
    });
  };

  const handleQRGeneration = (lot) => {
    setSelectedLot(lot);
    setQrGenerationData({
      batchCode: lot.batchNumber,
      quantity: 1,
      sequenceStart: lot.qrCodesGenerated + 1
    });
    setOpenQRDialog(true);
    setActiveStep(0);
  };

  const generateQRCodes = () => {
    const codes = [];
    for (let i = 0; i < qrGenerationData.quantity; i++) {
      const sequenceNumber = qrGenerationData.sequenceStart + i;
      const uniqueId = `${qrGenerationData.batchCode}-${sequenceNumber.toString().padStart(4, '0')}`;
      const qrData = {
        uniqueId,
        batchCode: qrGenerationData.batchCode,
        lotNumber: selectedLot.lotNumber,
        sequenceNumber,
        timestamp: new Date().toISOString(),
        data: {
          supplier: selectedLot.supplier,
          country: selectedLot.country,
          calibre: selectedLot.calibre,
          korTest: selectedLot.korTestResult,
          weight: selectedLot.weight
        }
      };
      codes.push(qrData);
    }

    setGeneratedQRCodes(codes);

    // Update the lot with new QR code count
    const updatedMaterials = materials.map(material => 
      material.id === selectedLot.id 
        ? { 
            ...material, 
            qrCodesGenerated: material.qrCodesGenerated + qrGenerationData.quantity,
            hasQRCodes: true
          }
        : material
    );
    setMaterials(updatedMaterials);

    setActiveStep(1);
  };

  const respondToRequest = (requestId, response) => {
    const updatedRequests = incomingRequests.map(req => 
      req.id === requestId 
        ? { ...req, status: response, responseTime: new Date().toISOString() }
        : req
    );
    setIncomingRequests(updatedRequests);
    localStorage.setItem('warehouse_requests', JSON.stringify(updatedRequests));

    alert(`Request ${response} successfully!`);
  };

  const sendNotificationToFragilisation = (lot, qrCodeCount) => {
    const notification = {
      id: Date.now(),
      timestamp: new Date().toISOString(),
      from: 'Raw Materials Warehouse',
      to: 'Fragilisation Section',
      type: 'QR_BATCH_READY',
      message: `QR batch ready for processing`,
      read: false,
      data: {
        lotNumber: lot.lotNumber,
        batchNumber: lot.batchNumber,
        supplier: lot.supplier,
        weight: lot.weight,
        calibre: lot.calibre,
        qrCodesGenerated: qrCodeCount,
        country: lot.country,
        korTestResult: lot.korTestResult
      }
    };

    // Store in localStorage for Fragilisation component to receive
    const existingNotifications = JSON.parse(localStorage.getItem('fragilisation_notifications') || '[]');
    const updatedNotifications = [...existingNotifications, notification];
    localStorage.setItem('fragilisation_notifications', JSON.stringify(updatedNotifications));

    // Send notification to backend (you can implement actual API call here)
    console.log('Sending notification to Fragilisation:', notification);

    // Add to local notifications for demonstration
    setNotifications(prev => [...prev, notification]);

    // Show success message
    alert(`Notification sent to Fragilisation section for lot ${lot.lotNumber} with ${qrCodeCount} QR codes ready for processing.`);
  };

  const steps = [
    {
      label: 'Configure QR Generation',
      description: 'Set batch parameters'
    },
    {
      label: 'Review Generated Codes',
      description: 'Verify and download'
    }
  ];

  const filteredMaterials = materials.filter(material =>
    material.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    material.supplier.toLowerCase().includes(searchTerm.toLowerCase()) ||
    material.batchNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    material.lotNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalValue = materials.reduce((sum, material) => sum + (material.quantity * material.price), 0);
  const approvedCount = materials.filter(m => m.qualityStatus === 'approved').length;
  const pendingCount = materials.filter(m => m.qualityStatus === 'pending').length;
  const totalQRCodes = materials.reduce((sum, material) => sum + material.qrCodesGenerated, 0);

  // Handle incoming requests from other sections
  useEffect(() => {
    const handleMessage = (event) => {
      if (event.data.type === 'REQUEST_BATCH') {
        const newRequest = {
          id: `REQ-${Date.now()}`,
          from: event.data.from,
          lotId: event.data.lotId,
          requestedQuantity: event.data.quantity,
          timestamp: new Date().toISOString(),
          status: 'pending'
        };

        setIncomingRequests(prev => [...prev, newRequest]);

        // Update analytics
        updateRequestAnalytics(newRequest);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  // Function to update request analytics
  const updateRequestAnalytics = (newRequest) => {
    const now = new Date();
    const today = now.toDateString();
    const thisWeek = getWeekNumber(now);
    const thisMonth = now.getMonth();

    setRequestAnalytics(prev => {
      const updatedHistory = [...prev.requestHistory, {
        ...newRequest,
        date: now.toISOString().split('T')[0],
        week: thisWeek,
        month: thisMonth
      }];

      // Calculate metrics
      const todayRequests = updatedHistory.filter(req => 
        new Date(req.timestamp).toDateString() === today
      ).length;

      const weeklyRequests = updatedHistory.filter(req => 
        req.week === thisWeek && new Date(req.timestamp).getFullYear() === now.getFullYear()
      ).length;

      const monthlyRequests = updatedHistory.filter(req => 
        req.month === thisMonth && new Date(req.timestamp).getFullYear() === now.getFullYear()
      ).length;

      return {
        totalRequests: updatedHistory.length,
        todayRequests,
        weeklyRequests,
        monthlyRequests,
        requestHistory: updatedHistory
      };
    });
  };

  // Helper function to get week number
  const getWeekNumber = (date) => {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  };

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', backgroundColor: '#f8fafc', position: 'relative' }}>
      <TopBanner />

      {/* Hover trigger zone for navigation */}
      <Box
        sx={{
          position: 'fixed',
          left: 0,
          top: 0,
          width: '20px',
          height: '100vh',
          zIndex: 1300,
          backgroundColor: 'transparent'
        }}
        onMouseEnter={handleMouseEnterTrigger}
      />

      <ModuleSidebar 
        open={navigationOpen} 
        onToggle={handleNavigationToggle}
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={handleMouseLeaveTrigger}
      />

      <Box 
        component="main" 
        sx={{ 
          flexGrow: 1,
          transition: 'margin-left 0.3s ease',
          marginLeft: 0,
          width: '100%',
          minHeight: '100vh'
        }}
      >
        {/* Modern Header */}
        <AppBar 
          position="static" 
          elevation={0}
          sx={{ 
            backgroundColor: 'white',
            borderBottom: '1px solid #e0e7ff',
            color: 'text.primary',
            backdropFilter: 'blur(10px)'
          }}
        >
          <Toolbar sx={{ py: 1 }}>
            <IconButton
              onClick={handleNavigationToggle}
              sx={{ mr: 2, color: 'primary.main' }}
            >
              <MenuIcon />
            </IconButton>
            <IconButton
              onClick={() => navigate('/main-dashboard')}
              sx={{ mr: 2, color: 'primary.main' }}
            >
              <ArrowBackIcon />
            </IconButton>
            <InventoryIcon sx={{ mr: 2, color: 'primary.main', fontSize: 32 }} />
            <Box sx={{ flexGrow: 1 }}>
              <Typography variant="h5" sx={{ fontWeight: 700, color: 'primary.main' }}>
                Raw Materials Warehouse
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Lot management and QR code traceability system
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button
                color="inherit"
                startIcon={<SettingsIcon />}
                onClick={() => navigate('/settings')}
                sx={{ color: 'primary.main' }}
              >
                Settings
              </Button>
              <Button
                color="inherit"
                startIcon={<MenuBookIcon />}
                onClick={() => navigate('/documentation')}
                sx={{ color: 'primary.main' }}
              >
                Docs
              </Button>
            </Box>

            <Box display="flex" alignItems="center" gap={3}>
              <Badge badgeContent={notifications.length} color="error">
                <IconButton>
                  <NotificationsIcon />
                </IconButton>
              </Badge>

              <Box display="flex" alignItems="center" gap={2}>
                <Avatar sx={{ bgcolor: 'primary.main', width: 40, height: 40 }}>
                  {user?.name?.charAt(0)}
                </Avatar>
                <Box>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                    {user?.name}
                  </Typography>
                  <Chip 
                    label={userRole} 
                    size="small" 
                    color="primary"
                    variant="outlined"
                    sx={{ height: 20, fontSize: '0.6rem' }}
                  />
                </Box>
              </Box>
            </Box>
          </Toolbar>
        </AppBar>

        <Container maxWidth="xl" sx={{ py: 4 }}>
          <NavigationBreadcrumb />

          {/* Hero Section */}
          <Card 
            sx={{ 
              mb: 4,
              background: 'linear-gradient(135deg, #2e7d32 0%, #4caf50 100%)',
              color: 'white',
              borderRadius: 3
            }}
          >
            <CardContent sx={{ p: 4 }}>
              <Grid container spacing={4} alignItems="center">
                <Grid item xs={12} md={8}>
                  <Typography variant="h3" sx={{ fontWeight: 700, mb: 2 }}>
                    Raw Materials & QR Traceability
                  </Typography>
                  <Typography variant="h6" sx={{ opacity: 0.9, mb: 3 }}>
                    Complete lot management system with QR code generation for full traceability
                  </Typography>
                  <Box display="flex" gap={2}>
                    <Button 
                      variant="contained" 
                      size="large"
                      onClick={() => setOpenDialog(true)}
                      sx={{ 
                        backgroundColor: 'white', 
                        color: 'primary.main',
                        '&:hover': { backgroundColor: 'grey.100' }
                      }}
                    >
                      Add New Lot
                    </Button>
                    <Button 
                      variant="outlined" 
                      size="large"
                      startIcon={<QrCodeIcon />}
                      sx={{ 
                        borderColor: 'white', 
                        color: 'white',
                        '&:hover': { backgroundColor: 'rgba(255,255,255,0.1)' }
                      }}
                    >
                      QR Analytics
                    </Button>
                  </Box>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Box textAlign="center">
                    <InventoryIcon sx={{ fontSize: 120, opacity: 0.3 }} />
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Request Analytics Section */}
          <Card sx={{ mb: 3, borderRadius: 3 }}>
            <CardContent>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                <AnalyticsIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                Request Analytics
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12} sm={6} md={3}>
                  <Card variant="outlined" sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h4" color="primary" sx={{ fontWeight: 700 }}>
                      {requestAnalytics.totalRequests}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Total Requests
                    </Typography>
                  </Card>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Card variant="outlined" sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h4" color="success.main" sx={{ fontWeight: 700 }}>
                      {requestAnalytics.todayRequests}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Today's Requests
                    </Typography>
                  </Card>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Card variant="outlined" sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h4" color="info.main" sx={{ fontWeight: 700 }}>
                      {requestAnalytics.weeklyRequests}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      This Week
                    </Typography>
                  </Card>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Card variant="outlined" sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h4" color="warning.main" sx={{ fontWeight: 700 }}>
                      {requestAnalytics.monthlyRequests}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      This Month
                    </Typography>
                  </Card>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Incoming Requests from Fragilisation */}
          {incomingRequests.length > 0 && (
            <Card sx={{ mb: 4, borderRadius: 3 }}>
              <CardContent>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                  Incoming Requests from Fragilisation
                </Typography>
                {incomingRequests.slice(-3).reverse().map((request) => (
                  <Card key={request.id} sx={{ mb: 2, border: request.status === 'pending' ? '2px solid #ff9800' : 'none' }}>
                    <CardContent>
                      <Grid container spacing={2} alignItems="center">
                        <Grid item xs={12} md={8}>
                          <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                            {request.type.replace('_', ' ').toUpperCase()}
                          </Typography>
                          <Box display="flex" gap={1} sx={{ mb: 1 }}>
                            <Chip label={`${request.data.quantity}kg`} size="small" />
                            <Chip label={`Caliber: ${request.data.caliber}`} size="small" />
                            <Chip label={request.data.urgency} size="small" color={
                              request.data.urgency === 'urgent' ? 'error' : 
                              request.data.urgency === 'high' ? 'warning' : 'default'
                            } />
                          </Box>
                          <Typography variant="body2" color="text.secondary">
                            From: {request.from} | {new Date(request.timestamp).toLocaleString()}
                          </Typography>
                          {request.data.notes && (
                            <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                              Notes: {request.data.notes}
                            </Typography>
                          )}
                        </Grid>
                        <Grid item xs={12} md={4}>
                          <Box display="flex" gap={1} justifyContent="flex-end">
                            {request.status === 'pending' && (
                              <>
                                <Button
                                  variant="contained"
                                  color="success"
                                  size="small"
                                  onClick={() => respondToRequest(request.id, 'approved')}
                                >
                                  Approve
                                </Button>
                                <Button
                                  variant="outlined"
                                  color="error"
                                  size="small"
                                  onClick={() => respondToRequest(request.id, 'rejected')}
                                >
                                  Reject
                                </Button>
                              </>
                            )}
                            <Chip 
                              label={request.status || 'pending'} 
                              color={
                                request.status === 'approved' ? 'success' : 
                                request.status === 'rejected' ? 'error' : 'warning'
                              }
                              size="small"
                            />
                          </Box>
                        </Grid>
                      </Grid>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Quick Stats */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ borderRadius: 3 }}>
                <CardContent>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    Total Lots
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>
                    {materials.length}
                  </Typography>
                  <Chip label="Active" size="small" color="success" variant="outlined" />
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ borderRadius: 3 }}>
                <CardContent>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    Total Value
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>
                    ${totalValue.toLocaleString()}
                  </Typography>
                  <Chip label="+5.2%" size="small" color="success" variant="outlined" />
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ borderRadius: 3 }}>
                <CardContent>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    QR Codes Generated
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>
                    {totalQRCodes}
                  </Typography>
                  <Chip label="Traceability" size="small" color="info" variant="outlined" />
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ borderRadius: 3 }}>
                <CardContent>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    Approved Lots
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>
                    {approvedCount}
                  </Typography>
                  <Chip label="Quality OK" size="small" color="success" variant="outlined" />
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* Search and Filters */}
          <Card sx={{ mb: 4, borderRadius: 3 }}>
            <CardContent>
              <Grid container spacing={3} alignItems="center">
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    placeholder="Search lots, suppliers, or batch numbers..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    InputProps={{
                      startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} />
                    }}
                    sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <Box display="flex" gap={2} justifyContent="flex-end">
                    <Button
                      variant="outlined"
                      startIcon={<FilterListIcon />}
                      sx={{ borderRadius: 2 }}
                    >
                      Filter
                    </Button>
                    <Button
                      variant="contained"
                      startIcon={<AddIcon />}
                      onClick={() => setOpenDialog(true)}
                      sx={{ borderRadius: 2 }}
                    >
                      Add Lot
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Materials Table */}
          <Card sx={{ borderRadius: 3 }}>
            <CardContent>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                Raw Materials Inventory
              </Typography>
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 600 }}>Lot Number</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Material & Supplier</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Weight/Quantity</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Quality Status</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Calibre & KOR</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>QR Codes</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {filteredMaterials.map((material) => (
                      <TableRow key={material.id} hover>
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 600, fontFamily: 'monospace' }}>
                            {material.lotNumber}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {material.country}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Box>
                            <Typography variant="body2" sx={{ fontWeight: 500 }}>
                              {material.name}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {material.supplier}
                            </Typography>
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {material.weight.toLocaleString()} {material.unit}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            ${(material.weight * material.price).toLocaleString()}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            icon={getStatusIcon(material.qualityStatus)}
                            label={material.qualityStatus.toUpperCase()}
                            color={getStatusColor(material.qualityStatus)}
                            size="small"
                            variant="outlined"
                          />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {material.calibre}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            KOR: {material.korTestResult}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Box display="flex" alignItems="center" gap={1}>
                            <Chip
                              label={material.qrCodesGenerated}
                              color={material.hasQRCodes ? "success" : "default"}
                              size="small"
                            />
                            {material.hasQRCodes && <QrCodeIcon color="success" fontSize="small" />}
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Box display="flex" gap={1}>
                            <IconButton
                              size="small"
                              onClick={() => handleQRGeneration(material)}
                              color="primary"
                              title="Generate QR Codes"
                            >
                              <QrCodeIcon />
                            </IconButton>
                            <IconButton 
                              size="small" 
                              color="default"
                              title="View Details"
                            >
                              <VisibilityIcon />
                            </IconButton>
                            {material.hasQRCodes && (
                              <IconButton
                                size="small"
                                color="success"
                                onClick={() => sendNotificationToFragilisation(material, material.qrCodesGenerated)}
                                title="Notify Fragilisation"
                              >
                                <NotificationsIcon />
                              </IconButton>
                            )}
                          </Box>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Container>

        {/* Floating Action Button */}
        <Fab
          color="primary"
          aria-label="add"
          onClick={() => setOpenDialog(true)}
          sx={{
            position: 'fixed',
            bottom: 32,
            right: 32,
            zIndex: 1000
          }}
        >
          <AddIcon />
        </Fab>

        {/* Add Lot Dialog */}
        <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="md" fullWidth>
          <DialogTitle>Add New Raw Material Lot</DialogTitle>
          <DialogContent>
            <Grid container spacing={3} sx={{ mt: 1 }}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Lot Number"
                  value={newLot.lotNumber}
                  onChange={(e) => setNewLot({...newLot, lotNumber: e.target.value})}
                  variant="outlined"
                  placeholder="LOT-2024-XXX"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Date of Arrival"
                  type="date"
                  value={newLot.dateOfArriving}
                  onChange={(e) => setNewLot({...newLot, dateOfArriving: e.target.value})}
                  variant="outlined"
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Supplier"
                  value={newLot.supplier}
                  onChange={(e) => setNewLot({...newLot, supplier: e.target.value})}
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Country of Origin"
                  value={newLot.country}
                  onChange={(e) => setNewLot({...newLot, country: e.target.value})}
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Weight (kg)"
                  type="number"
                  value={newLot.weight}
                  onChange={(e) => setNewLot({...newLot, weight: e.target.value})}
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Calibre"
                  value={newLot.calibre}
                  onChange={(e) => setNewLot({...newLot, calibre: e.target.value})}
                  variant="outlined"
                  placeholder="e.g., 180-200"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="KOR Test Result"
                  value={newLot.korTestResult}
                  onChange={(e) => setNewLot({...newLot, korTestResult: e.target.value})}
                  variant="outlined"
                  placeholder="e.g., 95%"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Storage Location"
                  value={newLot.storage}
                  onChange={(e) => setNewLot({...newLot, storage: e.target.value})}
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Price per kg ($)"
                  type="number"
                  step="0.01"
                  value={newLot.price}
                  onChange={(e) => setNewLot({...newLot, price: e.target.value})}
                  variant="outlined"
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
            <Button variant="contained" onClick={handleAddLot}>
              Add Lot
            </Button>
          </DialogActions>
        </Dialog>

        {/* QR Code Generation Dialog */}
        <Dialog open={openQRDialog} onClose={() => setOpenQRDialog(false)} maxWidth="md" fullWidth>
          <DialogTitle>
            Generate QR Codes for {selectedLot?.lotNumber}
          </DialogTitle>
          <DialogContent>
            <Stepper activeStep={activeStep} orientation="vertical" sx={{ mt: 2 }}>
              {steps.map((step, index) => (
                <Step key={step.label}>
                  <StepLabel>{step.label}</StepLabel>
                  <StepContent>
                    {index === 0 && (
                      <Box sx={{ mt: 2 }}>
                        <Grid container spacing={3}>
                          <Grid item xs={12}>
                            <Alert severity="info" sx={{ mb: 3 }}>
                              Generating QR codes for lot: {selectedLot?.lotNumber} ({selectedLot?.supplier})
                            </Alert>
                          </Grid>
                          <Grid item xs={12} md={6}>
                            <TextField
                              fullWidth
                              label="Batch Code"
                              value={qrGenerationData.batchCode}
                              onChange={(e) => setQrGenerationData({
                                ...qrGenerationData,
                                batchCode: e.target.value
                              })}
                              variant="outlined"
                            />
                          </Grid>
                          <Grid item xs={12} md={6}>
                            <TextField
                              fullWidth
                              label="Number of QR Codes"
                              type="number"
                              value={qrGenerationData.quantity}
                              onChange={(e) => setQrGenerationData({
                                ...qrGenerationData,
                                quantity: parseInt(e.target.value) || 1
                              })}
                              variant="outlined"
                              inputProps={{ min: 1, max: 1000 }}
                            />
                          </Grid>
                          <Grid item xs={12}>
                            <Typography variant="body2" color="text.secondary">
                              Sequence will start from: {qrGenerationData.sequenceStart}
                            </Typography>
                          </Grid>
                        </Grid>
                        <Box sx={{ mt: 3 }}>
                          <Button
                            variant="contained"
                            onClick={generateQRCodes}
                            disabled={!qrGenerationData.batchCode || qrGenerationData.quantity < 1}
                          >
                            Generate QR Codes
                          </Button>
                        </Box>
                      </Box>
                    )}
                    {index === 1 && (
                      <Box sx={{ mt: 2 }}>
                        <Typography variant="h6" sx={{ mb: 2 }}>
                          Generated {generatedQRCodes.length} QR Codes
                        </Typography>
                        <Box sx={{ maxHeight: 300, overflow: 'auto', mb: 3 }}>
                          {generatedQRCodes.map((qr, idx) => (
                            <Paper key={idx} sx={{ p: 2, mb: 1 }}>
                              <Grid container spacing={2} alignItems="center">
                                <Grid item xs={3}>
                                  <Box 
                                    sx={{ 
                                      width: 80, 
                                      height: 80, 
                                      backgroundColor: '#f0f0f0', 
                                      display: 'flex', 
                                      alignItems: 'center', 
                                      justifyContent: 'center',
                                      border: '2px solid #ddd'
                                    }}
                                  >
                                    <QrCodeIcon sx={{ fontSize: 40 }} />
                                  </Box>
                                </Grid>
                                <Grid item xs={9}>
                                  <Typography variant="subtitle2" sx={{ fontFamily: 'monospace' }}>
                                    {qr.uniqueId}
                                  </Typography>
                                  <Typography variant="caption" color="text.secondary">
                                    Sequence: {qr.sequenceNumber} | Lot: {qr.lotNumber}
                                  </Typography>
                                </Grid>
                              </Grid>
                            </Paper>
                          ))}
                        </Box>
                        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                          <Button
                            variant="contained"
                            startIcon={<DownloadIcon />}
                            onClick={() => {
                              const dataStr = JSON.stringify(generatedQRCodes, null, 2);
                              const dataBlob = new Blob([dataStr], { type: 'application/json' });
                              const url = URL.createObjectURL(dataBlob);
                              const link = document.createElement('a');
                              link.href = url;
                              link.download = `qr-codes-${selectedLot?.lotNumber}-${new Date().toISOString().split('T')[0]}.json`;
                              link.click();
                            }}
                          >
                            Download JSON
                          </Button>
                          <Button
                            variant="outlined"
                            startIcon={<PrintIcon />}
                          >
                            Print Codes
                          </Button>
                          <Button
                            variant="contained"
                            color="success"
                            startIcon={<NotificationsIcon />}
                            onClick={() => sendNotificationToFragilisation(selectedLot, generatedQRCodes.length)}
                            sx={{ backgroundColor: '#4caf50' }}
                          >
                            Notify Fragilisation
                          </Button>
                        </Box>
                      </Box>
                    )}
                  </StepContent>
                </Step>
              ))}
            </Stepper>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenQRDialog(false)}>Close</Button>
            {activeStep === 1 && (
              <Button 
                variant="contained" 
                onClick={() => setOpenQRDialog(false)}
              >
                Complete
              </Button>
            )}
          </DialogActions>
        </Dialog>
      </Box>
    </Box>
  );
};

export default MagasinMatierePremiere;