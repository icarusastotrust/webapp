import React from 'react';
import { Container, Typography } from '@mui/material';

const Sechage = () => {
  return (
    <Container>
      <Typography variant="h4">Séchange</Typography>
      {/* Add your content here */}
    </Container>
  );
};

export default Sechage;
