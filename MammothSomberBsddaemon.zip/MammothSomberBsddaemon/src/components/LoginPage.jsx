
import React, { useState } from "react";
import { Container, TextField, Button, Typography, Paper, MenuItem, Select, InputLabel, FormControl, Dialog, DialogTitle, DialogContent, DialogActions, Alert, Box, Chip } from "@mui/material";
import { styled } from "@mui/system";
import { useNavigate } from "react-router-dom";
import { useAuth } from "./AuthContext";
import IcarusLogo from "./IcarusLogo";
import backgroundImage from "/test.png";

const RootContainer = styled('div')({
  minHeight: '100vh',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundImage: `url(${backgroundImage})`,
  backgroundSize: 'cover',
  backgroundPosition: 'center',
  backgroundAttachment: 'fixed',
  position: 'relative',
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    zIndex: 1,
  },
});

const StyledPaper = styled(Paper)({
  padding: '40px 30px',
  maxWidth: 450,
  width: '100%',
  position: 'relative',
  zIndex: 2,
  borderRadius: '16px',
  boxShadow: '0 20px 40px rgba(0,0,0,0.3)',
  background: 'rgba(255, 255, 255, 0.95)',
  backdropFilter: 'blur(10px)',
  border: '1px solid rgba(255, 255, 255, 0.2)',
});

const StyledButton = styled(Button)({
  marginTop: 16,
  padding: '12px 0',
  borderRadius: '8px',
  fontWeight: 'bold',
  textTransform: 'none',
  fontSize: '1.1rem',
  transition: 'all 0.3s ease',
  '&:hover': {
    transform: 'translateY(-2px)',
    boxShadow: '0 8px 20px rgba(25, 118, 210, 0.3)',
  },
});

const AnimatedTextField = styled(TextField)({
  '& .MuiOutlinedInput-root': {
    borderRadius: '8px',
    transition: 'all 0.3s ease',
    '&:hover': {
      transform: 'translateY(-1px)',
    },
    '&.Mui-focused': {
      transform: 'translateY(-1px)',
      boxShadow: '0 4px 12px rgba(25, 118, 210, 0.2)',
    },
  },
});

const LoginPage = () => {
  const navigate = useNavigate();
  const { login, isAuthenticated } = useAuth();
  const [openRegister, setOpenRegister] = useState(false);
  const [openForgotPassword, setOpenForgotPassword] = useState(false);
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [registerData, setRegisterData] = useState({ username: '', password: '', confirmPassword: '', email: '' });
  const [forgotPasswordData, setForgotPasswordData] = useState({ email: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Redirect if already authenticated
  React.useEffect(() => {
    if (isAuthenticated) {
      navigate('/main-dashboard');
    }
  }, [isAuthenticated, navigate]);

  const handleRegisterOpen = () => setOpenRegister(true);
  const handleRegisterClose = () => setOpenRegister(false);

  const handleForgotPasswordOpen = () => setOpenForgotPassword(true);
  const handleForgotPasswordClose = () => setOpenForgotPassword(false);

  const handleLoginChange = (e) => {
    const { name, value } = e.target;
    setLoginData({ ...loginData, [name]: value });
    setError(''); // Clear error when user types
  };

  const handleLogin = async () => {
    if (!loginData.email || !loginData.password) {
      setError('Please enter both email and password');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const result = await login(loginData);
      if (result.success) {
        navigate('/main-dashboard');
      }
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterChange = (e) => {
    const { name, value } = e.target;
    setRegisterData({ ...registerData, [name]: value });
  };

  const handleForgotPasswordChange = (e) => {
    const { name, value } = e.target;
    setForgotPasswordData({ ...forgotPasswordData, [name]: value });
  };

  const handleRegister = () => {
    // Implement your register logic here
    handleRegisterClose();
  };

  const handleForgotPassword = () => {
    // Implement your forgot password logic here
    handleForgotPasswordClose();
  };

  return (
    <RootContainer>
      <StyledPaper elevation={24}>
        <IcarusLogo />
        
        <Typography variant="h5" align="center" gutterBottom sx={{ fontWeight: 600, color: '#1976d2', mb: 1 }}>
          Secure Access Portal
        </Typography>
        <Typography variant="body2" align="center" color="text.secondary" sx={{ mb: 3 }}>
          Welcome to the Industrial Control System
        </Typography>
        
        {error && (
          <Alert severity="error" sx={{ mb: 2, borderRadius: '8px' }}>
            {error}
          </Alert>
        )}

        <AnimatedTextField 
          fullWidth 
          label="Email Address" 
          name="email"
          type="email"
          value={loginData.email}
          onChange={handleLoginChange}
          margin="normal"
          variant="outlined"
        />
        <AnimatedTextField 
          fullWidth 
          label="Password" 
          name="password"
          type="password" 
          value={loginData.password}
          onChange={handleLoginChange}
          margin="normal"
          variant="outlined"
        />
        <StyledButton 
          variant="contained" 
          color="primary" 
          fullWidth 
          onClick={handleLogin}
          disabled={loading}
          size="large"
        >
          {loading ? 'Authenticating...' : 'Access System'}
        </StyledButton>

        {/* Demo Credentials */}
        <Box mt={3} p={2} bgcolor="rgba(25, 118, 210, 0.05)" borderRadius={2} border="1px solid rgba(25, 118, 210, 0.1)">
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, color: '#1976d2' }}>
            Demo Access Credentials:
          </Typography>
          <Box display="flex" flexDirection="column" gap={1}>
            <Chip 
              label="🔴 Admin: admin@icarus.com / admin123" 
              size="small" 
              color="error"
              onClick={() => setLoginData({email: 'admin@icarus.com', password: 'admin123'})}
              sx={{ cursor: 'pointer', '&:hover': { transform: 'scale(1.02)' } }}
            />
            <Chip 
              label="🟠 Manager: manager@icarus.com / manager123" 
              size="small" 
              color="warning"
              onClick={() => setLoginData({email: 'manager@icarus.com', password: 'manager123'})}
              sx={{ cursor: 'pointer', '&:hover': { transform: 'scale(1.02)' } }}
            />
            <Chip 
              label="🔵 Operator: operator@icarus.com / operator123" 
              size="small" 
              color="info"
              onClick={() => setLoginData({email: 'operator@icarus.com', password: 'operator123'})}
              sx={{ cursor: 'pointer', '&:hover': { transform: 'scale(1.02)' } }}
            />
            <Chip 
              label="🟢 Guest: guest@icarus.com / guest123" 
              size="small" 
              color="success"
              onClick={() => setLoginData({email: 'guest@icarus.com', password: 'guest123'})}
              sx={{ cursor: 'pointer', '&:hover': { transform: 'scale(1.02)' } }}
            />
          </Box>
        </Box>

        <Box display="flex" gap={1} mt={2}>
          <StyledButton variant="text" color="primary" fullWidth onClick={handleRegisterOpen}>
            Create Account
          </StyledButton>
          <StyledButton variant="text" color="primary" fullWidth onClick={handleForgotPasswordOpen}>
            Reset Password
          </StyledButton>
        </Box>

        {/* Register Dialog */}
        <Dialog open={openRegister} onClose={handleRegisterClose} maxWidth="sm" fullWidth>
          <DialogTitle sx={{ textAlign: 'center', pb: 1 }}>
            <Typography variant="h5" sx={{ fontWeight: 600, color: '#1976d2' }}>
              Create New Account
            </Typography>
          </DialogTitle>
          <DialogContent>
            <TextField
              autoFocus
              margin="dense"
              label="Full Name"
              type="text"
              fullWidth
              name="username"
              value={registerData.username}
              onChange={handleRegisterChange}
              variant="outlined"
            />
            <TextField
              margin="dense"
              label="Email Address"
              type="email"
              fullWidth
              name="email"
              value={registerData.email}
              onChange={handleRegisterChange}
              variant="outlined"
            />
            <TextField
              margin="dense"
              label="Password"
              type="password"
              fullWidth
              name="password"
              value={registerData.password}
              onChange={handleRegisterChange}
              variant="outlined"
            />
            <TextField
              margin="dense"
              label="Confirm Password"
              type="password"
              fullWidth
              name="confirmPassword"
              value={registerData.confirmPassword}
              onChange={handleRegisterChange}
              variant="outlined"
            />
          </DialogContent>
          <DialogActions sx={{ p: 3 }}>
            <Button onClick={handleRegisterClose} color="primary" variant="outlined">
              Cancel
            </Button>
            <Button onClick={handleRegister} color="primary" variant="contained">
              Create Account
            </Button>
          </DialogActions>
        </Dialog>

        {/* Forgot Password Dialog */}
        <Dialog open={openForgotPassword} onClose={handleForgotPasswordClose} maxWidth="sm" fullWidth>
          <DialogTitle sx={{ textAlign: 'center', pb: 1 }}>
            <Typography variant="h5" sx={{ fontWeight: 600, color: '#1976d2' }}>
              Reset Password
            </Typography>
          </DialogTitle>
          <DialogContent>
            <TextField
              autoFocus
              margin="dense"
              label="Email Address"
              type="email"
              fullWidth
              name="email"
              value={forgotPasswordData.email}
              onChange={handleForgotPasswordChange}
              variant="outlined"
            />
          </DialogContent>
          <DialogActions sx={{ p: 3 }}>
            <Button onClick={handleForgotPasswordClose} color="primary" variant="outlined">
              Cancel
            </Button>
            <Button onClick={handleForgotPassword} color="primary" variant="contained">
              Send Reset Link
            </Button>
          </DialogActions>
        </Dialog>
      </StyledPaper>
    </RootContainer>
  );
};

export default LoginPage;
