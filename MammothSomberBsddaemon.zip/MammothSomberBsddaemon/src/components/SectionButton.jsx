
import React from 'react';
import { Button, Box, Typography, Card, CardContent } from '@mui/material';
import { Link } from 'react-router-dom';

const SectionButton = ({ title, link, icon, subtitle, variant = 'button' }) => {
  if (variant === 'card') {
    return (
      <Card 
        component={Link}
        to={link}
        sx={{
          textDecoration: 'none',
          height: '100%',
          cursor: 'pointer',
          border: '1px solid #e1e5e9',
          borderRadius: '4px',
          transition: 'all 0.2s ease',
          '&:hover': {
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            transform: 'translateY(-1px)',
            borderColor: '#0078d4'
          }
        }}
        elevation={0}
      >
        <CardContent sx={{ p: 3, height: '100%', display: 'flex', flexDirection: 'column' }}>
          <Box display="flex" alignItems="center" mb={2}>
            <Box sx={{ color: '#0078d4', mr: 2 }}>
              {icon}
            </Box>
            <Typography variant="h6" sx={{ fontWeight: 600, color: '#323130' }}>
              {title}
            </Typography>
          </Box>
          {subtitle && (
            <Typography variant="body2" color="text.secondary" sx={{ flexGrow: 1 }}>
              {subtitle}
            </Typography>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <Box sx={{ p: 1 }}>
      <Button
        component={Link}
        to={link}
        variant="outlined"
        fullWidth
        startIcon={icon}
        sx={{
          minHeight: subtitle ? 120 : 100,
          fontSize: '14px',
          fontWeight: 500,
          flexDirection: 'column',
          alignItems: 'center',
          textTransform: 'none',
          backgroundColor: 'white',
          border: '1px solid #e1e5e9',
          color: '#323130',
          borderRadius: '4px',
          transition: 'all 0.2s ease',
          '&:hover': {
            backgroundColor: '#f8f9fa',
            borderColor: '#0078d4',
            transform: 'translateY(-1px)',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          },
          '& .MuiButton-startIcon': {
            margin: 0,
            marginBottom: subtitle ? 1 : 0.5,
            color: '#0078d4'
          }
        }}
      >
        <Typography variant="body2" component="div" sx={{ fontWeight: 600, textAlign: 'center' }}>
          {title}
        </Typography>
        {subtitle && (
          <Typography variant="caption" component="div" sx={{ 
            opacity: 0.7, 
            mt: 0.5,
            textAlign: 'center',
            lineHeight: 1.2
          }}>
            {subtitle}
          </Typography>
        )}
      </Button>
    </Box>
  );
};

export default SectionButton;
