import React from 'react';
import { Container, Typography } from '@mui/material';

const ClassificationEpuration = () => {
  return (
    <Container>
      <Typography variant="h4">Classification + Épuration</Typography>
      {/* Add your content here */}
    </Container>
  );
};

export default ClassificationEpuration;
