import React from 'react';
import { Bar } from 'react-chartjs-2';
import { Container, Typography, Paper } from '@mui/material';

const QualityComparisonChart = ({ data }) => {
  const chartData = {
    labels: ['Moisture', 'Free Fatty Acids', 'Peroxide Value', 'Aflatoxin', 'E. coli', 'Salmonella', 'Listeria', 'Staphylococcus'],
    datasets: [
      {
        label: 'AYGOS',
        backgroundColor: 'rgba(75,192,192,0.4)',
        borderColor: 'rgba(75,192,192,1)',
        borderWidth: 1,
        hoverBackgroundColor: 'rgba(75,192,192,0.6)',
        hoverBorderColor: 'rgba(75,192,192,1)',
        data: [
          data.moistureContent,
          data.freeFattyAcids,
          data.peroxideValue,
          data.aflatoxin,
          data.eColi,
          data.salmonella,
          data.listeria,
          data.staphylococcus,
        ],
      },
      {
        label: 'International Standard',
        backgroundColor: 'rgba(153,102,255,0.4)',
        borderColor: 'rgba(153,102,255,1)',
        borderWidth: 1,
        hoverBackgroundColor: 'rgba(153,102,255,0.6)',
        hoverBorderColor: 'rgba(153,102,255,1)',
        data: [5, 1.5, 5, 0, 0, 0, 0, 10],
      },
    ],
  };

  const options = {
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <Container component="main" maxWidth="md">
      <Paper style={{ padding: '20px', marginTop: '20px' }}>
        <Typography variant="h5" component="h1" gutterBottom>
          Quality Comparison
        </Typography>
        <Bar data={chartData} options={options} />
      </Paper>
    </Container>
  );
};

export default QualityComparisonChart;
