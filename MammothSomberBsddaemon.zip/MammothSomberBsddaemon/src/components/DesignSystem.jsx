
import { createTheme } from '@mui/material/styles';

export const designTokens = {
  colors: {
    primary: {
      50: '#e3f2fd',
      100: '#bbdefb',
      500: '#2196f3',
      600: '#1976d2',
      700: '#1565c0',
      900: '#0d47a1'
    },
    secondary: {
      50: '#f3e5f5',
      100: '#e1bee7',
      500: '#9c27b0',
      600: '#8e24aa',
      700: '#7b1fa2'
    },
    success: {
      50: '#e8f5e8',
      500: '#4caf50',
      700: '#388e3c'
    },
    warning: {
      50: '#fff3e0',
      500: '#ff9800',
      700: '#f57c00'
    },
    error: {
      50: '#ffebee',
      500: '#f44336',
      700: '#d32f2f'
    },
    neutral: {
      50: '#fafafa',
      100: '#f5f5f5',
      200: '#eeeeee',
      300: '#e0e0e0',
      400: '#bdbdbd',
      500: '#9e9e9e',
      600: '#757575',
      700: '#616161',
      800: '#424242',
      900: '#212121'
    },
    background: {
      default: '#fafafa',
      paper: '#ffffff',
      elevated: '#ffffff'
    }
  },
  spacing: {
    xs: '4px',
    sm: '8px',
    md: '16px',
    lg: '24px',
    xl: '32px',
    xxl: '48px'
  },
  borderRadius: {
    sm: '4px',
    md: '8px',
    lg: '12px',
    xl: '16px'
  },
  shadows: {
    sm: '0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24)',
    md: '0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23)',
    lg: '0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23)',
    xl: '0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22)'
  },
  typography: {
    fontFamily: '"Inter", "Segoe UI", "Roboto", sans-serif',
    h1: {
      fontSize: '2.5rem',
      fontWeight: 700,
      lineHeight: 1.2
    },
    h2: {
      fontSize: '2rem',
      fontWeight: 600,
      lineHeight: 1.3
    },
    h3: {
      fontSize: '1.5rem',
      fontWeight: 600,
      lineHeight: 1.4
    },
    h4: {
      fontSize: '1.25rem',
      fontWeight: 600,
      lineHeight: 1.4
    },
    body1: {
      fontSize: '1rem',
      fontWeight: 400,
      lineHeight: 1.6
    },
    body2: {
      fontSize: '0.875rem',
      fontWeight: 400,
      lineHeight: 1.6
    },
    caption: {
      fontSize: '0.75rem',
      fontWeight: 400,
      lineHeight: 1.4
    }
  }
};

export const modernTheme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: designTokens.colors.primary[600],
      light: designTokens.colors.primary[100],
      dark: designTokens.colors.primary[700]
    },
    secondary: {
      main: designTokens.colors.secondary[600],
      light: designTokens.colors.secondary[100],
      dark: designTokens.colors.secondary[700]
    },
    background: {
      default: designTokens.colors.background.default,
      paper: designTokens.colors.background.paper
    },
    text: {
      primary: designTokens.colors.neutral[800],
      secondary: designTokens.colors.neutral[600]
    }
  },
  typography: {
    fontFamily: designTokens.typography.fontFamily,
    h1: designTokens.typography.h1,
    h2: designTokens.typography.h2,
    h3: designTokens.typography.h3,
    h4: designTokens.typography.h4,
    body1: designTokens.typography.body1,
    body2: designTokens.typography.body2,
    caption: designTokens.typography.caption
  },
  shape: {
    borderRadius: 8
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          fontWeight: 600,
          borderRadius: designTokens.borderRadius.md,
          padding: '10px 20px',
          boxShadow: 'none',
          '&:hover': {
            boxShadow: designTokens.shadows.sm
          }
        }
      }
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: designTokens.borderRadius.lg,
          boxShadow: designTokens.shadows.sm,
          border: `1px solid ${designTokens.colors.neutral[200]}`,
          '&:hover': {
            boxShadow: designTokens.shadows.md,
            transform: 'translateY(-2px)',
            transition: 'all 0.3s ease'
          }
        }
      }
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: designTokens.borderRadius.lg,
          boxShadow: designTokens.shadows.sm
        }
      }
    }
  }
});
