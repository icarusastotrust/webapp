
import React, { useState } from 'react';
import { 
  Typography, 
  Box, 
  Grid, 
  Button, 
  Paper, 
  Card,
  CardContent,
  Container,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  AppBar,
  Toolbar,
  IconButton,
  Badge,
  Avatar,
  Divider,
  Chip
} from '@mui/material';
import { 
  Link as RouterLink, 
  useNavigate 
} from 'react-router-dom';
import { 
  Timeline, 
  Engineering, 
  Analytics, 
  Warning,
  Menu as MenuIcon,
  Notifications as NotificationsIcon,
  Settings as SettingsIcon,
  AccountCircle as AccountCircleIcon,
  Build,
  Speed,
  Opacity,
  Thermostat,
  LocalGasStation,
  Category,
  TrendingUp,
  Assessment
} from '@mui/icons-material';
import NavigationBreadcrumb from './NavigationBreadcrumb';

const PredictiveMaintenance = () => {
  const [navigationOpen, setNavigationOpen] = useState(false);
  const navigate = useNavigate();

  const handleNavigationToggle = () => {
    setNavigationOpen(!navigationOpen);
  };

  const maintenanceModules = [
    {
      id: 'drilling',
      title: 'Drilling Equipment',
      description: 'Advanced AI-powered predictive maintenance for drilling rigs, top drives, mud pumps, and BOP systems',
      icon: <Engineering />,
      path: '/predictive-maintenance/drilling',
      status: 'active',
      metrics: { uptime: '94%', alerts: 3, efficiency: '87%' }
    },
    {
      id: 'pumps',
      title: 'Pumping Systems',
      description: 'Comprehensive pump condition monitoring including centrifugal, reciprocating, and specialty pumps',
      icon: <Opacity />,
      path: '/predictive-maintenance/pumps',
      status: 'active',
      metrics: { uptime: '96%', alerts: 1, efficiency: '91%' }
    },
    {
      id: 'pipelines',
      title: 'Pipeline Systems',
      description: 'Drone-powered ultrasonic thickness measurement, leak detection, and GPS mapping for pipeline infrastructure',
      icon: <Timeline />,
      path: '/predictive-maintenance/pipelines',
      status: 'active',
      metrics: { uptime: '98%', alerts: 0, efficiency: '93%' }
    },
    {
      id: 'compressors',
      title: 'Compressor Systems',
      description: 'Vibration analysis, thermodynamic monitoring, and performance optimization for gas compressors',
      icon: <Speed />,
      path: '/predictive-maintenance/compressors',
      status: 'development',
      metrics: { uptime: '--', alerts: 0, efficiency: '--' }
    },
    {
      id: 'turbines',
      title: 'Turbine Systems',
      description: 'Condition monitoring for gas turbines including blade health, combustion analysis, and efficiency tracking',
      icon: <LocalGasStation />,
      path: '/predictive-maintenance/turbines',
      status: 'development',
      metrics: { uptime: '--', alerts: 0, efficiency: '--' }
    },
    {
      id: 'heat-exchangers',
      title: 'Heat Exchangers',
      description: 'Fouling detection, thermal efficiency monitoring, and predictive cleaning schedules',
      icon: <Thermostat />,
      path: '/predictive-maintenance/heat-exchangers',
      status: 'development',
      metrics: { uptime: '--', alerts: 0, efficiency: '--' }
    },
    {
      id: 'separators',
      title: 'Separation Equipment',
      description: 'Performance monitoring for oil-gas-water separators and filtration systems',
      icon: <Category />,
      path: '/predictive-maintenance/separators',
      status: 'development',
      metrics: { uptime: '--', alerts: 0, efficiency: '--' }
    },
    {
      id: 'valves',
      title: 'Valves & Controls',
      description: 'Actuator health monitoring, seal condition assessment, and control system diagnostics',
      icon: <Build />,
      path: '/predictive-maintenance/valves',
      status: 'development',
      metrics: { uptime: '--', alerts: 0, efficiency: '--' }
    }
  ];

  const getStatusColor = (status) => {
    switch(status) {
      case 'active': return 'success';
      case 'warning': return 'warning';
      case 'development': return 'default';
      default: return 'primary';
    }
  };

  const lateralMenuItems = [
    { title: 'Overview', icon: <Assessment />, path: '/predictive-maintenance' },
    { title: 'Drilling Equipment', icon: <Engineering />, path: '/predictive-maintenance/drilling' },
    { title: 'Pumping Systems', icon: <Opacity />, path: '/predictive-maintenance/pumps' },
    { title: 'Pipeline Systems', icon: <Timeline />, path: '/predictive-maintenance/pipelines' },
    { title: 'Compressors', icon: <Speed />, path: '/predictive-maintenance/compressors' },
    { title: 'Turbines', icon: <LocalGasStation />, path: '/predictive-maintenance/turbines' },
    { title: 'Heat Exchangers', icon: <Thermostat />, path: '/predictive-maintenance/heat-exchangers' },
    { title: 'Separators', icon: <Category />, path: '/predictive-maintenance/separators' },
    { title: 'Valves & Controls', icon: <Build />, path: '/predictive-maintenance/valves' }
  ];

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {/* Top Banner */}
      <AppBar 
        position="fixed" 
        sx={{ 
          zIndex: (theme) => theme.zIndex.drawer + 1,
          background: 'linear-gradient(135deg, #1976d2 0%, #1565c0 100%)',
          boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open navigation"
            edge="start"
            onClick={handleNavigationToggle}
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          
          <Box display="flex" alignItems="center" flexGrow={1}>
            <Engineering sx={{ mr: 2, fontSize: 28 }} />
            <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
              ICARUS - Predictive Maintenance Portal
            </Typography>
          </Box>

          <Box display="flex" alignItems="center" gap={2}>
            <IconButton color="inherit">
              <Badge badgeContent={5} color="error">
                <NotificationsIcon />
              </Badge>
            </IconButton>
            <IconButton color="inherit">
              <SettingsIcon />
            </IconButton>
            <Avatar sx={{ bgcolor: 'rgba(255,255,255,0.2)' }}>
              <AccountCircleIcon />
            </Avatar>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Lateral Navigation Drawer */}
      <Drawer
        variant="temporary"
        anchor="left"
        open={navigationOpen}
        onClose={handleNavigationToggle}
        sx={{
          '& .MuiDrawer-paper': {
            width: 280,
            mt: '64px',
            height: 'calc(100vh - 64px)',
            background: 'linear-gradient(180deg, #f8f9fa 0%, #e9ecef 100%)',
            borderRight: '1px solid #dee2e6'
          }
        }}
      >
        <Box sx={{ p: 2 }}>
          <Typography variant="h6" sx={{ mb: 2, color: '#495057', fontWeight: 600 }}>
            Maintenance Modules
          </Typography>
          <List>
            {lateralMenuItems.map((item, index) => (
              <ListItem 
                button 
                key={index}
                onClick={() => {
                  navigate(item.path);
                  setNavigationOpen(false);
                }}
                sx={{
                  borderRadius: 2,
                  mb: 1,
                  '&:hover': {
                    backgroundColor: 'rgba(25, 118, 210, 0.1)',
                    transform: 'translateX(4px)',
                    transition: 'all 0.3s ease'
                  }
                }}
              >
                <ListItemIcon sx={{ color: '#1976d2' }}>
                  {item.icon}
                </ListItemIcon>
                <ListItemText 
                  primary={item.title}
                  sx={{ 
                    '& .MuiListItemText-primary': { 
                      fontWeight: 500,
                      color: '#495057'
                    } 
                  }} 
                />
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>

      {/* Main Content */}
      <Box 
        component="main" 
        sx={{ 
          flexGrow: 1, 
          pt: '64px',
          backgroundColor: '#f8f9fa',
          minHeight: '100vh'
        }}
      >
        <Container maxWidth="xl" sx={{ py: 4 }}>
          <NavigationBreadcrumb />
          
          <Box sx={{ mb: 4 }}>
            <Typography variant="h4" gutterBottom sx={{ fontWeight: 700, color: '#2c3e50' }}>
              Predictive Maintenance Solutions
            </Typography>
            <Typography variant="body1" paragraph sx={{ color: '#6c757d', fontSize: '1.1rem' }}>
              Advanced AI-powered predictive maintenance systems for industrial applications. 
              Monitor equipment health, predict failures, and optimize maintenance schedules across your entire operation.
            </Typography>
          </Box>

          {/* System Overview Cards */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} md={3}>
              <Card sx={{ 
                background: 'linear-gradient(135deg, #28a745 0%, #20c997 100%)',
                color: 'white',
                boxShadow: '0 8px 32px rgba(40, 167, 69, 0.3)'
              }}>
                <CardContent>
                  <Box display="flex" alignItems="center" justifyContent="space-between">
                    <Box>
                      <Typography variant="h4" sx={{ fontWeight: 700 }}>96%</Typography>
                      <Typography variant="body2">System Uptime</Typography>
                    </Box>
                    <TrendingUp sx={{ fontSize: 48, opacity: 0.8 }} />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={3}>
              <Card sx={{ 
                background: 'linear-gradient(135deg, #ffc107 0%, #fd7e14 100%)',
                color: 'white',
                boxShadow: '0 8px 32px rgba(255, 193, 7, 0.3)'
              }}>
                <CardContent>
                  <Box display="flex" alignItems="center" justifyContent="space-between">
                    <Box>
                      <Typography variant="h4" sx={{ fontWeight: 700 }}>4</Typography>
                      <Typography variant="body2">Active Alerts</Typography>
                    </Box>
                    <Warning sx={{ fontSize: 48, opacity: 0.8 }} />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={3}>
              <Card sx={{ 
                background: 'linear-gradient(135deg, #17a2b8 0%, #6f42c1 100%)',
                color: 'white',
                boxShadow: '0 8px 32px rgba(23, 162, 184, 0.3)'
              }}>
                <CardContent>
                  <Box display="flex" alignItems="center" justifyContent="space-between">
                    <Box>
                      <Typography variant="h4" sx={{ fontWeight: 700 }}>$2.3M</Typography>
                      <Typography variant="body2">Cost Savings</Typography>
                    </Box>
                    <Analytics sx={{ fontSize: 48, opacity: 0.8 }} />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={3}>
              <Card sx={{ 
                background: 'linear-gradient(135deg, #6610f2 0%, #e83e8c 100%)',
                color: 'white',
                boxShadow: '0 8px 32px rgba(102, 16, 242, 0.3)'
              }}>
                <CardContent>
                  <Box display="flex" alignItems="center" justifyContent="space-between">
                    <Box>
                      <Typography variant="h4" sx={{ fontWeight: 700 }}>8</Typography>
                      <Typography variant="body2">Equipment Types</Typography>
                    </Box>
                    <Engineering sx={{ fontSize: 48, opacity: 0.8 }} />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* Equipment Modules Grid */}
          <Grid container spacing={3}>
            {maintenanceModules.map((module) => (
              <Grid item xs={12} md={6} lg={4} key={module.id}>
                <Card 
                  sx={{ 
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    transition: 'all 0.3s ease',
                    border: '1px solid #e9ecef',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                      boxShadow: '0 12px 40px rgba(0,0,0,0.15)',
                      borderColor: '#1976d2'
                    }
                  }}
                >
                  <CardContent sx={{ flexGrow: 1, p: 3 }}>
                    <Box display="flex" alignItems="center" mb={2}>
                      <Box 
                        sx={{ 
                          p: 2, 
                          borderRadius: 2, 
                          backgroundColor: '#e3f2fd',
                          color: '#1976d2',
                          mr: 2
                        }}
                      >
                        {module.icon}
                      </Box>
                      <Box flexGrow={1}>
                        <Typography variant="h6" sx={{ fontWeight: 600, color: '#2c3e50' }}>
                          {module.title}
                        </Typography>
                        <Chip 
                          label={module.status === 'active' ? 'Active' : 'In Development'}
                          color={getStatusColor(module.status)}
                          size="small"
                          sx={{ mt: 0.5 }}
                        />
                      </Box>
                    </Box>
                    
                    <Typography variant="body2" color="text.secondary" paragraph>
                      {module.description}
                    </Typography>

                    {module.status === 'active' && (
                      <Box 
                        display="flex" 
                        justifyContent="space-between" 
                        sx={{ 
                          mt: 2, 
                          p: 2, 
                          backgroundColor: '#f8f9fa',
                          borderRadius: 2 
                        }}
                      >
                        <Box textAlign="center">
                          <Typography variant="h6" color="success.main" sx={{ fontWeight: 600 }}>
                            {module.metrics.uptime}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            Uptime
                          </Typography>
                        </Box>
                        <Box textAlign="center">
                          <Typography variant="h6" color="warning.main" sx={{ fontWeight: 600 }}>
                            {module.metrics.alerts}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            Alerts
                          </Typography>
                        </Box>
                        <Box textAlign="center">
                          <Typography variant="h6" color="primary.main" sx={{ fontWeight: 600 }}>
                            {module.metrics.efficiency}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            Efficiency
                          </Typography>
                        </Box>
                      </Box>
                    )}
                  </CardContent>
                  
                  <Box sx={{ p: 3, pt: 0 }}>
                    <Button 
                      component={RouterLink} 
                      to={module.path} 
                      variant="contained" 
                      fullWidth
                      disabled={module.status === 'development'}
                      sx={{
                        py: 1.5,
                        borderRadius: 2,
                        fontWeight: 600,
                        textTransform: 'none'
                      }}
                    >
                      {module.status === 'active' ? 'Launch Module' : 'Coming Soon'}
                    </Button>
                  </Box>
                </Card>
              </Grid>
            ))}
          </Grid>

          {/* Key Features Section */}
          <Paper sx={{ mt: 4, p: 4, borderRadius: 3, border: '1px solid #e9ecef' }}>
            <Typography variant="h5" gutterBottom sx={{ fontWeight: 600, color: '#2c3e50' }}>
              Key Features & Capabilities
            </Typography>
            <Grid container spacing={3} sx={{ mt: 2 }}>
              <Grid item xs={12} md={4}>
                <Box display="flex" alignItems="center" mb={2}>
                  <Timeline color="primary" sx={{ mr: 2, fontSize: 32 }} />
                  <Box>
                    <Typography variant="h6" sx={{ fontWeight: 600 }}>Real-time Monitoring</Typography>
                    <Typography variant="body2" color="text.secondary">
                      Continuous sensor data collection and analysis
                    </Typography>
                  </Box>
                </Box>
              </Grid>
              <Grid item xs={12} md={4}>
                <Box display="flex" alignItems="center" mb={2}>
                  <Analytics color="primary" sx={{ mr: 2, fontSize: 32 }} />
                  <Box>
                    <Typography variant="h6" sx={{ fontWeight: 600 }}>AI-powered Predictions</Typography>
                    <Typography variant="body2" color="text.secondary">
                      Machine learning algorithms for failure prediction
                    </Typography>
                  </Box>
                </Box>
              </Grid>
              <Grid item xs={12} md={4}>
                <Box display="flex" alignItems="center" mb={2}>
                  <Warning color="primary" sx={{ mr: 2, fontSize: 32 }} />
                  <Box>
                    <Typography variant="h6" sx={{ fontWeight: 600 }}>Risk Assessment</Typography>
                    <Typography variant="body2" color="text.secondary">
                      Comprehensive risk analysis and mitigation strategies
                    </Typography>
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Paper>
        </Container>
      </Box>
    </Box>
  );
};

export default PredictiveMaintenance;
