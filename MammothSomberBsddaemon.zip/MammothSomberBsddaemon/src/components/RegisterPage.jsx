import React, { useState } from 'react';
import { Container, TextField, Button, Typography, Paper } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { styled } from '@mui/system';

const StyledPaper = styled('div')({
  padding: 20,
  maxWidth: 400,
  margin: 'auto',
  marginTop: 50,
});

const StyledButton = styled('div')({
  marginTop: 10,
});

const RegisterPage = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ username: '', email: '', password: '', confirmPassword: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = () => {
    // Implement your register logic here
    navigate('/');
  };

  return (
    <Container>
      <StyledPaper>
        <Paper sx={{ padding: 2.5, maxWidth: 400, margin: 'auto', marginTop: 6.25 }}>
          <Typography variant="h5">Create Account</Typography>
          <TextField
            fullWidth
            label="Username"
            margin="normal"
            name="username"
            value={formData.username}
            onChange={handleChange}
          />
          <TextField
            fullWidth
            label="Email"
            margin="normal"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />
          <TextField
            fullWidth
            label="Password"
            type="password"
            margin="normal"
            name="password"
            value={formData.password}
            onChange={handleChange}
          />
          <TextField
            fullWidth
            label="Confirm Password"
            type="password"
            margin="normal"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
          />
          <StyledButton>
            <Button variant="contained" color="primary" fullWidth onClick={handleSubmit} sx={{ marginTop: 1.25 }}>
              Register
            </Button>
          </StyledButton>
        </Paper>
      </StyledPaper>
    </Container>
  );
};

export default RegisterPage;
