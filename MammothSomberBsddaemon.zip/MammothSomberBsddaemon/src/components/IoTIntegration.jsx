import React from 'react';
import { Typography, Box } from '@mui/material';

const IoTIntegration = () => {
  return (
    <Box p={3}>
      <Typography variant="h6" gutterBottom>
        IoT Integration
      </Typography>
      <Typography>
        Integrate with IoT devices to monitor real-time machine status.
      </Typography>
      {/* Add your IoT integration implementation here */}
    </Box>
  );
};

export default IoTIntegration;
