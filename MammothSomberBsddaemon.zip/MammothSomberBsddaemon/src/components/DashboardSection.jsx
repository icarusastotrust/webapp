import React from 'react';
import { Typography } from '@mui/material';

const DashboardSection = ({ name }) => {
  return (
    <Typography variant="h6">
      Welcome to the {name} section
      {/* Add specific section content here */}
    </Typography>
  );
};

export default DashboardSection;
