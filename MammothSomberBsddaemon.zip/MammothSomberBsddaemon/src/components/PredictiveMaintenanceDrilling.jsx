
import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Grid,
  Paper,
  Card,
  CardContent,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  LinearProgress,
  Box,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Slider,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormLabel,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  AppBar,
  Toolbar,
  IconButton,
  Badge,
  Avatar,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText
} from '@mui/material';
import {
  Engineering,
  Build,
  Schedule,
  TrendingUp,
  Warning,
  CheckCircle,
  Error,
  Speed,
  Thermostat,
  Power,
  ExpandMore,
  Assessment,
  Settings,
  Timeline,
  Menu as MenuIcon,
  Notifications as NotificationsIcon,
  AccountCircle as AccountCircleIcon,
  Opacity,
  LocalGasStation,
  Category
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import NavigationBreadcrumb from './NavigationBreadcrumb';

const PredictiveMaintenanceDrilling = () => {
  const [activeTab, setActiveTab] = useState(0);
  const [activeStep, setActiveStep] = useState(0);
  const [navigationOpen, setNavigationOpen] = useState(false);
  const navigate = useNavigate();
  const [equipmentData, setEquipmentData] = useState({
    equipmentType: '',
    operatingHours: '',
    lastMaintenance: '',
    operatingConditions: '',
    vibrationLevel: '',
    temperature: '',
    pressure: '',
    fluidType: '',
    depthRange: '',
    drillBitType: '',
    rotarySpeed: '',
    weightOnBit: '',
    mudFlow: '',
    torque: '',
    flowRate: '',
    pipelineLength: '',
    pipeDiameter: '',
    installationYear: ''
  });
  const [prediction, setPrediction] = useState(null);
  const [loading, setLoading] = useState(false);

  const equipmentTypes = [
    { value: 'pipeline', label: 'Pipeline System', category: 'Pipeline Infrastructure' },
    { value: 'pipeline_section', label: 'Pipeline Section', category: 'Pipeline Infrastructure' },
    { value: 'pipeline_valve', label: 'Pipeline Valve', category: 'Pipeline Infrastructure' },
    { value: 'pipeline_pump', label: 'Pipeline Pump Station', category: 'Pipeline Infrastructure' },
    { value: 'pipeline_compressor', label: 'Pipeline Compressor', category: 'Pipeline Infrastructure' },
    { value: 'rotary_drill', label: 'Rotary Drilling Rig', category: 'Drilling Rigs' },
    { value: 'top_drive', label: 'Top Drive System', category: 'Drilling Systems' },
    { value: 'mud_pump', label: 'Mud Pump', category: 'Circulation System' },
    { value: 'draw_works', label: 'Draw Works', category: 'Hoisting System' },
    { value: 'rotary_table', label: 'Rotary Table', category: 'Drilling Systems' },
    { value: 'kelly_drive', label: 'Kelly Drive', category: 'Drilling Systems' },
    { value: 'blowout_preventer', label: 'Blowout Preventer (BOP)', category: 'Safety Systems' },
    { value: 'choke_manifold', label: 'Choke Manifold', category: 'Control Systems' },
    { value: 'shale_shaker', label: 'Shale Shaker', category: 'Solids Control' },
    { value: 'degasser', label: 'Degasser', category: 'Solids Control' }
  ];

  const operatingConditions = [
    'Offshore Deep Water',
    'Onshore Conventional',
    'High Pressure High Temperature (HPHT)',
    'Sour Gas Environment',
    'Extended Reach Drilling',
    'Directional Drilling',
    'Horizontal Drilling',
    'Geothermal Drilling',
    'Pipeline Transportation',
    'Pipeline Distribution',
    'Pipeline Gathering',
    'Subsea Pipeline',
    'Cross-country Pipeline',
    'Urban Pipeline Network'
  ];

  const fluidTypes = [
    'Water-based Mud (WBM)',
    'Oil-based Mud (OBM)',
    'Synthetic-based Mud (SBM)',
    'Air/Gas Drilling',
    'Foam Drilling',
    'Underbalanced Drilling Fluid',
    'Crude Oil',
    'Natural Gas',
    'Refined Products',
    'Natural Gas Liquids (NGL)',
    'Condensate',
    'Water/Brine'
  ];

  const drillBitTypes = [
    'PDC (Polycrystalline Diamond Compact)',
    'Roller Cone (Tricone)',
    'Natural Diamond',
    'Hybrid Bits',
    'Impregnated Diamond',
    'Steel Body PDC'
  ];

  const steps = [
    'Equipment Selection',
    'Operating Parameters',
    'Environmental Conditions',
    'Maintenance History',
    'Analysis & Prediction'
  ];

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleNavigationToggle = () => {
    setNavigationOpen(!navigationOpen);
  };

  const lateralMenuItems = [
    { title: 'Overview', icon: <Assessment />, path: '/predictive-maintenance' },
    { title: 'Drilling Equipment', icon: <Engineering />, path: '/predictive-maintenance/drilling' },
    { title: 'Pumping Systems', icon: <Opacity />, path: '/predictive-maintenance/pumps' },
    { title: 'Pipeline Systems', icon: <Timeline />, path: '/predictive-maintenance/pipelines' },
    { title: 'Compressors', icon: <Speed />, path: '/predictive-maintenance/compressors' },
    { title: 'Turbines', icon: <LocalGasStation />, path: '/predictive-maintenance/turbines' },
    { title: 'Heat Exchangers', icon: <Thermostat />, path: '/predictive-maintenance/heat-exchangers' },
    { title: 'Separators', icon: <Category />, path: '/predictive-maintenance/separators' },
    { title: 'Valves & Controls', icon: <Build />, path: '/predictive-maintenance/valves' }
  ];

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleInputChange = (field, value) => {
    setEquipmentData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const calculatePrediction = () => {
    setLoading(true);
    
    // Simulate AI prediction calculation
    setTimeout(() => {
      const hoursRemaining = Math.max(100, Math.random() * 2000);
      const riskLevel = hoursRemaining < 500 ? 'High' : hoursRemaining < 1000 ? 'Medium' : 'Low';
      const confidence = Math.floor(Math.random() * 20) + 80;
      
      const maintenanceRecommendations = [];
      
      if (equipmentData.equipmentType === 'mud_pump') {
        maintenanceRecommendations.push(
          'Replace high-pressure seals',
          'Inspect liner and piston assembly',
          'Check valve seat wear',
          'Lubricate bearing systems'
        );
      } else if (equipmentData.equipmentType === 'top_drive') {
        maintenanceRecommendations.push(
          'Inspect motor bearings',
          'Check hydraulic connections',
          'Replace rotary seals',
          'Calibrate torque sensors'
        );
      } else if (equipmentData.equipmentType === 'pipeline' || equipmentData.equipmentType === 'pipeline_section') {
        maintenanceRecommendations.push(
          'Ultrasonic thickness measurement',
          'Corrosion inspection and treatment',
          'Cathodic protection system check',
          'Pipeline integrity assessment',
          'Leak detection system calibration',
          'Coating condition evaluation'
        );
      } else if (equipmentData.equipmentType === 'pipeline_valve') {
        maintenanceRecommendations.push(
          'Valve seat and seal inspection',
          'Actuator mechanism lubrication',
          'Control system calibration',
          'Emergency shutdown test'
        );
      } else if (equipmentData.equipmentType === 'pipeline_pump') {
        maintenanceRecommendations.push(
          'Impeller wear inspection',
          'Bearing replacement',
          'Seal system maintenance',
          'Vibration analysis',
          'Flow rate optimization'
        );
      } else if (equipmentData.equipmentType === 'pipeline_compressor') {
        maintenanceRecommendations.push(
          'Compressor blade inspection',
          'Gas seal system maintenance',
          'Cooling system service',
          'Performance curve analysis'
        );
      } else {
        maintenanceRecommendations.push(
          'General lubrication service',
          'Inspect wear components',
          'Check safety systems',
          'Calibrate control systems'
        );
      }

      setPrediction({
        hoursRemaining,
        daysRemaining: Math.floor(hoursRemaining / 24),
        riskLevel,
        confidence,
        estimatedCost: `$${(Math.random() * 50000 + 10000).toFixed(0)}`,
        downtime: `${Math.floor(Math.random() * 48 + 8)} hours`,
        recommendations: maintenanceRecommendations,
        criticalComponents: equipmentData.equipmentType.includes('pipeline') ? [
          { name: 'Pipe Wall Thickness', condition: 'Good', lifeRemaining: '82%' },
          { name: 'Coating System', condition: 'Fair', lifeRemaining: '65%' },
          { name: 'Cathodic Protection', condition: 'Excellent', lifeRemaining: '95%' },
          { name: 'Valve Assembly', condition: 'Good', lifeRemaining: '78%' },
          { name: 'Instrumentation', condition: 'Good', lifeRemaining: '85%' }
        ] : [
          { name: 'Bearing Assembly', condition: 'Good', lifeRemaining: '75%' },
          { name: 'Sealing System', condition: 'Fair', lifeRemaining: '45%' },
          { name: 'Hydraulic System', condition: 'Excellent', lifeRemaining: '90%' },
          { name: 'Control Electronics', condition: 'Good', lifeRemaining: '80%' }
        ]
      });
      setLoading(false);
    }, 2000);
  };

  const getRiskColor = (risk) => {
    switch(risk) {
      case 'High': return 'error';
      case 'Medium': return 'warning';
      case 'Low': return 'success';
      default: return 'default';
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {/* Top Banner */}
      <AppBar 
        position="fixed" 
        sx={{ 
          zIndex: (theme) => theme.zIndex.drawer + 1,
          background: 'linear-gradient(135deg, #1976d2 0%, #1565c0 100%)',
          boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open navigation"
            edge="start"
            onClick={handleNavigationToggle}
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          
          <Box display="flex" alignItems="center" flexGrow={1}>
            <Engineering sx={{ mr: 2, fontSize: 28 }} />
            <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
              ICARUS - Drilling Equipment Maintenance
            </Typography>
          </Box>

          <Box display="flex" alignItems="center" gap={2}>
            <IconButton color="inherit">
              <Badge badgeContent={3} color="error">
                <NotificationsIcon />
              </Badge>
            </IconButton>
            <IconButton color="inherit">
              <Settings />
            </IconButton>
            <Avatar sx={{ bgcolor: 'rgba(255,255,255,0.2)' }}>
              <AccountCircleIcon />
            </Avatar>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Lateral Navigation Drawer */}
      <Drawer
        variant="temporary"
        anchor="left"
        open={navigationOpen}
        onClose={handleNavigationToggle}
        sx={{
          '& .MuiDrawer-paper': {
            width: 280,
            mt: '64px',
            height: 'calc(100vh - 64px)',
            background: 'linear-gradient(180deg, #f8f9fa 0%, #e9ecef 100%)',
            borderRight: '1px solid #dee2e6'
          }
        }}
      >
        <Box sx={{ p: 2 }}>
          <Typography variant="h6" sx={{ mb: 2, color: '#495057', fontWeight: 600 }}>
            Maintenance Modules
          </Typography>
          <List>
            {lateralMenuItems.map((item, index) => (
              <ListItem 
                button 
                key={index}
                onClick={() => {
                  navigate(item.path);
                  setNavigationOpen(false);
                }}
                sx={{
                  borderRadius: 2,
                  mb: 1,
                  '&:hover': {
                    backgroundColor: 'rgba(25, 118, 210, 0.1)',
                    transform: 'translateX(4px)',
                    transition: 'all 0.3s ease'
                  }
                }}
              >
                <ListItemIcon sx={{ color: '#1976d2' }}>
                  {item.icon}
                </ListItemIcon>
                <ListItemText 
                  primary={item.title}
                  sx={{ 
                    '& .MuiListItemText-primary': { 
                      fontWeight: 500,
                      color: '#495057'
                    } 
                  }} 
                />
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>

      {/* Main Content */}
      <Box 
        component="main" 
        sx={{ 
          flexGrow: 1, 
          pt: '64px',
          backgroundColor: '#f8f9fa',
          minHeight: '100vh'
        }}
      >
        <Container maxWidth="xl" sx={{ py: 4 }}>
          <NavigationBreadcrumb />
          
          <Typography variant="h4" gutterBottom sx={{ fontWeight: 700, color: '#2c3e50' }}>
            Predictive Maintenance - Drilling Equipment
          </Typography>
          
          <Typography variant="body1" paragraph sx={{ color: '#6c757d', fontSize: '1.1rem' }}>
            AI-powered predictive maintenance analysis for oil and gas drilling equipment
          </Typography>

      <Tabs value={activeTab} onChange={handleTabChange} sx={{ mb: 3 }}>
        <Tab label="Maintenance Prediction" />
        <Tab label="Equipment Database" />
        <Tab label="Historical Analysis" />
        <Tab label="Maintenance Reports" />
      </Tabs>

      {/* Maintenance Prediction Tab */}
      {activeTab === 0 && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Equipment Maintenance Prediction Wizard
          </Typography>
          
          <Stepper activeStep={activeStep} orientation="vertical">
            {/* Step 1: Equipment Selection */}
            <Step>
              <StepLabel>Equipment Selection</StepLabel>
              <StepContent>
                <Grid container spacing={3}>
                  <Grid item xs={12} md={6}>
                    <FormControl fullWidth>
                      <InputLabel>Equipment Type</InputLabel>
                      <Select
                        value={equipmentData.equipmentType}
                        onChange={(e) => handleInputChange('equipmentType', e.target.value)}
                        label="Equipment Type"
                      >
                        {equipmentTypes.map((eq) => (
                          <MenuItem key={eq.value} value={eq.value}>
                            {eq.label} ({eq.category})
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <TextField
                      fullWidth
                      label="Total Operating Hours"
                      type="number"
                      value={equipmentData.operatingHours}
                      onChange={(e) => handleInputChange('operatingHours', e.target.value)}
                      helperText="Total operational hours since installation"
                    />
                  </Grid>
                </Grid>
                <Box sx={{ mt: 2 }}>
                  <Button variant="contained" onClick={handleNext} disabled={!equipmentData.equipmentType}>
                    Continue
                  </Button>
                </Box>
              </StepContent>
            </Step>

            {/* Step 2: Operating Parameters */}
            <Step>
              <StepLabel>Operating Parameters</StepLabel>
              <StepContent>
                <Grid container spacing={3}>
                  <Grid item xs={12} md={4}>
                    <TextField
                      fullWidth
                      label={equipmentData.equipmentType?.includes('pipeline') ? "Flow Rate (bpd)" : "Rotary Speed (RPM)"}
                      type="number"
                      value={equipmentData.equipmentType?.includes('pipeline') ? equipmentData.flowRate : equipmentData.rotarySpeed}
                      onChange={(e) => handleInputChange(equipmentData.equipmentType?.includes('pipeline') ? 'flowRate' : 'rotarySpeed', e.target.value)}
                    />
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <TextField
                      fullWidth
                      label={equipmentData.equipmentType?.includes('pipeline') ? "Pipeline Length (km)" : "Weight on Bit (klbs)"}
                      type="number"
                      value={equipmentData.equipmentType?.includes('pipeline') ? equipmentData.pipelineLength : equipmentData.weightOnBit}
                      onChange={(e) => handleInputChange(equipmentData.equipmentType?.includes('pipeline') ? 'pipelineLength' : 'weightOnBit', e.target.value)}
                    />
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <TextField
                      fullWidth
                      label="Operating Pressure (psi)"
                      type="number"
                      value={equipmentData.pressure}
                      onChange={(e) => handleInputChange('pressure', e.target.value)}
                    />
                  </Grid>
                  <Grid item xs={12} md={6}>
                    {equipmentData.equipmentType?.includes('pipeline') ? (
                      <TextField
                        fullWidth
                        label="Pipe Diameter (inches)"
                        type="number"
                        value={equipmentData.pipeDiameter}
                        onChange={(e) => handleInputChange('pipeDiameter', e.target.value)}
                      />
                    ) : (
                      <FormControl fullWidth>
                        <InputLabel>Drill Bit Type</InputLabel>
                        <Select
                          value={equipmentData.drillBitType}
                          onChange={(e) => handleInputChange('drillBitType', e.target.value)}
                          label="Drill Bit Type"
                        >
                          {drillBitTypes.map((bit) => (
                            <MenuItem key={bit} value={bit}>
                              {bit}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    )}
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <TextField
                      fullWidth
                      label={equipmentData.equipmentType?.includes('pipeline') ? "Installation Year" : "Drilling Depth Range (ft)"}
                      value={equipmentData.equipmentType?.includes('pipeline') ? equipmentData.installationYear : equipmentData.depthRange}
                      onChange={(e) => handleInputChange(equipmentData.equipmentType?.includes('pipeline') ? 'installationYear' : 'depthRange', e.target.value)}
                      placeholder={equipmentData.equipmentType?.includes('pipeline') ? "e.g., 2010" : "e.g., 5000-15000"}
                    />
                  </Grid>
                </Grid>
                <Box sx={{ mt: 2 }}>
                  <Button variant="contained" onClick={handleNext} sx={{ mr: 1 }}>
                    Continue
                  </Button>
                  <Button onClick={handleBack}>
                    Back
                  </Button>
                </Box>
              </StepContent>
            </Step>

            {/* Step 3: Environmental Conditions */}
            <Step>
              <StepLabel>Environmental Conditions</StepLabel>
              <StepContent>
                <Grid container spacing={3}>
                  <Grid item xs={12} md={6}>
                    <FormControl fullWidth>
                      <InputLabel>Operating Environment</InputLabel>
                      <Select
                        value={equipmentData.operatingConditions}
                        onChange={(e) => handleInputChange('operatingConditions', e.target.value)}
                        label="Operating Environment"
                      >
                        {operatingConditions.map((condition) => (
                          <MenuItem key={condition} value={condition}>
                            {condition}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <FormControl fullWidth>
                      <InputLabel>Drilling Fluid Type</InputLabel>
                      <Select
                        value={equipmentData.fluidType}
                        onChange={(e) => handleInputChange('fluidType', e.target.value)}
                        label="Drilling Fluid Type"
                      >
                        {fluidTypes.map((fluid) => (
                          <MenuItem key={fluid} value={fluid}>
                            {fluid}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <TextField
                      fullWidth
                      label="Operating Temperature (°F)"
                      type="number"
                      value={equipmentData.temperature}
                      onChange={(e) => handleInputChange('temperature', e.target.value)}
                    />
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <TextField
                      fullWidth
                      label="Vibration Level (mm/s)"
                      type="number"
                      value={equipmentData.vibrationLevel}
                      onChange={(e) => handleInputChange('vibrationLevel', e.target.value)}
                    />
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <TextField
                      fullWidth
                      label="Mud Flow Rate (gpm)"
                      type="number"
                      value={equipmentData.mudFlow}
                      onChange={(e) => handleInputChange('mudFlow', e.target.value)}
                    />
                  </Grid>
                </Grid>
                <Box sx={{ mt: 2 }}>
                  <Button variant="contained" onClick={handleNext} sx={{ mr: 1 }}>
                    Continue
                  </Button>
                  <Button onClick={handleBack}>
                    Back
                  </Button>
                </Box>
              </StepContent>
            </Step>

            {/* Step 4: Maintenance History */}
            <Step>
              <StepLabel>Maintenance History</StepLabel>
              <StepContent>
                <Grid container spacing={3}>
                  <Grid item xs={12} md={6}>
                    <TextField
                      fullWidth
                      label="Last Maintenance Date"
                      type="date"
                      value={equipmentData.lastMaintenance}
                      onChange={(e) => handleInputChange('lastMaintenance', e.target.value)}
                      InputLabelProps={{ shrink: true }}
                    />
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <TextField
                      fullWidth
                      label="Torque Reading (ft-lbs)"
                      type="number"
                      value={equipmentData.torque}
                      onChange={(e) => handleInputChange('torque', e.target.value)}
                    />
                  </Grid>
                </Grid>
                <Box sx={{ mt: 2 }}>
                  <Button variant="contained" onClick={handleNext} sx={{ mr: 1 }}>
                    Analyze
                  </Button>
                  <Button onClick={handleBack}>
                    Back
                  </Button>
                </Box>
              </StepContent>
            </Step>

            {/* Step 5: Analysis & Prediction */}
            <Step>
              <StepLabel>Analysis & Prediction</StepLabel>
              <StepContent>
                <Box sx={{ mb: 2 }}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={calculatePrediction}
                    disabled={loading}
                    startIcon={<Assessment />}
                  >
                    {loading ? 'Analyzing...' : 'Generate Prediction'}
                  </Button>
                </Box>

                {loading && (
                  <Box sx={{ mb: 2 }}>
                    <LinearProgress />
                    <Typography variant="body2" sx={{ mt: 1 }}>
                      Analyzing equipment data and generating predictions...
                    </Typography>
                  </Box>
                )}

                {prediction && (
                  <Grid container spacing={3}>
                    {/* Prediction Summary */}
                    <Grid item xs={12}>
                      <Alert severity={prediction.riskLevel === 'High' ? 'error' : prediction.riskLevel === 'Medium' ? 'warning' : 'success'}>
                        <Typography variant="h6">
                          Maintenance Required in {prediction.daysRemaining} days ({prediction.hoursRemaining} operating hours)
                        </Typography>
                        <Typography>
                          Risk Level: {prediction.riskLevel} | Confidence: {prediction.confidence}% | Estimated Cost: {prediction.estimatedCost}
                        </Typography>
                      </Alert>
                    </Grid>

                    {/* Risk Assessment Cards */}
                    <Grid item xs={12} md={3}>
                      <Card>
                        <CardContent>
                          <Box display="flex" alignItems="center">
                            <Schedule color="primary" sx={{ mr: 1 }} />
                            <Typography variant="h6">Time Remaining</Typography>
                          </Box>
                          <Typography variant="h4" color="primary">
                            {prediction.daysRemaining}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Days until maintenance
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>

                    <Grid item xs={12} md={3}>
                      <Card>
                        <CardContent>
                          <Box display="flex" alignItems="center">
                            <Warning color={getRiskColor(prediction.riskLevel)} sx={{ mr: 1 }} />
                            <Typography variant="h6">Risk Level</Typography>
                          </Box>
                          <Chip 
                            label={prediction.riskLevel} 
                            color={getRiskColor(prediction.riskLevel)}
                            size="large"
                          />
                          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                            Based on current conditions
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>

                    <Grid item xs={12} md={3}>
                      <Card>
                        <CardContent>
                          <Box display="flex" alignItems="center">
                            <TrendingUp color="info" sx={{ mr: 1 }} />
                            <Typography variant="h6">Confidence</Typography>
                          </Box>
                          <Typography variant="h4" color="info">
                            {prediction.confidence}%
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Prediction accuracy
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>

                    <Grid item xs={12} md={3}>
                      <Card>
                        <CardContent>
                          <Box display="flex" alignItems="center">
                            <Build color="secondary" sx={{ mr: 1 }} />
                            <Typography variant="h6">Downtime</Typography>
                          </Box>
                          <Typography variant="h4" color="secondary">
                            {prediction.downtime}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Expected maintenance time
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>

                    {/* Component Health */}
                    <Grid item xs={12} md={6}>
                      <Paper sx={{ p: 2 }}>
                        <Typography variant="h6" gutterBottom>
                          Critical Component Health
                        </Typography>
                        {prediction.criticalComponents.map((component, index) => (
                          <Box key={index} sx={{ mb: 2 }}>
                            <Box display="flex" justifyContent="space-between" alignItems="center">
                              <Typography variant="body1">{component.name}</Typography>
                              <Chip 
                                label={component.condition} 
                                color={component.condition === 'Excellent' ? 'success' : component.condition === 'Good' ? 'info' : 'warning'}
                                size="small"
                              />
                            </Box>
                            <LinearProgress 
                              variant="determinate" 
                              value={parseInt(component.lifeRemaining)} 
                              sx={{ mt: 1 }}
                              color={parseInt(component.lifeRemaining) > 70 ? 'success' : parseInt(component.lifeRemaining) > 40 ? 'warning' : 'error'}
                            />
                            <Typography variant="caption" color="text.secondary">
                              {component.lifeRemaining} life remaining
                            </Typography>
                          </Box>
                        ))}
                      </Paper>
                    </Grid>

                    {/* Maintenance Recommendations */}
                    <Grid item xs={12} md={6}>
                      <Paper sx={{ p: 2 }}>
                        <Typography variant="h6" gutterBottom>
                          Recommended Actions
                        </Typography>
                        {prediction.recommendations.map((rec, index) => (
                          <Box key={index} display="flex" alignItems="center" sx={{ mb: 1 }}>
                            <CheckCircle color="success" sx={{ mr: 1, fontSize: 20 }} />
                            <Typography variant="body2">{rec}</Typography>
                          </Box>
                        ))}
                        <Box sx={{ mt: 2 }}>
                          <Button variant="outlined" color="primary" size="small">
                            Schedule Maintenance
                          </Button>
                        </Box>
                      </Paper>
                    </Grid>
                  </Grid>
                )}

                <Box sx={{ mt: 2 }}>
                  <Button onClick={handleBack}>
                    Back
                  </Button>
                  <Button
                    variant="contained"
                    color="secondary"
                    sx={{ ml: 1 }}
                    onClick={() => setActiveStep(0)}
                  >
                    Start New Analysis
                  </Button>
                </Box>
              </StepContent>
            </Step>
          </Stepper>
        </Paper>
      )}

      {/* Equipment Database Tab */}
      {activeTab === 1 && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Drilling Equipment Database
          </Typography>
          
          <Grid container spacing={3}>
            {equipmentTypes.map((equipment, index) => (
              <Grid item xs={12} md={4} key={index}>
                <Card variant="outlined">
                  <CardContent>
                    <Box display="flex" alignItems="center" mb={2}>
                      <Engineering color="primary" sx={{ mr: 2 }} />
                      <Typography variant="h6">{equipment.label}</Typography>
                    </Box>
                    <Typography variant="body2" color="text.secondary" paragraph>
                      Category: {equipment.category}
                    </Typography>
                    <Typography variant="body2" paragraph>
                      Critical maintenance parameters and monitoring requirements for {equipment.label.toLowerCase()}.
                    </Typography>
                    <Button 
                      variant="outlined" 
                      size="small"
                      onClick={() => {
                        handleInputChange('equipmentType', equipment.value);
                        setActiveTab(0);
                        setActiveStep(0);
                      }}
                    >
                      Analyze This Equipment
                    </Button>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Paper>
      )}

      {/* Historical Analysis Tab */}
      {activeTab === 2 && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Historical Maintenance Analysis
          </Typography>
          
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2, backgroundColor: '#f5f5f5' }}>
                <Typography variant="h6" gutterBottom>
                  Failure Patterns
                </Typography>
                <Typography variant="body2">
                  • 40% of failures occur in high-temperature environments<br/>
                  • Mud pump failures peak at 8,000-12,000 operating hours<br/>
                  • BOP systems require attention every 6 months in HPHT conditions<br/>
                  • Top drives show increased wear in directional drilling operations
                </Typography>
              </Paper>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2, backgroundColor: '#f5f5f5' }}>
                <Typography variant="h6" gutterBottom>
                  Cost Analysis
                </Typography>
                <Typography variant="body2">
                  • Average preventive maintenance cost: $15,000-$45,000<br/>
                  • Emergency repair costs: 3-5x higher than planned maintenance<br/>
                  • Downtime costs: $50,000-$200,000 per day<br/>
                  • ROI on predictive maintenance: 300-500%
                </Typography>
              </Paper>
            </Grid>
          </Grid>
        </Paper>
      )}

      {/* Maintenance Reports Tab */}
      {activeTab === 3 && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Maintenance Reports & Analytics
          </Typography>
          
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Alert severity="info">
                <Typography variant="h6">Power BI Integration</Typography>
                <Typography>
                  Advanced analytics and reporting dashboards will be integrated here using Power BI for comprehensive maintenance analytics, 
                  trend analysis, and performance monitoring across your drilling equipment fleet.
                </Typography>
              </Alert>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>Equipment Uptime</Typography>
                  <Typography variant="h3" color="success.main">94.5%</Typography>
                  <Typography variant="body2">Last 30 days</Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>Avg. Repair Time</Typography>
                  <Typography variant="h3" color="warning.main">18 hrs</Typography>
                  <Typography variant="body2">Per incident</Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>Cost Savings</Typography>
                  <Typography variant="h3" color="primary.main">$2.3M</Typography>
                  <Typography variant="body2">This quarter</Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Paper>
      )}
        </Container>
      </Box>
    </Box>
  );
};

export default PredictiveMaintenanceDrilling;
