import React, { useState } from 'react';
import { Container, TextField, Button, Typography, Paper, Grid } from '@mui/material';
import QualityChart from './QualityChart';

const PerformanceQuality = () => {
  const [formData, setFormData] = useState({
    moistureContent: '',
    freeFattyAcids: '',
    peroxideValue: '',
    aflatoxin: '',
    eColi: '',
    salmonella: '',
    listeria: '',
    staphylococcus: '',
  });
  const [showChart, setShowChart] = useState(false);

  const internationalStandards = [5, 1.5, 5, 20, 0, 0, 0, 10]; // Example standards

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: parseFloat(value) });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowChart(true);
  };

  return (
    <Container component="main" maxWidth="md">
      <Paper style={{ padding: '20px' }}>
        <Typography variant="h5" component="h1" gutterBottom>
          Performance Quality
        </Typography>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                name="moistureContent"
                label="Moisture Content (%)"
                fullWidth
                variant="outlined"
                value={formData.moistureContent}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="freeFattyAcids"
                label="Free Fatty Acids (%)"
                fullWidth
                variant="outlined"
                value={formData.freeFattyAcids}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="peroxideValue"
                label="Peroxide Value (meq/kg)"
                fullWidth
                variant="outlined"
                value={formData.peroxideValue}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="aflatoxin"
                label="Aflatoxin Level (ppb)"
                fullWidth
                variant="outlined"
                value={formData.aflatoxin}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="eColi"
                label="E. Coli (CFU/g)"
                fullWidth
                variant="outlined"
                value={formData.eColi}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="salmonella"
                label="Salmonella (per 375g)"
                fullWidth
                variant="outlined"
                value={formData.salmonella}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="listeria"
                label="Listeria Monocytogenes (per 125g)"
                fullWidth
                variant="outlined"
                value={formData.listeria}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="staphylococcus"
                label="Staphylococcus Aureus (CFU/g)"
                fullWidth
                variant="outlined"
                value={formData.staphylococcus}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <Button type="submit" variant="contained" color="primary">
                Submit
              </Button>
            </Grid>
          </Grid>
        </form>
        {showChart && (
          <QualityChart
            aygosQuality={[
              formData.moistureContent,
              formData.freeFattyAcids,
              formData.peroxideValue,
              formData.aflatoxin,
              formData.eColi,
              formData.salmonella,
              formData.listeria,
              formData.staphylococcus,
            ]}
            internationalStandards={internationalStandards}
          />
        )}
      </Paper>
    </Container>
  );
};

export default PerformanceQuality;
