
import React from 'react';
import { Breadcrumbs, Link, Typography, Box } from '@mui/material';
import { useLocation, Link as RouterLink } from 'react-router-dom';
import { Home as HomeIcon, ChevronRight as ChevronRightIcon } from '@mui/icons-material';

const NavigationBreadcrumb = () => {
  const location = useLocation();
  const pathnames = location.pathname.split('/').filter((x) => x);

  const breadcrumbNameMap = {
    '': 'Dashboard',
    'main-dashboard': 'Main Dashboard',
    'africa-negoce': 'Africa Negoce Industrie',
    'trading': 'Trading Operations',
    'supply-chain': 'Supply Chain',
    'inventory': 'Inventory Management',
    'financial': 'Financial Analytics',
    'market': 'Market Intelligence',
    'clients': 'Client Portal',
    'predictive-maintenance': 'Predictive Maintenance',
    'drilling': 'Drilling Equipment',
    'pumps': 'Pumping Systems',
    'pipelines': 'Pipeline Systems',
    'compressors': 'Compressors',
    'turbines': 'Turbines',
    'heat-exchangers': 'Heat Exchangers',
    'separators': 'Separators',
    'valves': 'Valves & Controls',
    'magasin-matiere-premiere': 'Raw Materials',
    'fragilisation': 'Fragilisation',
    'decorticage': 'Decorticage',
    'sechage': 'Sechage',
    'depelliculage': 'Depelliculage',
    'classification-epuration': 'Classification',
    'emballage-produits-fini': 'Packaging',
    'maintenance-scheduling': 'Maintenance',
    'reporting-analytics': 'Analytics'
  };

  return (
    <Box sx={{ mb: 2, mt: 1 }}>
      <Breadcrumbs 
        separator={<ChevronRightIcon fontSize="small" />}
        aria-label="breadcrumb"
        sx={{
          '& .MuiBreadcrumbs-separator': {
            color: '#666'
          }
        }}
      >
        <Link
          component={RouterLink}
          to="/main-dashboard"
          sx={{
            display: 'flex',
            alignItems: 'center',
            textDecoration: 'none',
            color: '#0078d4',
            '&:hover': {
              textDecoration: 'underline'
            }
          }}
        >
          <HomeIcon sx={{ mr: 0.5 }} fontSize="inherit" />
          Home
        </Link>
        
        {pathnames.map((value, index) => {
          const last = index === pathnames.length - 1;
          const to = `/${pathnames.slice(0, index + 1).join('/')}`;
          const displayName = breadcrumbNameMap[value] || value.charAt(0).toUpperCase() + value.slice(1);

          return last ? (
            <Typography color="text.primary" key={to} sx={{ fontWeight: 500 }}>
              {displayName}
            </Typography>
          ) : (
            <Link
              component={RouterLink}
              to={to}
              key={to}
              sx={{
                textDecoration: 'none',
                color: '#0078d4',
                '&:hover': {
                  textDecoration: 'underline'
                }
              }}
            >
              {displayName}
            </Link>
          );
        })}
      </Breadcrumbs>
    </Box>
  );
};

export default NavigationBreadcrumb;
