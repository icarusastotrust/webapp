
import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Button,
  Grid,
  Paper,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Snackbar,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box,
  Card,
  CardContent,
  Divider,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemIcon
} from '@mui/material';
import MuiAlert from '@mui/material/Alert';
import { QrCode, Scanner, CheckCircle, Cancel, History } from '@mui/icons-material';
import AppLayout from './AppLayout';
import NavigationBreadcrumb from './NavigationBreadcrumb';
import axios from 'axios';

const Alert = React.forwardRef((props, ref) => {
  return <MuiAlert elevation={6} variant="filled" ref={ref} {...props} />;
});

const API_BASE_URL = `${window.location.protocol}//${window.location.host.split(':')[0]}:5000/api`;

const QRCodeScanner = () => {
  const [scannedData, setScannedData] = useState(null);
  const [formOpen, setFormOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [scanHistory, setScanHistory] = useState([]);
  const [deactivatedQRs, setDeactivatedQRs] = useState([]);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState('success');
  
  // Form data for QR code scanning
  const [formData, setFormData] = useState({
    scannedById: '',
    scannerName: '',
    location: '',
    temperature: '',
    humidity: '',
    qualityCheck: '',
    notes: '',
    processStage: '',
    batchCondition: 'good'
  });

  // Admin form for activation/deactivation
  const [adminData, setAdminData] = useState({
    batchCode: '',
    uniqueId: '',
    action: 'deactivate',
    reason: ''
  });

  // Manual QR input
  const [manualInput, setManualInput] = useState('');

  useEffect(() => {
    fetchScanHistory();
    fetchDeactivatedQRs();
  }, []);

  const fetchScanHistory = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/qrcode/scans`);
      setScanHistory(response.data);
    } catch (error) {
      console.error('Error fetching scan history:', error);
    }
  };

  const fetchDeactivatedQRs = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/qrcode/deactivated`);
      setDeactivatedQRs(response.data);
    } catch (error) {
      console.error('Error fetching deactivated QR codes:', error);
    }
  };

  const handleManualScan = () => {
    if (!manualInput.trim()) {
      setSnackbarMessage('Please enter QR code data');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
      return;
    }

    try {
      const qrData = JSON.parse(manualInput);
      handleQRCodeScan(qrData);
    } catch (error) {
      setSnackbarMessage('Invalid QR code format');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
    }
  };

  const handleQRCodeScan = async (qrData) => {
    try {
      // Check if QR code is active
      const statusResponse = await axios.get(`${API_BASE_URL}/qrcode/status/${qrData.uniqueId}`);
      
      if (!statusResponse.data.isActive) {
        setSnackbarMessage('This QR code has been deactivated and cannot be scanned');
        setSnackbarSeverity('error');
        setSnackbarOpen(true);
        return;
      }

      setScannedData(qrData);
      setFormData({
        scannedById: '',
        scannerName: '',
        location: '',
        temperature: '',
        humidity: '',
        qualityCheck: '',
        notes: '',
        processStage: '',
        batchCondition: 'good'
      });
      setFormOpen(true);
    } catch (error) {
      console.error('Error checking QR code status:', error);
      setSnackbarMessage('Error verifying QR code status');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
    }
  };

  const handleFormSubmit = async () => {
    if (!formData.scannedById || !formData.scannerName || !formData.location) {
      setSnackbarMessage('Please fill in all required fields');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
      return;
    }

    try {
      const scanRecord = {
        qrCodeId: scannedData.uniqueId,
        batchCode: scannedData.batchCode,
        lotNumber: scannedData.lotNumber,
        scanTimestamp: new Date().toISOString(),
        scannedBy: {
          id: formData.scannedById,
          name: formData.scannerName
        },
        scanData: {
          location: formData.location,
          temperature: formData.temperature,
          humidity: formData.humidity,
          qualityCheck: formData.qualityCheck,
          notes: formData.notes,
          processStage: formData.processStage,
          batchCondition: formData.batchCondition
        },
        originalQRData: scannedData
      };

      await axios.post(`${API_BASE_URL}/qrcode/scan`, scanRecord);
      
      setSnackbarMessage('Scan recorded successfully!');
      setSnackbarSeverity('success');
      setSnackbarOpen(true);
      setFormOpen(false);
      setScannedData(null);
      setManualInput('');
      fetchScanHistory();
    } catch (error) {
      console.error('Error recording scan:', error);
      setSnackbarMessage('Error recording scan data');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
    }
  };

  const handleAdminAction = async () => {
    if (!adminData.batchCode || !adminData.uniqueId) {
      setSnackbarMessage('Please provide both batch code and unique ID');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
      return;
    }

    if (adminData.action === 'deactivate' && !adminData.reason) {
      setSnackbarMessage('Please provide a reason for deactivation');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
      return;
    }

    try {
      const actionData = {
        batchCode: adminData.batchCode,
        uniqueId: adminData.uniqueId,
        action: adminData.action,
        reason: adminData.reason,
        timestamp: new Date().toISOString(),
        adminId: 'admin-user' // This should come from authentication context
      };

      await axios.post(`${API_BASE_URL}/qrcode/admin-action`, actionData);
      
      setSnackbarMessage(`QR code ${adminData.action}d successfully!`);
      setSnackbarSeverity('success');
      setSnackbarOpen(true);
      setAdminOpen(false);
      setAdminData({
        batchCode: '',
        uniqueId: '',
        action: 'deactivate',
        reason: ''
      });
      fetchDeactivatedQRs();
    } catch (error) {
      console.error('Error performing admin action:', error);
      setSnackbarMessage('Error performing action');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
    }
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleAdminChange = (e) => {
    const { name, value } = e.target;
    setAdminData({ ...adminData, [name]: value });
  };

  const handleSnackbarClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setSnackbarOpen(false);
  };

  return (
    <AppLayout>
      <Container maxWidth="xl" sx={{ py: 3 }}>
        <NavigationBreadcrumb />
        <Typography variant="h4" component="h1" gutterBottom>
          QR Code Scanner & Tracking System
        </Typography>

        <Grid container spacing={3}>
          {/* Manual QR Code Input */}
          <Grid item xs={12} md={6}>
            <Card elevation={3}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  <QrCode sx={{ mr: 1, verticalAlign: 'middle' }} />
                  Scan QR Code
                </Typography>
                <Box sx={{ mt: 2 }}>
                  <TextField
                    fullWidth
                    multiline
                    rows={4}
                    label="Paste QR Code Data Here"
                    value={manualInput}
                    onChange={(e) => setManualInput(e.target.value)}
                    placeholder="Paste the QR code JSON data here..."
                    sx={{ mb: 2 }}
                  />
                  <Button
                    variant="contained"
                    color="primary"
                    fullWidth
                    onClick={handleManualScan}
                    startIcon={<Scanner />}
                  >
                    Process QR Code
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>

          {/* Admin Controls */}
          <Grid item xs={12} md={6}>
            <Card elevation={3}>
              <CardContent>
                <Typography variant="h6" gutterBottom color="error">
                  Admin Controls
                </Typography>
                <Button
                  variant="contained"
                  color="error"
                  fullWidth
                  onClick={() => setAdminOpen(true)}
                  sx={{ mb: 2 }}
                >
                  Activate/Deactivate QR Codes
                </Button>
                <Typography variant="body2" color="text.secondary">
                  Manage QR code status and track deactivated codes
                </Typography>
              </CardContent>
            </Card>
          </Grid>

          {/* Scan History */}
          <Grid item xs={12} md={6}>
            <Card elevation={3}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  <History sx={{ mr: 1, verticalAlign: 'middle' }} />
                  Recent Scans ({scanHistory.length})
                </Typography>
                <Box sx={{ maxHeight: 300, overflow: 'auto' }}>
                  <List dense>
                    {scanHistory.slice(0, 5).map((scan, index) => (
                      <ListItem key={index}>
                        <ListItemIcon>
                          <CheckCircle color="success" />
                        </ListItemIcon>
                        <ListItemText
                          primary={`${scan.qrCodeId}`}
                          secondary={`${scan.scannedBy.name} - ${new Date(scan.scanTimestamp).toLocaleString()}`}
                        />
                      </ListItem>
                    ))}
                  </List>
                </Box>
              </CardContent>
            </Card>
          </Grid>

          {/* Deactivated QR Codes */}
          <Grid item xs={12} md={6}>
            <Card elevation={3}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  <Cancel sx={{ mr: 1, verticalAlign: 'middle' }} />
                  Deactivated QR Codes ({deactivatedQRs.length})
                </Typography>
                <Box sx={{ maxHeight: 300, overflow: 'auto' }}>
                  <List dense>
                    {deactivatedQRs.slice(0, 5).map((qr, index) => (
                      <ListItem key={index}>
                        <ListItemIcon>
                          <Cancel color="error" />
                        </ListItemIcon>
                        <ListItemText
                          primary={`${qr.uniqueId}`}
                          secondary={`Reason: ${qr.reason} - ${new Date(qr.timestamp).toLocaleString()}`}
                        />
                      </ListItem>
                    ))}
                  </List>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* QR Code Form Dialog */}
        <Dialog open={formOpen} onClose={() => setFormOpen(false)} maxWidth="md" fullWidth>
          <DialogTitle>QR Code Scan Form</DialogTitle>
          <DialogContent>
            {scannedData && (
              <Box sx={{ mb: 3, p: 2, backgroundColor: '#f5f5f5', borderRadius: 1 }}>
                <Typography variant="h6" gutterBottom>QR Code Information:</Typography>
                <Typography><strong>Unique ID:</strong> {scannedData.uniqueId}</Typography>
                <Typography><strong>Batch Code:</strong> {scannedData.batchCode}</Typography>
                <Typography><strong>Lot Number:</strong> {scannedData.lotNumber}</Typography>
                <Typography><strong>Sequence:</strong> {scannedData.sequenceNumber}</Typography>
              </Box>
            )}
            
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  name="scannedById"
                  label="Scanner ID"
                  value={formData.scannedById}
                  onChange={handleFormChange}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  name="scannerName"
                  label="Scanner Name"
                  value={formData.scannerName}
                  onChange={handleFormChange}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  name="location"
                  label="Scan Location"
                  value={formData.location}
                  onChange={handleFormChange}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel>Process Stage</InputLabel>
                  <Select
                    name="processStage"
                    value={formData.processStage}
                    onChange={handleFormChange}
                    label="Process Stage"
                  >
                    <MenuItem value="reception">Reception</MenuItem>
                    <MenuItem value="fragilisation">Fragilisation</MenuItem>
                    <MenuItem value="decorticage">Décorticage</MenuItem>
                    <MenuItem value="sechage">Séchage</MenuItem>
                    <MenuItem value="depelliculage">Dépelliculage</MenuItem>
                    <MenuItem value="emballage">Emballage</MenuItem>
                    <MenuItem value="expedition">Expédition</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  name="temperature"
                  label="Temperature (°C)"
                  type="number"
                  value={formData.temperature}
                  onChange={handleFormChange}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  name="humidity"
                  label="Humidity (%)"
                  type="number"
                  value={formData.humidity}
                  onChange={handleFormChange}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel>Quality Check</InputLabel>
                  <Select
                    name="qualityCheck"
                    value={formData.qualityCheck}
                    onChange={handleFormChange}
                    label="Quality Check"
                  >
                    <MenuItem value="passed">Passed</MenuItem>
                    <MenuItem value="failed">Failed</MenuItem>
                    <MenuItem value="needs_review">Needs Review</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel>Batch Condition</InputLabel>
                  <Select
                    name="batchCondition"
                    value={formData.batchCondition}
                    onChange={handleFormChange}
                    label="Batch Condition"
                  >
                    <MenuItem value="excellent">Excellent</MenuItem>
                    <MenuItem value="good">Good</MenuItem>
                    <MenuItem value="fair">Fair</MenuItem>
                    <MenuItem value="poor">Poor</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={3}
                  name="notes"
                  label="Additional Notes"
                  value={formData.notes}
                  onChange={handleFormChange}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setFormOpen(false)}>Cancel</Button>
            <Button onClick={handleFormSubmit} variant="contained" color="primary">
              Submit Scan Data
            </Button>
          </DialogActions>
        </Dialog>

        {/* Admin Action Dialog */}
        <Dialog open={adminOpen} onClose={() => setAdminOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>Admin: Manage QR Codes</DialogTitle>
          <DialogContent>
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  name="batchCode"
                  label="Batch Code"
                  value={adminData.batchCode}
                  onChange={handleAdminChange}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  name="uniqueId"
                  label="Unique QR ID"
                  value={adminData.uniqueId}
                  onChange={handleAdminChange}
                />
              </Grid>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>Action</InputLabel>
                  <Select
                    name="action"
                    value={adminData.action}
                    onChange={handleAdminChange}
                    label="Action"
                  >
                    <MenuItem value="activate">Activate</MenuItem>
                    <MenuItem value="deactivate">Deactivate</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              {adminData.action === 'deactivate' && (
                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    multiline
                    rows={3}
                    name="reason"
                    label="Reason for Deactivation"
                    value={adminData.reason}
                    onChange={handleAdminChange}
                  />
                </Grid>
              )}
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setAdminOpen(false)}>Cancel</Button>
            <Button onClick={handleAdminAction} variant="contained" color="error">
              {adminData.action === 'activate' ? 'Activate' : 'Deactivate'} QR Code
            </Button>
          </DialogActions>
        </Dialog>

        <Snackbar
          open={snackbarOpen}
          autoHideDuration={6000}
          onClose={handleSnackbarClose}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        >
          <Alert onClose={handleSnackbarClose} severity={snackbarSeverity}>
            {snackbarMessage}
          </Alert>
        </Snackbar>
      </Container>
    </AppLayout>
  );
};

export default QRCodeScanner;
