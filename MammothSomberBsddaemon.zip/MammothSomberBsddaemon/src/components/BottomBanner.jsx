
import React, { useState } from 'react';
import { Box, Typography, Link } from '@mui/material';
import { styled } from '@mui/system';
import { 
  SupportModal, 
  DocumentationModal, 
  PrivacyPolicyModal, 
  TermsOfServiceModal 
} from './PolicyModals';

const BannerContainer = styled(Box)(({ open }) => ({
  background: 'linear-gradient(135deg, #263238, #37474f)',
  color: 'white',
  padding: '20px 24px',
  position: 'fixed',
  bottom: 0,
  right: 0,
  width: open ? '400px' : '0px',
  height: 'auto',
  borderTop: '3px solid #1976d2',
  borderLeft: '3px solid #1976d2',
  borderTopLeftRadius: '8px',
  transition: 'width 0.3s ease, opacity 0.3s ease',
  opacity: open ? 1 : 0,
  overflow: 'hidden',
  zIndex: 1200,
  boxShadow: open ? '0 -4px 20px rgba(0,0,0,0.3)' : 'none',
}));

const BottomBanner = ({ open = true, onMouseEnter, onMouseLeave }) => {
  const [modals, setModals] = useState({
    support: false,
    documentation: false,
    privacy: false,
    terms: false
  });

  const handleModalOpen = (modalType) => {
    setModals(prev => ({ ...prev, [modalType]: true }));
  };

  const handleModalClose = (modalType) => {
    setModals(prev => ({ ...prev, [modalType]: false }));
  };

  return (
    <BannerContainer 
      open={open}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      <Box display="flex" justifyContent="space-between" alignItems="center" flexWrap="wrap" gap={2}>
        <Box>
          <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 1 }}>
            AFRICA NEGOCE INDUSTRIE
          </Typography>
          <Typography variant="body2" sx={{ opacity: 0.8 }}>
            Advanced Manufacturing Operations & Predictive Maintenance Solutions
          </Typography>
        </Box>
        
        <Box textAlign="right">
          <Typography variant="body2" sx={{ mb: 1 }}>
            Powered by ICARUS SYSTEM v2.0
          </Typography>
          <Typography variant="caption" sx={{ opacity: 0.7 }}>
            © 2024 Africa Negoce Industrie. All rights reserved.
          </Typography>
        </Box>
      </Box>
      
      <Box 
        display="flex" 
        justifyContent="center" 
        alignItems="center" 
        gap={3} 
        mt={2} 
        pt={2} 
        borderTop="1px solid rgba(255,255,255,0.1)"
      >
        <Link 
          component="button"
          color="inherit" 
          sx={{ 
            opacity: 0.8, 
            '&:hover': { opacity: 1 },
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            textDecoration: 'underline'
          }}
          onClick={() => handleModalOpen('support')}
        >
          Support
        </Link>
        <Link 
          component="button"
          color="inherit" 
          sx={{ 
            opacity: 0.8, 
            '&:hover': { opacity: 1 },
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            textDecoration: 'underline'
          }}
          onClick={() => handleModalOpen('documentation')}
        >
          Documentation
        </Link>
        <Link 
          component="button"
          color="inherit" 
          sx={{ 
            opacity: 0.8, 
            '&:hover': { opacity: 1 },
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            textDecoration: 'underline'
          }}
          onClick={() => handleModalOpen('privacy')}
        >
          Privacy Policy
        </Link>
        <Link 
          component="button"
          color="inherit" 
          sx={{ 
            opacity: 0.8, 
            '&:hover': { opacity: 1 },
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            textDecoration: 'underline'
          }}
          onClick={() => handleModalOpen('terms')}
        >
          Terms of Service
        </Link>
      </Box>

      {/* Modal Components */}
      <SupportModal 
        open={modals.support} 
        onClose={() => handleModalClose('support')} 
      />
      <DocumentationModal 
        open={modals.documentation} 
        onClose={() => handleModalClose('documentation')} 
      />
      <PrivacyPolicyModal 
        open={modals.privacy} 
        onClose={() => handleModalClose('privacy')} 
      />
      <TermsOfServiceModal 
        open={modals.terms} 
        onClose={() => handleModalClose('terms')} 
      />
    </BannerContainer>
  );
};

export default BottomBanner;
