
import React, { useState } from 'react';
import {
  Container,
  Typography,
  Grid,
  Box,
  Card,
  CardContent,
  IconButton,
  AppBar,
  Toolbar,
  Avatar,
  Badge,
  Button,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Fab,
  LinearProgress
} from '@mui/material';
import {
  Business as BusinessIcon,
  TrendingUp as TrendingUpIcon,
  Add as AddIcon,
  Search as SearchIcon,
  Notifications as NotificationsIcon,
  Settings as SettingsIcon,
  MenuBook as MenuBookIcon,
  Menu as MenuIcon,
  ArrowBack as ArrowBackIcon,
  CheckCircle as CheckCircleIcon,
  Schedule as ScheduleIcon,
  LocalShipping as LocalShippingIcon
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import ModuleSidebar from './ModuleSidebar';
import TopBanner from './TopBanner';
import NavigationBreadcrumb from './NavigationBreadcrumb';

const AfricaNegoceTrading = () => {
  const navigate = useNavigate();
  const { user, userRole } = useAuth();
  const [navigationOpen, setNavigationOpen] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [openDialog, setOpenDialog] = useState(false);

  // Sample trading data
  const [trades, setTrades] = useState([
    {
      id: 'ANI-2024-001',
      commodity: 'Cashew Nuts',
      quantity: 500,
      unit: 'MT',
      price: 3500,
      currency: 'USD',
      buyer: 'European Trading Ltd',
      status: 'active',
      deliveryDate: '2024-02-15',
      origin: 'Ivory Coast',
      destination: 'Hamburg, Germany'
    },
    {
      id: 'ANI-2024-002',
      commodity: 'Cocoa Beans',
      quantity: 1000,
      unit: 'MT',
      price: 2800,
      currency: 'USD',
      buyer: 'Swiss Commodities AG',
      status: 'pending',
      deliveryDate: '2024-02-20',
      origin: 'Ghana',
      destination: 'Rotterdam, Netherlands'
    },
    {
      id: 'ANI-2024-003',
      commodity: 'Palm Oil',
      quantity: 750,
      unit: 'MT',
      price: 950,
      currency: 'USD',
      buyer: 'Asian Markets Co',
      status: 'completed',
      deliveryDate: '2024-01-30',
      origin: 'Nigeria',
      destination: 'Singapore'
    }
  ]);

  const handleNavigationToggle = () => {
    setNavigationOpen(!navigationOpen);
  };

  const handleMouseEnterTrigger = () => {
    setIsHovering(true);
    setNavigationOpen(true);
  };

  const handleMouseLeaveTrigger = () => {
    setIsHovering(false);
    setTimeout(() => {
      if (!isHovering) {
        setNavigationOpen(false);
      }
    }, 300);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'primary';
      case 'pending': return 'warning';
      case 'completed': return 'success';
      default: return 'default';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active': return <TrendingUpIcon />;
      case 'pending': return <ScheduleIcon />;
      case 'completed': return <CheckCircleIcon />;
      default: return <ScheduleIcon />;
    }
  };

  const filteredTrades = trades.filter(trade =>
    trade.commodity.toLowerCase().includes(searchTerm.toLowerCase()) ||
    trade.buyer.toLowerCase().includes(searchTerm.toLowerCase()) ||
    trade.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalValue = trades.reduce((sum, trade) => sum + (trade.quantity * trade.price), 0);
  const activeCount = trades.filter(t => t.status === 'active').length;
  const completedCount = trades.filter(t => t.status === 'completed').length;

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', backgroundColor: '#f8fafc', position: 'relative' }}>
      <TopBanner />

      {/* Hover trigger zone for navigation */}
      <Box
        sx={{
          position: 'fixed',
          left: 0,
          top: 0,
          width: '20px',
          height: '100vh',
          zIndex: 1300,
          backgroundColor: 'transparent'
        }}
        onMouseEnter={handleMouseEnterTrigger}
      />

      <ModuleSidebar 
        open={navigationOpen} 
        onToggle={handleNavigationToggle}
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={handleMouseLeaveTrigger}
      />

      <Box 
        component="main" 
        sx={{ 
          flexGrow: 1,
          transition: 'margin-left 0.3s ease',
          marginLeft: 0,
          width: '100%',
          minHeight: '100vh'
        }}
      >
        {/* Modern Header */}
        <AppBar 
          position="static" 
          elevation={0}
          sx={{ 
            backgroundColor: 'white',
            borderBottom: '1px solid #e0e7ff',
            color: 'text.primary',
            backdropFilter: 'blur(10px)'
          }}
        >
          <Toolbar sx={{ py: 1 }}>
            <IconButton
              onClick={handleNavigationToggle}
              sx={{ mr: 2, color: 'primary.main' }}
            >
              <MenuIcon />
            </IconButton>
            <IconButton
              onClick={() => navigate('/main-dashboard')}
              sx={{ mr: 2, color: 'primary.main' }}
            >
              <ArrowBackIcon />
            </IconButton>
            <BusinessIcon sx={{ mr: 2, color: 'primary.main', fontSize: 32 }} />
            <Box sx={{ flexGrow: 1 }}>
              <Typography variant="h5" sx={{ fontWeight: 700, color: 'primary.main' }}>
                Africa Negoce Trading
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Commodity trading and market operations
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button
                color="inherit"
                startIcon={<SettingsIcon />}
                onClick={() => navigate('/settings')}
                sx={{ color: 'primary.main' }}
              >
                Settings
              </Button>
              <Button
                color="inherit"
                startIcon={<MenuBookIcon />}
                onClick={() => navigate('/documentation')}
                sx={{ color: 'primary.main' }}
              >
                Docs
              </Button>
            </Box>

            <Box display="flex" alignItems="center" gap={3}>
              <Badge badgeContent={4} color="error">
                <IconButton>
                  <NotificationsIcon />
                </IconButton>
              </Badge>

              <Box display="flex" alignItems="center" gap={2}>
                <Avatar sx={{ bgcolor: 'primary.main', width: 40, height: 40 }}>
                  {user?.name?.charAt(0)}
                </Avatar>
                <Box>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                    {user?.name}
                  </Typography>
                  <Chip 
                    label={userRole} 
                    size="small" 
                    color="primary"
                    variant="outlined"
                    sx={{ height: 20, fontSize: '0.6rem' }}
                  />
                </Box>
              </Box>
            </Box>
          </Toolbar>
        </AppBar>

        <Container maxWidth="xl" sx={{ py: 4 }}>
          <NavigationBreadcrumb />

          {/* Hero Section */}
          <Card 
            sx={{ 
              mb: 4,
              background: 'linear-gradient(135deg, #ff6b35 0%, #f7931e 100%)',
              color: 'white',
              borderRadius: 3
            }}
          >
            <CardContent sx={{ p: 4 }}>
              <Grid container spacing={4} alignItems="center">
                <Grid item xs={12} md={8}>
                  <Typography variant="h3" sx={{ fontWeight: 700, mb: 2 }}>
                    Trading Operations
                  </Typography>
                  <Typography variant="h6" sx={{ opacity: 0.9, mb: 3 }}>
                    Manage commodity trading, track shipments, and optimize supply chain operations
                  </Typography>
                  <Box display="flex" gap={2}>
                    <Button 
                      variant="contained" 
                      size="large"
                      onClick={() => setOpenDialog(true)}
                      sx={{ 
                        backgroundColor: 'white', 
                        color: 'primary.main',
                        '&:hover': { backgroundColor: 'grey.100' }
                      }}
                    >
                      New Trade
                    </Button>
                    <Button 
                      variant="outlined" 
                      size="large"
                      sx={{ 
                        borderColor: 'white', 
                        color: 'white',
                        '&:hover': { backgroundColor: 'rgba(255,255,255,0.1)' }
                      }}
                    >
                      Market Report
                    </Button>
                  </Box>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Box textAlign="center">
                    <BusinessIcon sx={{ fontSize: 120, opacity: 0.3 }} />
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Trading Stats */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ borderRadius: 3 }}>
                <CardContent>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    Total Trades
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>
                    {trades.length}
                  </Typography>
                  <Chip label="Active" size="small" color="primary" variant="outlined" />
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ borderRadius: 3 }}>
                <CardContent>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    Total Value
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>
                    ${(totalValue / 1000000).toFixed(1)}M
                  </Typography>
                  <Chip label="+12.5%" size="small" color="success" variant="outlined" />
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ borderRadius: 3 }}>
                <CardContent>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    Active Contracts
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>
                    {activeCount}
                  </Typography>
                  <Chip label="In Progress" size="small" color="primary" variant="outlined" />
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ borderRadius: 3 }}>
                <CardContent>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    Completed
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>
                    {completedCount}
                  </Typography>
                  <Chip label="Delivered" size="small" color="success" variant="outlined" />
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* Search and Controls */}
          <Card sx={{ mb: 4, borderRadius: 3 }}>
            <CardContent>
              <Grid container spacing={3} alignItems="center">
                <Grid item xs={12} md={8}>
                  <TextField
                    fullWidth
                    placeholder="Search trades, commodities, or buyers..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    InputProps={{
                      startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} />
                    }}
                    sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <Box display="flex" gap={2} justifyContent="flex-end">
                    <Button
                      variant="contained"
                      startIcon={<AddIcon />}
                      onClick={() => setOpenDialog(true)}
                      sx={{ borderRadius: 2 }}
                    >
                      New Trade
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Trading Table */}
          <Card sx={{ borderRadius: 3 }}>
            <CardContent>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                Active Trading Portfolio
              </Typography>
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 600 }}>Trade ID</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Commodity</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Quantity</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Buyer</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Value</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Delivery</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Route</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {filteredTrades.map((trade) => (
                      <TableRow key={trade.id} hover>
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 600, fontFamily: 'monospace' }}>
                            {trade.id}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 500 }}>
                            {trade.commodity}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {trade.quantity.toLocaleString()} {trade.unit}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {trade.buyer}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            ${(trade.quantity * trade.price).toLocaleString()} {trade.currency}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            icon={getStatusIcon(trade.status)}
                            label={trade.status.toUpperCase()}
                            color={getStatusColor(trade.status)}
                            size="small"
                            variant="outlined"
                          />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {trade.deliveryDate}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Box>
                            <Typography variant="caption" color="text.secondary">
                              {trade.origin}
                            </Typography>
                            <LocalShippingIcon sx={{ mx: 0.5, fontSize: 12, color: 'text.secondary' }} />
                            <Typography variant="caption" color="text.secondary">
                              {trade.destination}
                            </Typography>
                          </Box>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Container>

        {/* Floating Action Button */}
        <Fab
          color="primary"
          aria-label="add trade"
          onClick={() => setOpenDialog(true)}
          sx={{
            position: 'fixed',
            bottom: 32,
            right: 32,
            zIndex: 1000
          }}
        >
          <AddIcon />
        </Fab>

        {/* New Trade Dialog */}
        <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="md" fullWidth>
          <DialogTitle>Create New Trade</DialogTitle>
          <DialogContent>
            <Grid container spacing={3} sx={{ mt: 1 }}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Commodity"
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Quantity"
                  type="number"
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Unit Price (USD)"
                  type="number"
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Buyer"
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Origin"
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Destination"
                  variant="outlined"
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
            <Button variant="contained" onClick={() => setOpenDialog(false)}>
              Create Trade
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Box>
  );
};

export default AfricaNegoceTrading;
