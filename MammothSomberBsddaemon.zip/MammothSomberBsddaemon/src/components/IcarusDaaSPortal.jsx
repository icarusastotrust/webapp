
import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  Alert,
  Box,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  DialogActions,
  AppBar,
  Toolbar,
  IconButton
} from '@mui/material';
import {
  Security as SecurityIcon,
  Agriculture as AgricultureIcon,
  Build as OilGasIcon,
  Engineering as MiningIcon,
  ArrowBack as ArrowBackIcon,
  FlightTakeoff as DroneIcon
} from '@mui/icons-material';
import AgricultureDaaSSubsection from './AgricultureDaaSSubsection';

const IcarusDaaSPortal = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [selectedSubsection, setSelectedSubsection] = useState('');
  const [selectedDrone, setSelectedDrone] = useState(null);
  const [bookingDialog, setBookingDialog] = useState(false);
  const [selectedMission, setSelectedMission] = useState('');
  const [navigationOpen, setNavigationOpen] = useState(true);

  // DaaS Password (in production, this should be more secure)
  const DAAS_PASSWORD = 'ICARUS-DAAS-2024';

  const handlePasswordSubmit = () => {
    if (password === DAAS_PASSWORD) {
      setIsAuthenticated(true);
      setPasswordError('');
    } else {
      setPasswordError('Invalid password. Access denied.');
    }
  };

  const subsections = [
    {
      id: 'military',
      title: 'MILITARY AND DEFENCE APPLICATION',
      icon: <SecurityIcon sx={{ fontSize: 60, color: '#8B0000' }} />,
      color: '#8B0000',
      missions: ['ISR MISSION', 'STRIKING MISSION', 'SWARMING STRIKING']
    },
    {
      id: 'agriculture',
      title: 'AGRICULTURE APPLICATION',
      icon: <AgricultureIcon sx={{ fontSize: 60, color: '#228B22' }} />,
      color: '#228B22',
      missions: ['PESTICIDE SPRAYING', 'WATER SPRAYING', 'AGRICULTURE LAND MAPPING', 'PEST IDENTIFICATION', 'CROPS SPRAYING MISSION']
    },
    {
      id: 'oil-gas',
      title: 'OIL AND GAS APPLICATION',
      icon: <OilGasIcon sx={{ fontSize: 60, color: '#FF8C00' }} />,
      color: '#FF8C00',
      missions: ['PIPELINE INSPECTION', 'LEAK DETECTION', 'INFRASTRUCTURE MONITORING']
    },
    {
      id: 'mining',
      title: 'MINING APPLICATION',
      icon: <MiningIcon sx={{ fontSize: 60, color: '#696969' }} />,
      color: '#696969',
      missions: ['SITE SURVEYING', 'STOCKPILE MONITORING', 'SAFETY INSPECTION']
    }
  ];

  const drones = {
    military: [
      {
        id: 'MIL-001',
        name: 'Reaper MQ-9 Combat',
        image: '/test.png',
        specifications: {
          'Max Speed': '482 km/h',
          'Flight Time': '14 hours',
          'Payload': '1,700 kg',
          'Range': '1,850 km',
          'Altitude': '15,240 m',
          'Sensors': 'Multi-Spectral Targeting System'
        },
        availability: 'Available',
        cost: '$15,000/day'
      },
      {
        id: 'MIL-002',
        name: 'Predator B Hunter',
        image: '/test.png',
        specifications: {
          'Max Speed': '400 km/h',
          'Flight Time': '12 hours',
          'Payload': '1,200 kg',
          'Range': '1,600 km',
          'Altitude': '12,000 m',
          'Sensors': 'Infrared/Thermal Imaging'
        },
        availability: 'Available',
        cost: '$12,000/day'
      }
    ],
    agriculture: [
      {
        id: 'AGR-001',
        name: 'AgroDrone X1 Pro',
        image: '/test.png',
        specifications: {
          'Max Speed': '65 km/h',
          'Flight Time': '8 hours',
          'Payload': '40 liters',
          'Range': '50 km',
          'Altitude': '500 m',
          'Sensors': 'Multispectral Camera, GPS'
        },
        availability: 'Available',
        cost: '$800/day'
      },
      {
        id: 'AGR-002',
        name: 'CropGuardian 5000',
        image: '/test.png',
        specifications: {
          'Max Speed': '80 km/h',
          'Flight Time': '10 hours',
          'Payload': '60 liters',
          'Range': '75 km',
          'Altitude': '800 m',
          'Sensors': 'NDVI Camera, Thermal Sensor'
        },
        availability: 'Available',
        cost: '$1,200/day'
      },
      {
        id: 'AGR-003',
        name: 'PestHunter Elite',
        image: '/test.png',
        specifications: {
          'Max Speed': '70 km/h',
          'Flight Time': '6 hours',
          'Payload': '25 liters',
          'Range': '40 km',
          'Altitude': '300 m',
          'Sensors': 'AI Vision System, Chemical Detector'
        },
        availability: 'Maintenance',
        cost: '$950/day'
      }
    ],
    'oil-gas': [
      {
        id: 'OG-001',
        name: 'PipelineInspector Pro',
        image: '/test.png',
        specifications: {
          'Max Speed': '120 km/h',
          'Flight Time': '12 hours',
          'Payload': '15 kg',
          'Range': '200 km',
          'Altitude': '1,000 m',
          'Sensors': 'Gas Detector, Thermal Camera'
        },
        availability: 'Available',
        cost: '$2,500/day'
      }
    ],
    mining: [
      {
        id: 'MIN-001',
        name: 'MineMapper 3D',
        image: '/test.png',
        specifications: {
          'Max Speed': '90 km/h',
          'Flight Time': '9 hours',
          'Payload': '20 kg',
          'Range': '100 km',
          'Altitude': '1,500 m',
          'Sensors': 'LiDAR, High-Res Camera'
        },
        availability: 'Available',
        cost: '$1,800/day'
      }
    ]
  };

  const handleNavigationToggle = () => {
    setNavigationOpen(!navigationOpen);
  };

  const handleDroneSelect = (drone) => {
    setSelectedDrone(drone);
    setBookingDialog(true);
  };

  const handleBookingConfirm = () => {
    // Here you would implement the actual booking logic
    alert(`Booking confirmed!\nDrone: ${selectedDrone.name}\nMission: ${selectedMission}\nCost: ${selectedDrone.cost}`);
    setBookingDialog(false);
    setSelectedDrone(null);
    setSelectedMission('');
  };

  if (!isAuthenticated) {
    return (
      <Container maxWidth="md" sx={{ mt: 8, textAlign: 'center' }}>
        <Box sx={{ p: 4, backgroundColor: '#f5f5f5', borderRadius: 2 }}>
          <DroneIcon sx={{ fontSize: 80, color: '#1976d2', mb: 2 }} />
          <Typography variant="h3" gutterBottom sx={{ fontWeight: 'bold' }}>
            ICARUS DaaS Portal
          </Typography>
          <Typography variant="h6" sx={{ mb: 4, color: '#666' }}>
            Drone as a Service Environment
          </Typography>
          
          <Paper sx={{ p: 4, maxWidth: 400, mx: 'auto' }}>
            <Typography variant="h6" gutterBottom>
              Access Control
            </Typography>
            <TextField
              fullWidth
              type="password"
              label="DaaS Access Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handlePasswordSubmit()}
              sx={{ mb: 2 }}
            />
            {passwordError && (
              <Alert severity="error" sx={{ mb: 2 }}>
                {passwordError}
              </Alert>
            )}
            <Button
              fullWidth
              variant="contained"
              onClick={handlePasswordSubmit}
              sx={{ py: 1.5 }}
            >
              Access DaaS Portal
            </Button>
          </Paper>
        </Box>
      </Container>
    );
  }

  if (selectedSubsection === 'agriculture') {
    return <AgricultureDaaSSubsection onBack={() => setSelectedSubsection('')} />;
  }

  if (selectedSubsection && selectedSubsection !== 'agriculture') {
    return (
      <Box sx={{ flexGrow: 1 }}>
        <AppBar position="static" sx={{ backgroundColor: '#1976d2' }}>
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              onClick={() => setSelectedSubsection('')}
            >
              <ArrowBackIcon />
            </IconButton>
            <Typography variant="h6" sx={{ flexGrow: 1 }}>
              {subsections.find(s => s.id === selectedSubsection)?.title}
            </Typography>
          </Toolbar>
        </AppBar>
        
        <Container maxWidth="xl" sx={{ mt: 4 }}>
          <Grid container spacing={3}>
            {drones[selectedSubsection]?.map((drone) => (
              <Grid item xs={12} md={6} lg={4} key={drone.id}>
                <Card sx={{ height: '100%' }}>
                  <CardMedia
                    component="img"
                    height="200"
                    image={drone.image}
                    alt={drone.name}
                    sx={{ cursor: 'pointer' }}
                    onClick={() => handleDroneSelect(drone)}
                  />
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      {drone.name}
                    </Typography>
                    <Chip
                      label={drone.availability}
                      color={drone.availability === 'Available' ? 'success' : 'warning'}
                      size="small"
                      sx={{ mb: 2 }}
                    />
                    <Typography variant="h6" color="primary" sx={{ mb: 2 }}>
                      {drone.cost}
                    </Typography>
                    
                    <TableContainer component={Paper} variant="outlined">
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell><strong>Specification</strong></TableCell>
                            <TableCell><strong>Value</strong></TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {Object.entries(drone.specifications).map(([key, value]) => (
                            <TableRow key={key}>
                              <TableCell>{key}</TableCell>
                              <TableCell>{value}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    
                    <Button
                      fullWidth
                      variant="contained"
                      sx={{ mt: 2 }}
                      onClick={() => handleDroneSelect(drone)}
                      disabled={drone.availability !== 'Available'}
                    >
                      Book Drone
                    </Button>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>
    );
  }

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static" sx={{ backgroundColor: '#1976d2' }}>
        <Toolbar>
          <DroneIcon sx={{ mr: 2 }} />
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            ICARUS DaaS Portal - Drone as a Service
          </Typography>
        </Toolbar>
      </AppBar>
      
      <Container maxWidth="xl" sx={{ mt: 4 }}>
        <Typography variant="h4" gutterBottom sx={{ textAlign: 'center', mb: 4 }}>
          Select Application Domain
        </Typography>
        
        <Grid container spacing={4}>
          {subsections.map((subsection) => (
            <Grid item xs={12} md={6} lg={3} key={subsection.id}>
              <Card 
                sx={{ 
                  height: '100%', 
                  cursor: 'pointer',
                  transition: 'transform 0.2s',
                  '&:hover': {
                    transform: 'scale(1.05)',
                    boxShadow: 6
                  }
                }}
                onClick={() => setSelectedSubsection(subsection.id)}
              >
                <CardContent sx={{ textAlign: 'center', p: 4 }}>
                  {subsection.icon}
                  <Typography variant="h6" sx={{ mt: 2, fontWeight: 'bold' }}>
                    {subsection.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    Available Missions: {subsection.missions.length}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Booking Dialog */}
      <Dialog open={bookingDialog} onClose={() => setBookingDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>Book Drone: {selectedDrone?.name}</DialogTitle>
        <DialogContent>
          <FormControl fullWidth sx={{ mt: 2 }}>
            <InputLabel>Select Mission Type</InputLabel>
            <Select
              value={selectedMission}
              onChange={(e) => setSelectedMission(e.target.value)}
              label="Select Mission Type"
            >
              {subsections.find(s => s.id === selectedSubsection)?.missions.map((mission) => (
                <MenuItem key={mission} value={mission}>
                  {mission}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          
          {selectedDrone && (
            <Box sx={{ mt: 3 }}>
              <Typography variant="h6" gutterBottom>Drone Specifications</Typography>
              <TableContainer component={Paper}>
                <Table>
                  <TableBody>
                    {Object.entries(selectedDrone.specifications).map(([key, value]) => (
                      <TableRow key={key}>
                        <TableCell><strong>{key}</strong></TableCell>
                        <TableCell>{value}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              <Typography variant="h6" color="primary" sx={{ mt: 2 }}>
                Cost: {selectedDrone.cost}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setBookingDialog(false)}>Cancel</Button>
          <Button 
            onClick={handleBookingConfirm}
            variant="contained"
            disabled={!selectedMission}
          >
            Confirm Booking
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default IcarusDaaSPortal;
