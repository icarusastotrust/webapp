
import React from 'react';
import { Box } from '@mui/material';
import TopBanner from './TopBanner';
import BottomBanner from './BottomBanner';
import NavigationPanel from './NavigationPanel';

const AppLayout = ({ children, showNavigation = true }) => {
  return (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column',
      minHeight: '100vh',
      backgroundColor: '#f5f7fa'
    }}>
      <TopBanner />
      {showNavigation && <NavigationPanel />}
      <Box sx={{ 
        flexGrow: 1, 
        ml: showNavigation ? { xs: 0, md: '280px' } : 0,
        transition: 'margin 0.3s ease'
      }}>
        {children}
      </Box>
      <BottomBanner />
    </Box>
  );
};

export default AppLayout;
