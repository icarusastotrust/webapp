import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { ThemeProvider, CssBaseline } from '@mui/material';
import { AuthProvider } from './components/AuthContext';
import { modernTheme } from './components/DesignSystem';
import MainDashboard from './components/MainDashboard';
import MagasinMatierePremiere from './components/MagasinMatierePremiere';
import Fragilisation from './components/Fragilisation';
import Decorticage from './components/Decorticage';
import Sechage from './components/Sechage';
import Depelliculage from './components/Depelliculage';
import ClassificationEpuration from './components/ClassificationEpuration';
import EmballageProduitsFini from './components/EmballageProduitsFini';
import MaintenanceScheduling from './components/MaintenanceScheduling';
import ReportingAnalytics from './components/ReportingAnalytics';
import MaintenanceEquipmentDatabase from './components/MaintenanceEquipmentDatabase';
import LoginPage from './components/LoginPage';
import RegisterPage from './components/RegisterPage';
import ForgotPasswordPage from './components/ForgotPasswordPage';
import PipelinePredictiveMaintenance from './components/PipelinePredictiveMaintenance';
import PipelineMaintenanceIdeas from './components/PipelineMaintenanceIdeas';
import AfricaNegoceTrading from './components/AfricaNegoceTrading';
import AfricaNegoceSupplyChain from './components/AfricaNegoceSupplyChain';
import QRCodeScanner from './components/QRCodeScanner';
import QRAnalytics from './components/QRAnalytics';
import SettingsPage from './components/SettingsPage';
import DocumentationPage from './components/DocumentationPage';
import PredictiveMaintenanceDrilling from './components/PredictiveMaintenanceDrilling';
import PredictiveMaintenancePumps from './components/PredictiveMaintenancePumps';
import IcarusDaaSPortal from './components/IcarusDaaSPortal';
import AgricultureDaaSSubsection from './components/AgricultureDaaSSubsection';

const App = () => {
  return (
    <ThemeProvider theme={modernTheme}>
      <CssBaseline />
      <AuthProvider>
        <Router>
          <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route path="/main-dashboard" element={<MainDashboard />} />
            <Route path="/magasin-matiere-premiere" element={<MagasinMatierePremiere />} />
            <Route path="/fragilisation" element={<Fragilisation />} />
            <Route path="/decorticage" element={<Decorticage />} />
            <Route path="/sechage" element={<Sechage />} />
            <Route path="/depelliculage" element={<Depelliculage />} />
            <Route path="/classification-epuration" element={<ClassificationEpuration />} />
            <Route path="/emballage-produits-fini" element={<EmballageProduitsFini />} />
            <Route path="/maintenance-scheduling" element={<MaintenanceScheduling />} />
            <Route path="/reporting-analytics" element={<ReportingAnalytics />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            <Route path="/pipeline-maintenance" element={<PipelinePredictiveMaintenance />} />
            <Route path="/pipeline-maintenance-ideas" element={<PipelineMaintenanceIdeas />} />
            <Route path="/africa-negoce/trading" element={<AfricaNegoceTrading />} />
            <Route path="/africa-negoce/supply-chain" element={<AfricaNegoceSupplyChain />} />
            <Route path="/qr-scanner" element={<QRCodeScanner />} />
            <Route path="/qr-analytics" element={<QRAnalytics />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/documentation" element={<DocumentationPage />} />
            <Route path="/africa-negoce/inventory" element={<div>Inventory Management - Coming Soon</div>} />
            <Route path="/africa-negoce/financial" element={<div>Financial Analytics - Coming Soon</div>} />
            <Route path="/africa-negoce/market" element={<div>Market Intelligence - Coming Soon</div>} />
            <Route path="/africa-negoce/clients" element={<div>Client Portal - Coming Soon</div>} />
            <Route path="/maintenance-equipment-database" element={<MaintenanceEquipmentDatabase />} />

            {/* Predictive Maintenance Portal Routes */}
            <Route path="/predictive-maintenance/drilling" element={<PredictiveMaintenanceDrilling />} />
            <Route path="/predictive-maintenance/pumps" element={<PredictiveMaintenancePumps />} />
            <Route path="/predictive-maintenance/compressors" element={<div>Compressor Maintenance - Coming Soon</div>} />
            <Route path="/predictive-maintenance/turbines" element={<div>Turbine Maintenance - Coming Soon</div>} />
            <Route path="/predictive-maintenance/heat-exchangers" element={<div>Heat Exchanger Maintenance - Coming Soon</div>} />
            <Route path="/predictive-maintenance/separators" element={<div>Separator Maintenance - Coming Soon</div>} />
            <Route path="/predictive-maintenance/pipelines" element={<PipelinePredictiveMaintenance />} />
            <Route path="/predictive-maintenance/valves" element={<div>Valve & Control Maintenance - Coming Soon</div>} />

            {/* DaaS Portal Routes */}
            <Route path="/icarus-daas" element={<IcarusDaaSPortal />} />
              <Route path="/agriculture-daas" element={<AgricultureDaaSSubsection />} />

          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
};

export default App;