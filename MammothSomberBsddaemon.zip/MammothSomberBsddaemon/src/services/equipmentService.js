
const API_BASE_URL = 'http://localhost:5000/api';

export class EquipmentService {
  // Get all equipment with optional filters
  static async getAllEquipment(filters = {}) {
    try {
      const queryParams = new URLSearchParams();
      
      Object.entries(filters).forEach(([key, value]) => {
        if (value && value !== 'all') {
          queryParams.append(key, value);
        }
      });

      const url = `${API_BASE_URL}/equipment${queryParams.toString() ? '?' + queryParams.toString() : ''}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error fetching equipment:', error);
      throw error;
    }
  }

  // Get single equipment by ID
  static async getEquipmentById(id) {
    try {
      const response = await fetch(`${API_BASE_URL}/equipment/${id}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error fetching equipment:', error);
      throw error;
    }
  }

  // Create new equipment
  static async createEquipment(equipmentData) {
    try {
      const response = await fetch(`${API_BASE_URL}/equipment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(equipmentData),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error creating equipment:', error);
      throw error;
    }
  }

  // Update equipment
  static async updateEquipment(id, equipmentData) {
    try {
      const response = await fetch(`${API_BASE_URL}/equipment/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(equipmentData),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error updating equipment:', error);
      throw error;
    }
  }

  // Delete equipment
  static async deleteEquipment(id) {
    try {
      const response = await fetch(`${API_BASE_URL}/equipment/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error deleting equipment:', error);
      throw error;
    }
  }

  // Get equipment analytics
  static async getEquipmentAnalytics() {
    try {
      const response = await fetch(`${API_BASE_URL}/equipment/analytics/dashboard`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error fetching equipment analytics:', error);
      throw error;
    }
  }

  // Add maintenance record
  static async addMaintenanceRecord(equipmentId, maintenanceData) {
    try {
      const response = await fetch(`${API_BASE_URL}/equipment/${equipmentId}/maintenance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(maintenanceData),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error adding maintenance record:', error);
      throw error;
    }
  }

  // Utility methods for status and type management
  static getEquipmentTypes() {
    return [
      'Drilling Equipment',
      'Pipeline Equipment',
      'Pump Systems',
      'Compressor Systems',
      'Valve Systems',
      'Control Systems',
      'Safety Equipment',
      'Measurement Equipment'
    ];
  }

  static getEquipmentStatuses() {
    return [
      { value: 'operational', label: 'Operational', color: 'success' },
      { value: 'maintenance', label: 'In Maintenance', color: 'warning' },
      { value: 'out_of_order', label: 'Out of Order', color: 'error' },
      { value: 'standby', label: 'Standby', color: 'info' }
    ];
  }

  static getCriticalityLevels() {
    return [
      { value: 'low', label: 'Low', color: 'success' },
      { value: 'medium', label: 'Medium', color: 'warning' },
      { value: 'high', label: 'High', color: 'error' },
      { value: 'critical', label: 'Critical', color: 'error' }
    ];
  }
}

export default EquipmentService;
