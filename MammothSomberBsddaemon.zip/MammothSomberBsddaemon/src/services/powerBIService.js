import { PublicClientApplication, LogLevel } from '@azure/msal-browser';
import { Client } from '@microsoft/microsoft-graph-client';
import { models } from 'powerbi-client';

class PowerBIService {
  constructor() {
    // Configuration for Government Cloud (GCC High/DoD)
    this.isGovernmentCloud = import.meta.env.VITE_GOVERNMENT_CLOUD === 'true';

    this.msalConfig = {
      auth: {
        clientId: import.meta.env.VITE_POWERBI_CLIENT_ID || 'your-client-id',
        authority: `https://login.microsoftonline.com/${import.meta.env.VITE_TENANT_ID || 'your-tenant-id'}`,
        redirectUri: window.location.origin,
        postLogoutRedirectUri: window.location.origin,
        navigateToLoginRequestUrl: false,
        // Enable B2C if needed for Government scenarios
        knownAuthorities: this.isGovernmentCloud 
          ? ['login.microsoftonline.us']
          : ['login.microsoftonline.com']
      },
      cache: {
        cacheLocation: 'localStorage', // sessionStorage for higher security
        storeAuthStateInCookie: false, // Set to true for IE11 compatibility
        secureCookies: true // Ensure cookies are secure
      },
      system: {
        loggerOptions: {
          loggerCallback: (level, message, containsPii) => {
            if (containsPii) return;
            switch (level) {
              case LogLevel.Error:
                console.error(message);
                break;
              case LogLevel.Warning:
                console.warn(message);
                break;
              case LogLevel.Info:
                console.info(message);
                break;
              case LogLevel.Verbose:
                console.debug(message);
                break;
            }
          },
          piiLoggingEnabled: false,
          logLevel: LogLevel.Warning
        },
        windowHashTimeout: 60000,
        iframeHashTimeout: 6000,
        loadFrameTimeout: 0,
        asyncPopups: false
      }
    };

    this.pca = new PublicClientApplication(this.msalConfig);

    // Government Cloud specific Power BI scopes
    this.powerBIScopes = this.isGovernmentCloud
      ? ['https://analysis.usgovcloudapi.net/powerbi/api/.default']
      : ['https://analysis.windows.net/powerbi/api/.default'];

    // Additional Microsoft Graph scopes for enterprise features
    this.graphScopes = [
      'User.Read',
      'Group.Read.All',
      'Directory.Read.All'
    ];

    this.powerBIApiBase = this.isGovernmentCloud
      ? 'https://api.powerbigov.us'
      : 'https://api.powerbi.com';

    this.initializeMsal();
  }

  async initializeMsal() {
    try {
      await this.pca.initialize();
      this.handleRedirectPromise();
    } catch (error) {
      console.error('MSAL initialization failed:', error);
      throw error;
    }
  }

  async handleRedirectPromise() {
    try {
      const response = await this.pca.handleRedirectPromise();
      if (response) {
        this.setActiveAccount(response.account);
        return response;
      }
    } catch (error) {
      console.error('Error handling redirect:', error);
      throw error;
    }
  }

  setActiveAccount(account) {
    this.pca.setActiveAccount(account);
  }

  async login() {
    try {
      const loginRequest = {
        scopes: [...this.powerBIScopes, ...this.graphScopes],
        prompt: 'select_account', // Force account selection for security
        extraScopesToConsent: this.graphScopes
      };

      const response = await this.pca.loginPopup(loginRequest);
      this.setActiveAccount(response.account);
      return response;
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    }
  }

  async logout() {
    try {
      const logoutRequest = {
        account: this.pca.getActiveAccount(),
        postLogoutRedirectUri: window.location.origin
      };

      await this.pca.logoutPopup(logoutRequest);
    } catch (error) {
      console.error('Logout failed:', error);
      throw error;
    }
  }

  async getAccessToken(scopes = this.powerBIScopes) {
    try {
      const activeAccount = this.pca.getActiveAccount();
      if (!activeAccount) {
        throw new Error('No active account found. Please login first.');
      }

      const silentRequest = {
        scopes: scopes,
        account: activeAccount,
        forceRefresh: false // Set to true if you want to skip cache
      };

      try {
        const response = await this.pca.acquireTokenSilent(silentRequest);
        return response.accessToken;
      } catch (silentError) {
        console.warn('Silent token acquisition failed:', silentError);

        // Fallback to interactive token acquisition
        const interactiveRequest = {
          scopes: scopes,
          account: activeAccount
        };

        const response = await this.pca.acquireTokenPopup(interactiveRequest);
        return response.accessToken;
      }
    } catch (error) {
      console.error('Error acquiring token:', error);
      throw error;
    }
  }

  async validateUserPermissions() {
    try {
      const graphToken = await this.getAccessToken(this.graphScopes);

      // Create Microsoft Graph client
      const authProvider = {
        getAccessToken: async () => graphToken
      };

      const graphClient = Client.initWithMiddleware({ authProvider });

      // Get user information and group memberships
      const user = await graphClient.api('/me').get();
      const groups = await graphClient.api('/me/memberOf').get();

      // Validate user has required permissions/groups for Power BI access
      const hasRequiredPermissions = this.validateRequiredGroups(groups.value);

      return {
        user,
        hasRequiredPermissions,
        groups: groups.value
      };
    } catch (error) {
      console.error('User validation failed:', error);
      throw error;
    }
  }

  validateRequiredGroups(userGroups) {
    // Define required security groups for Power BI access
    const requiredGroups = [
      'PowerBI-Users',
      'ANI-Industrie-Analytics',
      // Add your specific security groups here
    ];

    return requiredGroups.some(requiredGroup => 
      userGroups.some(group => 
        group.displayName === requiredGroup || 
        group.mail === requiredGroup
      )
    );
  }

  createEmbedConfig(reportId, embedUrl, accessToken) {
    return {
      type: 'report',
      id: reportId,
      embedUrl: embedUrl,
      accessToken: accessToken,
      tokenType: models.TokenType.Aad,
      settings: {
        panes: {
          filters: {
            expanded: false,
            visible: true
          },
          pageNavigation: {
            visible: true
          }
        },
        background: models.BackgroundType.Transparent,
        layoutType: models.LayoutType.FitToWidth,
        customLayout: {
          displayOption: models.DisplayOption.FitToPage
        },
        bars: {
          statusBar: {
            visible: true
          }
        },
        // Enterprise security settings
        permissions: models.Permissions.All,
        viewMode: models.ViewMode.View,
        datasetBinding: {
          datasetId: import.meta.env.VITE_DATASET_ID
        }
      },
      // Additional security headers
      headers: {
        'X-Frame-Options': 'SAMEORIGIN',
        'Content-Security-Policy': "frame-ancestors 'self'"
      }
    };
  }

  async getReports() {
    try {
      const accessToken = await this.getAccessToken();

      const response = await fetch(`${this.powerBIApiBase}/v1.0/myorg/reports`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data.value;
    } catch (error) {
      console.error('Error fetching reports:', error);
      throw error;
    }
  }

  async getWorkspaces() {
    try {
      const accessToken = await this.getAccessToken();

      const response = await fetch(`${this.powerBIApiBase}/v1.0/myorg/groups`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data.value;
    } catch (error) {
      console.error('Error fetching workspaces:', error);
      throw error;
    }
  }

  // Manufacturing specific configurations for Government compliance
  getManufacturingDashboardConfig() {
    this.reportConfigs = {
          main: {
            reportId: import.meta.env.VITE_MAIN_REPORT_ID,
            embedUrl: import.meta.env.VITE_MAIN_EMBED_URL,
            workspaceId: import.meta.env.VITE_MAIN_WORKSPACE_ID
          },
          maintenance: {
            reportId: import.meta.env.VITE_MAINTENANCE_REPORT_ID,
            embedUrl: import.meta.env.VITE_MAINTENANCE_EMBED_URL,
            workspaceId: import.meta.env.VITE_MAINTENANCE_WORKSPACE_ID
          }
        };
    return {
      mainDashboard: {
        reportId: import.meta.env.VITE_MAIN_REPORT_ID || '',
        embedUrl: import.meta.env.VITE_MAIN_EMBED_URL || '',
        workspaceId: import.meta.env.VITE_MAIN_WORKSPACE_ID || ''
      },
      productionMetrics: {
        reportId: import.meta.env.VITE_PRODUCTION_REPORT_ID || '',
        embedUrl: import.meta.env.VITE_PRODUCTION_EMBED_URL || '',
        workspaceId: import.meta.env.VITE_PRODUCTION_WORKSPACE_ID || ''
      },
      qualityControl: {
        reportId: import.meta.env.VITE_QUALITY_REPORT_ID || '',
        embedUrl: import.meta.env.VITE_QUALITY_EMBED_URL || '',
        workspaceId: import.meta.env.VITE_QUALITY_WORKSPACE_ID || ''
      },
      maintenanceAnalytics: {
        reportId: import.meta.env.VITE_MAINTENANCE_REPORT_ID || '',
        embedUrl: import.meta.env.VITE_MAINTENANCE_EMBED_URL || '',
        workspaceId: import.meta.env.VITE_MAINTENANCE_WORKSPACE_ID || ''
      }
    };
  }

  // Security audit logging
  async logSecurityEvent(eventType, details) {
    try {
      const user = this.pca.getActiveAccount();
      const logEntry = {
        timestamp: new Date().toISOString(),
        user: user?.username || 'Unknown',
        eventType,
        details,
        userAgent: navigator.userAgent,
        ipAddress: await this.getClientIP()
      };

      console.log('Security Event:', logEntry);

      // In production, send to your security logging service
      // await this.sendToSecurityLog(logEntry);
    } catch (error) {
      console.error('Failed to log security event:', error);
    }
  }

  async getClientIP() {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch (error) {
      return 'Unknown';
    }
  }

  getCurrentUser() {
    return this.pca.getActiveAccount();
  }

  isAuthenticated() {
    return this.pca.getActiveAccount() !== null;
  }
}

export default new PowerBIService();