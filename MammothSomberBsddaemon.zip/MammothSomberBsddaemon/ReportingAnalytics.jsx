import React from 'react';
import { Container, Typography, Paper, Grid } from '@mui/material';
import { Bar, Line, Pie } from 'react-chartjs-2';

const ReportingAnalytics = () => {
  const maintenanceData = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
    datasets: [
      {
        label: 'Number of Maintenance Tasks',
        backgroundColor: 'rgba(75,192,192,0.4)',
        borderColor: 'rgba(75,192,192,1)',
        borderWidth: 1,
        hoverBackgroundColor: 'rgba(75,192,192,0.6)',
        hoverBorderColor: 'rgba(75,192,192,1)',
        data: [65, 59, 80, 81, 56, 55, 40],
      },
    ],
  };

  const costData = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
    datasets: [
      {
        label: 'Maintenance Cost ($)',
        backgroundColor: 'rgba(153,102,255,0.4)',
        borderColor: 'rgba(153,102,255,1)',
        borderWidth: 1,
        hoverBackgroundColor: 'rgba(153,102,255,0.6)',
        hoverBorderColor: 'rgba(153,102,255,1)',
        data: [500, 400, 450, 700, 600, 800, 750],
      },
    ],
  };

  const downtimeData = {
    labels: ['Machine A', 'Machine B', 'Machine C', 'Machine D'],
    datasets: [
      {
        label: 'Downtime Hours',
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
        hoverBackgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
        data: [10, 20, 30, 15],
      },
    ],
  };

  return (
    <Container component="main" maxWidth="lg">
      <Typography variant="h4" component="h1" gutterBottom>
        Reporting and Analytics
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper style={{ padding: '20px' }}>
            <Typography variant="h6" component="h2" gutterBottom>
              Maintenance Tasks Over Time
            </Typography>
            <Bar data={maintenanceData} />
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper style={{ padding: '20px' }}>
            <Typography variant="h6" component="h2" gutterBottom>
              Maintenance Costs Over Time
            </Typography>
            <Line data={costData} />
          </Paper>
        </Grid>
        <Grid item xs={12}>
          <Paper style={{ padding: '20px' }}>
            <Typography variant="h6" component="h2" gutterBottom>
              Downtime by Machine
            </Typography>
            <Pie data={downtimeData} />
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default ReportingAnalytics;
