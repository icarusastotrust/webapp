import React, { useState } from 'react';
import { Container, Typography, Grid, TextField, Button, Paper, List, ListItem, ListItemText, Tabs, Tab, Box } from '@mui/material';
import { LocalizationProvider, DateTimePicker } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { format } from 'date-fns';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import { PowerBIEmbed } from 'powerbi-client-react';
import { models } from 'powerbi-client';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';

const localizer = momentLocalizer(moment);

const MaintenanceScheduling = () => {
  const [formData, setFormData] = useState({
    machine: '',
    description: '',
    date: new Date(),
  });

  const [events, setEvents] = useState([]);
  const [upcomingTasks, setUpcomingTasks] = useState([]);
  const [tabValue, setTabValue] = useState(0);
  
  // Power BI configuration for maintenance analytics
  const maintenanceEmbedConfig = {
    type: 'report',
    id: process.env.REACT_APP_MAINTENANCE_REPORT_ID || '',
    embedUrl: process.env.REACT_APP_MAINTENANCE_EMBED_URL || '',
    accessToken: process.env.REACT_APP_POWERBI_ACCESS_TOKEN || '',
    tokenType: models.TokenType.Embed,
    settings: {
      panes: {
        filters: { expanded: false, visible: true }
      },
      background: models.BackgroundType.Transparent,
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleDateChange = (date) => {
    setFormData({ ...formData, date });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newEvent = {
      title: formData.machine,
      start: formData.date,
      end: formData.date,
      allDay: true,
      description: formData.description,
    };
    setEvents([...events, newEvent]);
    setUpcomingTasks([...upcomingTasks, newEvent]);
    setFormData({
      machine: '',
      description: '',
      date: new Date(),
    });
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <Container component="main" maxWidth="xl">
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 700, color: 'primary.main' }}>
          Maintenance Management & Analytics
        </Typography>
        <Typography variant="subtitle1" color="text.secondary">
          Comprehensive maintenance scheduling and equipment management system
        </Typography>
      </Box>
      
      {/* Quick Actions Bar */}
      <Paper sx={{ p: 2, mb: 3, borderRadius: 3, background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white' }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={8}>
            <Box display="flex" gap={2} flexWrap="wrap">
              <Button 
                variant="contained" 
                startIcon={<AddIcon />}
                onClick={() => navigate('/maintenance-equipment-database')}
                sx={{ backgroundColor: 'rgba(255,255,255,0.2)', '&:hover': { backgroundColor: 'rgba(255,255,255,0.3)' } }}
              >
                Equipment Database
              </Button>
              <Button 
                variant="contained" 
                startIcon={<ScheduleIcon />}
                sx={{ backgroundColor: 'rgba(255,255,255,0.2)', '&:hover': { backgroundColor: 'rgba(255,255,255,0.3)' } }}
              >
                Schedule Maintenance
              </Button>
              <Button 
                variant="contained" 
                startIcon={<AssignmentIcon />}
                sx={{ backgroundColor: 'rgba(255,255,255,0.2)', '&:hover': { backgroundColor: 'rgba(255,255,255,0.3)' } }}
              >
                Work Orders
              </Button>
            </Box>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box display="flex" justifyContent="flex-end" gap={2}>
              <Chip 
                icon={<WarningIcon />} 
                label={`${urgentTasks} Urgent Tasks`} 
                color="warning" 
                variant="filled"
                sx={{ color: 'white', fontWeight: 600 }}
              />
              <Chip 
                icon={<CheckCircleIcon />} 
                label={`${completedTasks} Completed`} 
                color="success" 
                variant="filled"
                sx={{ color: 'white', fontWeight: 600 }}
              />
            </Box>
          </Grid>
        </Grid>
      </Paper>
      
      <Paper sx={{ borderRadius: 3, overflow: 'hidden', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}>
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange} 
          aria-label="maintenance tabs"
          sx={{ 
            borderBottom: 1, 
            borderColor: 'divider',
            '& .MuiTab-root': { fontWeight: 600 }
          }}
        >
          <Tab icon={<ScheduleIcon />} label="Schedule & Calendar" iconPosition="start" />
          <Tab icon={<AnalyticsIcon />} label="Power BI Analytics" iconPosition="start" />
          <Tab icon={<AssessmentIcon />} label="Performance Reports" iconPosition="start" />
          <Tab icon={<BuildIcon />} label="Equipment Database" iconPosition="start" />
        </Tabs>
      </Paper>

      {/* Schedule & Calendar Tab */}
      {tabValue === 0 && (
        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <Paper style={{ padding: '20px' }}>
              <Typography variant="h6" component="h2" gutterBottom>
                Schedule Maintenance
              </Typography>
              <form onSubmit={handleSubmit}>
                <TextField
                  name="machine"
                  label="Machine"
                  fullWidth
                  variant="outlined"
                  margin="normal"
                  value={formData.machine}
                  onChange={handleChange}
                />
                <TextField
                  name="description"
                  label="Description"
                  fullWidth
                  variant="outlined"
                  margin="normal"
                  value={formData.description}
                  onChange={handleChange}
                />
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DateTimePicker
                    label="Maintenance Date & Time"
                    value={formData.date}
                    onChange={handleDateChange}
                    renderInput={(props) => <TextField {...props} fullWidth variant="outlined" margin="normal" />}
                  />
                </LocalizationProvider>
                <Button type="submit" variant="contained" color="primary" fullWidth>
                  Schedule
                </Button>
              </form>
            </Paper>
          </Grid>
          <Grid item xs={12} md={8}>
            <Paper style={{ padding: '20px' }}>
              <Typography variant="h6" component="h2" gutterBottom>
                Upcoming Maintenance Tasks
              </Typography>
              <List>
                {upcomingTasks.map((task, index) => (
                  <ListItem key={index}>
                    <ListItemText
                      primary={`${task.title} - ${format(new Date(task.start), 'dd/MM/yyyy HH:mm')}`}
                      secondary={task.description}
                    />
                  </ListItem>
                ))}
              </List>
            </Paper>
          </Grid>
          <Grid item xs={12}>
            <Paper style={{ padding: '20px' }}>
              <Typography variant="h6" component="h2" gutterBottom>
                Maintenance Calendar
              </Typography>
              <Calendar
                localizer={localizer}
                events={events}
                startAccessor="start"
                endAccessor="end"
                style={{ height: 500 }}
              />
            </Paper>
          </Grid>
        </Grid>
      )}

      {/* Power BI Analytics Tab */}
      {tabValue === 1 && (
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Paper style={{ padding: '20px' }}>
              <Typography variant="h6" component="h2" gutterBottom>
                Maintenance Analytics Dashboard
              </Typography>
              {maintenanceEmbedConfig.id && maintenanceEmbedConfig.embedUrl && maintenanceEmbedConfig.accessToken ? (
                <PowerBIEmbed
                  embedConfig={maintenanceEmbedConfig}
                  eventHandlers={
                    new Map([
                      ['loaded', function () { console.log('Maintenance report loaded'); }],
                      ['rendered', function () { console.log('Maintenance report rendered'); }],
                      ['error', function (event) { console.log(event.detail); }]
                    ])
                  }
                  cssClassName={"maintenanceReportClass"}
                />
              ) : (
                <div style={{ height: '500px', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#f5f5f5' }}>
                  <Typography variant="body1" color="textSecondary">
                    Configure Power BI credentials in environment variables to display maintenance analytics
                  </Typography>
                </div>
              )}
            </Paper>
          </Grid>
        </Grid>
      )}

      {/* Performance Reports Tab */}
      {tabValue === 2 && (
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Paper style={{ padding: '20px' }}>
              <Typography variant="h6" component="h2" gutterBottom>
                Equipment Downtime Analysis
              </Typography>
              <div style={{ height: '300px', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#f5f5f5' }}>
                <Typography variant="body2" color="textSecondary">
                  Power BI equipment downtime reports will be embedded here
                </Typography>
              </div>
            </Paper>
          </Grid>
          <Grid item xs={12} md={6}>
            <Paper style={{ padding: '20px' }}>
              <Typography variant="h6" component="h2" gutterBottom>
                Maintenance Cost Trends
              </Typography>
              <div style={{ height: '300px', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#f5f5f5' }}>
                <Typography variant="body2" color="textSecondary">
                  Power BI cost analysis reports will be embedded here
                </Typography>
              </div>
            </Paper>
          </Grid>
        </Grid>
      )}
    </Container>
  );
};

export default MaintenanceScheduling;
