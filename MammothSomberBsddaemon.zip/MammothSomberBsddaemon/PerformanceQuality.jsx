import React, { useState } from 'react';
import { Container, TextField, Button, Typography, Paper, Grid } from '@mui/material';
import QualityComparisonChart from './QualityComparisonChart';

const PerformanceQuality = () => {
  const [formData, setFormData] = useState({
    moistureContent: '',
    freeFattyAcids: '',
    peroxideValue: '',
    aflatoxin: '',
    eColi: '',
    salmonella: '',
    listeria: '',
    staphylococcus: '',
  });

  const [showChart, setShowChart] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowChart(true);
  };

  return (
    <Container component="main" maxWidth="md">
      <Paper style={{ padding: '20px' }}>
        <Typography variant="h5" component="h1" gutterBottom>
          Performance Quality
        </Typography>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                name="moistureContent"
                label="Moisture Content (%)"
                fullWidth
                variant="outlined"
                value={formData.moistureContent}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="freeFattyAcids"
                label="Free Fatty Acids (%)"
                fullWidth
                variant="outlined"
                value={formData.freeFattyAcids}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="peroxideValue"
                label="Peroxide Value (meq/kg)"
                fullWidth
                variant="outlined"
                value={formData.peroxideValue}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="aflatoxin"
                label="Aflatoxin Level"
                fullWidth
                variant="outlined"
                value={formData.aflatoxin}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="eColi"
                label="E. Coli"
                fullWidth
                variant="outlined"
                value={formData.eColi}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="salmonella"
                label="Salmonella"
                fullWidth
                variant="outlined"
                value={formData.salmonella}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="listeria"
                label="Listeria Monocytogenes"
                fullWidth
                variant="outlined"
                value={formData.listeria}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="staphylococcus"
                label="Staphylococcus Aureus"
                fullWidth
                variant="outlined"
                value={formData.staphylococcus}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <Button type="submit" variant="contained" color="primary">
                Submit
              </Button>
            </Grid>
          </Grid>
        </form>
      </Paper>
      {showChart && <QualityComparisonChart data={formData} />}
    </Container>
  );
};

export default PerformanceQuality;
